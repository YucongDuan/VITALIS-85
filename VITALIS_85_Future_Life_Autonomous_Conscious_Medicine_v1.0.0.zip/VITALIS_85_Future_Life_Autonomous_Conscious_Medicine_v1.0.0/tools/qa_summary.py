from pathlib import Path
import json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
p=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,text=True,capture_output=True)
text=p.stdout+p.stderr;m=re.search(r'Ran (\d+) tests',text);n=int(m.group(1)) if m else 0
static=json.loads((ROOT/'outputs/static_audit.json').read_text()) if (ROOT/'outputs/static_audit.json').exists() else {'passed':False,'passed_count':0,'total':0}
http=json.loads((ROOT/'outputs/http_acceptance.json').read_text()) if (ROOT/'outputs/http_acceptance.json').exists() else {'passed':False,'passed_count':0,'total':0}
browser=json.loads((ROOT/'outputs/browser_validate.json').read_text()) if (ROOT/'outputs/browser_validate.json').exists() else {'passed':False,'count':0,'checks':[]}
out={'system':'VITALIS-85','version':'1.0.0','unit_tests':{'passed':p.returncode==0,'passed_count':n if p.returncode==0 else 0,'total':n,'output_tail':text[-4000:]},'static_audit':static,'http_acceptance':http,'browser_validation':browser}
out['passed']=p.returncode==0 and static['passed'] and http['passed'] and browser['passed'];out['passed_count']=out['unit_tests']['passed_count']+static['passed_count']+http['passed_count']+browser.get('count',0);out['total']=n+static['total']+http['total']+browser.get('count',0);(ROOT/'outputs/qa_summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(0 if out['passed'] else 1)
