from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1];exclude={'MANIFEST.sha256'};lines=[]
for p in sorted(ROOT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(ROOT).as_posix()
 if rel in exclude or rel.startswith('var/') or rel.startswith('outputs/visual_evidence/') or '__pycache__' in rel or rel.endswith('.pyc'):continue
 lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel}")
(ROOT/'MANIFEST.sha256').write_text('\n'.join(lines)+'\n');print(len(lines))
