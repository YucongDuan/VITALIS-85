from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from vitalis85.engine import VITALIS85Engine
E=VITALIS85Engine()
D={
 'dashboard':E.dashboard(),'daemon':E.autonomous_daemon_status(),'constitution':E.list_kind('constitution')[0],'self':E.list_kind('self_state')[0],'reflection':E.list_kind('self_reflection')[0],
 'life_assessments':{'items':E.list_kind('life_assessment')},'consciousness_assessments':{'items':E.list_kind('consciousness_assessment')},
 'health_assessments':{'items':E.list_kind('health_assessment')},'ai_pathologies':{'items':E.list_kind('ai_pathology')},'interactions_risks':{'items':E.list_kind('interaction_risk')},
 'goals':{'items':E.list_kind('goal')},'missions_deliberations':{'items':E.list_kind('mission_deliberation')},'actions_gates':{'items':E.list_kind('action_gate')},
 'worldlines':{'items':E.list_kind('worldline')},'evidence_cells':{'items':E.list_kind('evidence_cell')},'guidance':{'items':E.list_kind('living_guidance')},
 'connectors':E.list_kind('connector'),'mesh85_evaluations':{'items':E.list_kind('mesh85_evaluation')},'audit_verify':E.store.verify_audit(),
}
html=(ROOT/'web/index.html').read_text();css=(ROOT/'web/styles.css').read_text();js=(ROOT/'web/app.js').read_text()
html=html.replace('<link rel="stylesheet" href="styles.css">',f'<style>{css}</style>').replace('<script src="app.js"></script>',f'<script>window.VITALIS_OFFLINE_DATA={json.dumps(D,ensure_ascii=False)};</script><script>{js}</script>').replace('<link rel="manifest" href="manifest.webmanifest">','').replace('<link rel="icon" href="favicon.svg">','')
out=ROOT/'web/offline_demo.html';out.write_text(html,encoding='utf-8');print(out)
