from __future__ import annotations
from pathlib import Path
import json,sys,tempfile,threading,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from vitalis85.app import create_server
from vitalis85.engine import VITALIS85Engine
from vitalis85.store import KnowledgeStore
from playwright.sync_api import sync_playwright
T=None;S=None
outdir=ROOT/'outputs/visual_evidence';outdir.mkdir(parents=True,exist_ok=True);checks=[]
try:
 with sync_playwright() as pw:
  b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--allow-file-access-from-files']);page=b.new_page(viewport={'width':1440,'height':1000});page.set_content((ROOT/'web/offline_demo.html').read_text(encoding='utf-8'),wait_until='load');page.screenshot(path=str(outdir/'00_login.png'),full_page=True);page.fill('#username','autonomous_core');page.fill('#password','mesh85-demo');page.click('#loginBtn');page.wait_for_selector('#shell:not(.hidden)');page.wait_for_timeout(800)
  views=['overview','constitution','self','missions','health','ai','interaction','consciousness','life','evidence','actions','worldlines','connectors','mesh85','audit','ecology','architecture']
  for i,v in enumerate(views,1):
   page.click(f'[data-view="{v}"]');page.wait_for_timeout(180);page.screenshot(path=str(outdir/f'{i:02d}_{v}.png'),full_page=True);checks.append({'view':v,'passed':True})
  page.set_viewport_size({'width':390,'height':844});page.click('[data-view="overview"]');page.wait_for_timeout(200);page.screenshot(path=str(outdir/'18_mobile.png'),full_page=True);checks.append({'view':'mobile','passed':True});b.close()
finally:
 if S: S.shutdown();S.server_close()
 if T: T.cleanup()
out={'passed':all(x['passed'] for x in checks),'count':len(checks),'checks':checks};(ROOT/'outputs/browser_validate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
