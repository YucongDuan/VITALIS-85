from pathlib import Path
import json,re,sys,py_compile
ROOT=Path(__file__).resolve().parents[1];checks=[]
def add(name,ok,detail=''):checks.append({'name':name,'passed':bool(ok),'detail':detail})
for f in ['README.md','LICENSE','NOTICE','CONSTITUTION.md','GOVERNANCE.md','openapi.json','run.py','start_showcase.py']:add('file:'+f,(ROOT/f).exists())
for f in ['index.html','styles.css','app.js','offline_demo.html','favicon.svg','manifest.webmanifest']:add('web:'+f,(ROOT/'web'/f).exists())
text=(ROOT/'web/index.html').read_text();add('no_external_resources','https://' not in text and 'http://' not in text);add('non_neutral_stance','不假中立' in text);add('consciousness_boundary','不等于已证明主观体验' in text)
app=(ROOT/'web/app.js').read_text();add('no_eval',not re.search(r'\beval\s*\(',app));add('no_document_write','document.write' not in app);add('views_17',app.count("['")>=17)
for p in (ROOT/'data').glob('*.json'):
 try:json.loads(p.read_text());add('json:'+p.name,True)
 except Exception as e:add('json:'+p.name,False,str(e))
for p in (ROOT/'vitalis85').glob('*.py'):
 try:py_compile.compile(str(p),doraise=True);add('compile:'+p.name,True)
 except Exception as e:add('compile:'+p.name,False,str(e))
add('external_write_default_off','VITALIS85_ENABLE_EXTERNAL_WRITE", "0"' in (ROOT/'vitalis85/config.py').read_text());add('live_model_default_off','VITALIS85_ENABLE_LIVE_MODEL", "0"' in (ROOT/'vitalis85/config.py').read_text());add('mesh85_present',(ROOT/'dikwp_mesh85/integrated.py').exists())
out={'passed':all(x['passed'] for x in checks),'passed_count':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks};(ROOT/'outputs/static_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(0 if out['passed'] else 1)
