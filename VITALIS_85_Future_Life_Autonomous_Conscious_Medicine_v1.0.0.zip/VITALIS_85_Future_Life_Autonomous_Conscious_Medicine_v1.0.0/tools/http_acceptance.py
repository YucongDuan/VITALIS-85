from pathlib import Path
import json,sys,tempfile,threading,time,urllib.request
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from vitalis85.app import create_server
from vitalis85.engine import VITALIS85Engine
from vitalis85.store import KnowledgeStore
T=tempfile.TemporaryDirectory();E=VITALIS85Engine(KnowledgeStore(Path(T.name)/'x.db'));S=create_server('127.0.0.1',0,E);p=S.server_address[1];th=threading.Thread(target=S.serve_forever,daemon=True);th.start();time.sleep(.1);checks=[]
def get(path):
 with urllib.request.urlopen(f'http://127.0.0.1:{p}{path}',timeout=5) as r:return r.status,dict(r.headers),r.read()
def add(n,ok,d=''):checks.append({'name':n,'passed':bool(ok),'detail':d})
try:
 s,h,b=get('/api/health');x=json.loads(b);add('health',s==200 and x['status']=='ok');add('security_headers','Content-Security-Policy' in h);add('index','VITALIS-85' in get('/')[2].decode());add('styles',get('/styles.css')[0]==200);add('app_js',get('/app.js')[0]==200);add('fhir',json.loads(get('/fhir/R4/metadata')[2])['fhirVersion']=='4.0.1');add('offline',(ROOT/'web/offline_demo.html').exists());add('audit',E.store.verify_audit()['valid']);add('mesh85',len(E.list_kind('mesh85_evaluation'))>=6);add('goals',len(E.list_kind('goal'))==5);add('missions',len(E.list_kind('mission_deliberation'))==6);add('consciousness',len(E.list_kind('consciousness_assessment'))==4);add('life',len(E.list_kind('life_assessment'))==7);add('health_cases',len(E.list_kind('health_assessment'))==4)
finally:S.shutdown();S.server_close();T.cleanup()
out={'passed':all(x['passed'] for x in checks),'passed_count':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks};(ROOT/'outputs/http_acceptance.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(0 if out['passed'] else 1)
