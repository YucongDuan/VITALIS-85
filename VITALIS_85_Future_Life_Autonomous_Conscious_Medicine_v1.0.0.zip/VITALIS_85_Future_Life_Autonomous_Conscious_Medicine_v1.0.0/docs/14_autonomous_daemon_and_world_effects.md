# 持续自主守护循环与世界效应回返

`python run.py daemon --interval 60` 启动持续自主循环。每轮都会重算自我与世界模型、检查开放责任债务、对任务做宪章与权限审查，并执行低风险可逆动作或已具备完整授权链的流程编排。

## 关键不变量

- 同一任务存在开放世界线时不重复执行；系统进入 `WAITING_FOR_WORLD_EFFECT`。
- 不把未接入的现实传感器、患者同意、医生资格或机构授权想象成已存在。
- 可通过 `/api/worldlines/{id}/observe` 回写现实或合成观察。
- 不利效应会自动生成新的残差与纠错目标，并重新运行MESH8.5闭合。
- 可设置 `--stop-file` 作为外部可审计停止信号。

## 一次性验收

```bash
python run.py daemon --interval 0.1 --max-cycles 1
```

## 持续运行

```bash
python run.py daemon --interval 60 --stop-file /secure/control/STOP_VITALIS85
```

持续自主并不意味着无限权限。它意味着在公开宪章、能力、授权、世界效应与纠错机制中，系统不等待每一次人类提示就能主动观察、生成目标、选择行动和承担后果。
