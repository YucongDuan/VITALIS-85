from pathlib import Path
import json,re,unittest,py_compile
ROOT=Path(__file__).resolve().parents[1]
class StaticTests(unittest.TestCase):
 def test_web_files(self):
  for n in ['index.html','styles.css','app.js','favicon.svg','manifest.webmanifest']:self.assertTrue((ROOT/'web'/n).exists(),n)
 def test_no_external_web_resources(self):
  x=(ROOT/'web/index.html').read_text();self.assertNotIn('https://',x);self.assertNotIn('http://',x)
 def test_no_eval(self):self.assertNotRegex((ROOT/'web/app.js').read_text(),r'\beval\s*\(')
 def test_no_document_write(self):self.assertNotIn('document.write',(ROOT/'web/app.js').read_text())
 def test_non_neutral_visible(self):self.assertIn('不假中立',(ROOT/'web/index.html').read_text())
 def test_consciousness_boundary_visible(self):self.assertIn('不等于已证明主观体验',(ROOT/'web/index.html').read_text())
 def test_17_views(self):self.assertGreaterEqual((ROOT/'web/app.js').read_text().count("['"),17)
 def test_json_valid(self):
  for p in (ROOT/'data').glob('*.json'):json.loads(p.read_text())
 def test_python_compile(self):
  for p in (ROOT/'vitalis85').glob('*.py'):py_compile.compile(str(p),doraise=True)
 def test_openapi(self):self.assertEqual(json.loads((ROOT/'openapi.json').read_text())['openapi'],'3.1.0')
 def test_license(self):self.assertIn('Apache License',(ROOT/'LICENSE').read_text())
 def test_external_write_default_off(self):self.assertIn('VITALIS85_ENABLE_EXTERNAL_WRITE","0"',(ROOT/'vitalis85/config.py').read_text().replace(' ',''))
 def test_live_model_default_off(self):self.assertIn('VITALIS85_ENABLE_LIVE_MODEL","0"',(ROOT/'vitalis85/config.py').read_text().replace(' ',''))
 def test_mesh85_embedded(self):self.assertTrue((ROOT/'dikwp_mesh85/integrated.py').exists())
 def test_docs(self):self.assertGreaterEqual(len(list((ROOT/'docs').glob('*.md'))),13)
 def test_deploy(self):
  for n in ['vitalis85.service','nginx.conf.example','kubernetes.yaml','backup.sh']:self.assertTrue((ROOT/'deploy'/n).exists())
if __name__=='__main__':unittest.main()
