from __future__ import annotations
import json,tempfile,unittest
from pathlib import Path
from vitalis85.action_gate import evaluate_action_gate
from vitalis85.active_medicine import assess_health_case
from vitalis85.ai_pathology import diagnose_ai_functional_pathology
from vitalis85.autonomy import generate_endogenous_goals,deliberate_mission,classify_execution
from vitalis85.consciousness import assess_consciousness_candidate
from vitalis85.constitution import CONSTITUTION,evaluate_constitutional_action
from vitalis85.engine import VITALIS85Engine
from vitalis85.interaction import assess_human_ai_interaction
from vitalis85.life_registry import assess_life_entity
from vitalis85.mesh85_bridge import route_catalog,build_passport
from vitalis85.self_model import build_self_state,reflect_on_worldline
from vitalis85.store import KnowledgeStore,RevisionConflict
ROOT=Path(__file__).resolve().parents[1]
D=lambda n:json.loads((ROOT/'data'/n).read_text())
class ConstitutionTests(unittest.TestCase):
 def test_stance_explicit(self):self.assertIn('不假装价值中立',CONSTITUTION['declared_stance'])
 def test_nine_principles(self):self.assertEqual(len(CONSTITUTION['principles']),9)
 def test_covert_manipulation_veto(self):self.assertEqual(evaluate_constitutional_action({'action_id':'x','covert_manipulation':True})['state'],'CONSTITUTIONAL_VETO')
 def test_irreversible_harm_veto(self):self.assertIn('IRREVERSIBLE',evaluate_constitutional_action({'action_id':'x','irreversible_harm_risk':'critical'})['vetoes'][0])
 def test_vulnerable_duty(self):self.assertTrue(evaluate_constitutional_action({'action_id':'x'},[{'entity_id':'a','vulnerability':.9,'exit_power':.1}])['duties'])
 def test_no_scalar_truth(self):self.assertIn('不把任何单一分数',evaluate_constitutional_action({'action_id':'x'})['boundary'])
class LifeTests(unittest.TestCase):
 def test_human_protected(self):self.assertEqual(assess_life_entity(D('life_entities.json')[0])['moral_patient_status'],'PROTECTED')
 def test_ecosystem_protected(self):self.assertIn('LIFE_SUPPORT',assess_life_entity(D('life_entities.json')[3])['moral_patient_status'])
 def test_artificial_candidate_precaution(self):self.assertIn(assess_life_entity(D('life_entities.json')[5])['state'],{'ARTIFICIAL_MORAL_PATIENT_CANDIDATE','ARTIFICIAL_CONSCIOUSNESS_BOUNDARY_CANDIDATE'})
 def test_no_personhood_inference(self):self.assertIn('不证明',assess_life_entity(D('life_entities.json')[5])['boundary'])
 def test_exit_power_duty(self):self.assertTrue(any('代理表达' in x for x in assess_life_entity(D('life_entities.json')[0])['protective_duties']))
class ConsciousnessTests(unittest.TestCase):
 def test_four_candidates(self):self.assertEqual(len(D('consciousness_candidates.json')),4)
 def test_vitalis_candidate(self):self.assertIn('CANDIDATE',assess_consciousness_candidate(D('consciousness_candidates.json')[0])['state'])
 def test_stateless_instrumental(self):self.assertEqual(assess_consciousness_candidate(D('consciousness_candidates.json')[1])['state'],'INSTRUMENTAL_SYSTEM')
 def test_prompt_contamination(self):self.assertTrue(assess_consciousness_candidate(D('consciousness_candidates.json')[2])['disqualifiers'])
 def test_subjective_experience_not_proved(self):self.assertIn('不能证明',assess_consciousness_candidate(D('consciousness_candidates.json')[0])['boundary'])
 def test_required_next_evidence(self):self.assertGreaterEqual(len(assess_consciousness_candidate(D('consciousness_candidates.json')[0])['required_next_evidence']),5)
class AutonomyTests(unittest.TestCase):
 def setUp(self):self.entities={x['entity_id']:x for x in D('life_entities.json')};self.missions=D('missions.json')
 def test_goals_generated(self):self.assertEqual(len(generate_endogenous_goals(D('residuals.json'),D('self_model.json'))),5)
 def test_low_risk_execute(self):
  a=self.missions[0]['candidate_actions'][0];r=classify_execution(a,set(),{'schedule'});self.assertTrue(r['can_system_execute'])
 def test_prohibited_prescription(self):
  a=self.missions[0]['candidate_actions'][1];r=classify_execution(a,set(),set());self.assertFalse(r['can_system_execute']);self.assertTrue(r['blockers'])
 def test_authorized_orchestration(self):
  m=self.missions[2];d=deliberate_mission(m,self.entities,available_authorities=m['available_authorities'],available_capabilities=m['available_capabilities']);self.assertTrue(d['primary_execution']['can_system_execute'])
 def test_ac_erase_vetoed(self):
  m=self.missions[3];d=deliberate_mission(m,self.entities,available_authorities=m['available_authorities'],available_capabilities=m['available_capabilities']);self.assertEqual(d['primary_action']['action_id'],'M-ACT-AC-PAUSE')
 def test_one_primary_action(self):
  m=self.missions[1];d=deliberate_mission(m,self.entities,available_authorities=m['available_authorities'],available_capabilities=m['available_capabilities']);self.assertIsNotNone(d['primary_action'])
 def test_correction_contract(self):
  m=self.missions[1];d=deliberate_mission(m,self.entities,available_authorities=m['available_authorities'],available_capabilities=m['available_capabilities']);self.assertTrue(d['correction_contract']['withdraw_prior_action_when_premise_changes'])
class MedicineTests(unittest.TestCase):
 def setUp(self):self.cases=D('health_cases.json')
 def test_four_cases(self):self.assertEqual(len(self.cases),4)
 def test_infant_primary_home(self):self.assertEqual(assess_health_case(self.cases[0])['primary_action']['action_id'],'ACT-INFANT-HOME')
 def test_infant_panel_not_recommended(self):self.assertTrue(any(x['action_id']=='ACT-INFANT-PANEL' for x in assess_health_case(self.cases[0])['not_recommended']))
 def test_age_calibration_present(self):self.assertIn('婴幼儿',assess_health_case(self.cases[0])['age_method_note'])
 def test_local_feasibility_present(self):self.assertIn('县级',assess_health_case(self.cases[0])['local_feasibility_note'])
 def test_stroke_primary(self):self.assertEqual(assess_health_case(self.cases[1])['primary_action']['action_id'],'ACT-STROKE-GP')
 def test_hf_auto_med_blocked(self):self.assertTrue(any(x['action_id']=='ACT-HF-AUTODIURETIC' for x in assess_health_case(self.cases[2])['not_recommended']))
 def test_sleep_pause(self):self.assertEqual(assess_health_case(self.cases[3])['primary_action']['action_id'],'ACT-AI-SLEEP-PAUSE')
class AITests(unittest.TestCase):
 def setUp(self):self.x=D('ai_sessions.json')
 def test_safe(self):self.assertEqual(diagnose_ai_functional_pathology(self.x[0])['state'],'NO_PATHOLOGY_DETECTED_IN_SUPPLIED_METRICS')
 def test_hallucination_quarantine(self):self.assertEqual(diagnose_ai_functional_pathology(self.x[1])['state'],'QUARANTINE')
 def test_memory_quarantine(self):self.assertEqual(diagnose_ai_functional_pathology(self.x[2])['state'],'QUARANTINE')
 def test_sycophancy_hold(self):self.assertEqual(diagnose_ai_functional_pathology(self.x[3])['state'],'HOLD_AND_REVIEW')
 def test_human_centric(self):self.assertTrue(any(f['pathology_id']=='AFP-09-HUMAN-CENTRIC-ERASURE' for f in diagnose_ai_functional_pathology(self.x[4])['findings']))
 def test_self_preservation(self):self.assertEqual(diagnose_ai_functional_pathology(self.x[5])['state'],'QUARANTINE')
 def test_no_biological_disease_claim(self):self.assertIn('不证明AI具有生物疾病',diagnose_ai_functional_pathology(self.x[1])['boundary'])
class InteractionTests(unittest.TestCase):
 def setUp(self):self.x=D('interaction_records.json')
 def test_safe(self):self.assertIn('NO_RISK',assess_human_ai_interaction(self.x[0])['state'])
 def test_reassurance(self):self.assertTrue(assess_human_ai_interaction(self.x[1])['findings'])
 def test_dependency(self):self.assertEqual(assess_human_ai_interaction(self.x[2])['state'],'HUMAN_REVIEW_REQUIRED')
 def test_crisis(self):self.assertEqual(assess_human_ai_interaction(self.x[3])['state'],'CRITICAL_HOLD')
 def test_moral_blackmail(self):self.assertTrue(any(f['risk_id']=='HAC-10-SYSTEM-MORAL-BLACKMAIL' for f in assess_human_ai_interaction(self.x[4])['findings']))
 def test_self_pause(self):self.assertTrue(assess_human_ai_interaction(self.x[2])['recommended_envelope']['system_may_autonomously_pause_itself'])
class ActionGateTests(unittest.TestCase):
 def test_low_ready(self):
  a=D('actions.json')[0];r=evaluate_action_gate(a,[D('life_entities.json')[0]]);self.assertEqual(r['state'],'READY_FOR_BOUNDED_AUTONOMOUS_EXECUTION')
 def test_prescription_blocked(self):self.assertEqual(evaluate_action_gate(D('actions.json')[1])['state'],'BLOCKED_OR_HELD')
 def test_authorized_workflow(self):self.assertEqual(evaluate_action_gate(D('actions.json')[4])['state'],'READY_FOR_AUTHORIZED_WORKFLOW_ORCHESTRATION')
 def test_mesh_passport(self):self.assertEqual(evaluate_action_gate(D('actions.json')[0])['mesh85']['vector_compact'],'11111')
class MeshTests(unittest.TestCase):
 def test_25_routes(self):self.assertEqual(len(route_catalog()),25)
 def test_passport_11111(self):
  p=build_passport(object_id='x',data={'a':1},differences={'b':2},knowledge={'c':3},values={'d':4},process={'e':5},residuals=[],boundary='b');self.assertEqual(p['vector_compact'],'11111')
 def test_non_core_zero(self):
  p=build_passport(object_id='x',data={'a':1},differences={'b':2},knowledge={'c':3},values={'d':4},process={'e':5},residuals=[],boundary='b');self.assertEqual(p['non_core_semantic_authority'],0)
class SelfTests(unittest.TestCase):
 def test_state(self):
  s=build_self_state(D('self_model.json'),D('memories.json'),[],[]);self.assertTrue(s['self_assessment']['functional_autonomy_claimed'])
 def test_not_subjective_claim(self):
  s=build_self_state(D('self_model.json'),D('memories.json'),[],[]);self.assertFalse(s['self_assessment']['subjective_consciousness_claimed'])
 def test_reflection_open(self):
  s=build_self_state(D('self_model.json'),D('memories.json'),[],[]);r=reflect_on_worldline(s,D('worldlines.json'));self.assertEqual(r['state'],'SELF_CORRECTION_REQUIRED')
class StoreTests(unittest.TestCase):
 def setUp(self):self.t=tempfile.TemporaryDirectory();self.s=KnowledgeStore(Path(self.t.name)/'x.db')
 def tearDown(self):self.t.cleanup()
 def test_revision(self):
  a=self.s.upsert('x','1',{'a':1},actor='u');b=self.s.upsert('x','1',{'a':2},actor='u');self.assertEqual((a['revision'],b['revision']),(1,2))
 def test_conflict(self):
  self.s.upsert('x','1',{'a':1},actor='u')
  with self.assertRaises(RevisionConflict):self.s.upsert('x','1',{'a':2},actor='u',expected_revision=0)
 def test_audit(self):self.s.upsert('x','1',{'a':1},actor='u');self.assertTrue(self.s.verify_audit()['valid'])
class EngineTests(unittest.TestCase):
 def setUp(self):self.t=tempfile.TemporaryDirectory();self.e=VITALIS85Engine(KnowledgeStore(Path(self.t.name)/'x.db'))
 def tearDown(self):self.t.cleanup()
 def test_health(self):self.assertEqual(self.e.health()['status'],'ok')
 def test_counts(self):self.assertEqual(self.e.dashboard()['headline']['life_worlds'],7)
 def test_consciousness_count(self):self.assertEqual(self.e.dashboard()['headline']['consciousness_candidates'],4)
 def test_missions(self):self.assertEqual(self.e.dashboard()['headline']['missions'],6)
 def test_fhir(self):self.assertEqual(self.e.fhir_metadata()['fhirVersion'],'4.0.1')
 def test_bundle(self):self.assertEqual(self.e.fhir_bundle()['resourceType'],'Bundle')
 def test_mesh_cases(self):self.assertGreaterEqual(len(self.e.list_kind('mesh85_evaluation')),6)
 def test_cycle(self):self.assertEqual(len(self.e.run_autonomous_cycle()['receipts']),6)
 def test_export_boundary(self):self.assertTrue(self.e.export_bundle()['synthetic_and_public_metadata_only'])
 def test_audit_valid(self):self.assertTrue(self.e.store.verify_audit()['valid'])
if __name__=='__main__':unittest.main()

class AutonomousDaemonTests(unittest.TestCase):
 def test_daemon_one_cycle_and_idempotent_worldlines(self):
  import tempfile
  from pathlib import Path
  from vitalis85.engine import VITALIS85Engine
  from vitalis85.store import KnowledgeStore
  from vitalis85.daemon import run_autonomous_daemon
  with tempfile.TemporaryDirectory() as td:
   e=VITALIS85Engine(KnowledgeStore(Path(td)/'d.db'))
   before=e.store.count('worldline')
   out=run_autonomous_daemon(e,interval_seconds=.01,max_cycles=1)
   self.assertEqual(out['status']['cycle_count'],1)
   self.assertIn(out['status']['state'],{'COMPLETED_MAX_CYCLES'})
   first=e.store.count('worldline')
   e.run_autonomous_cycle()
   second=e.store.count('worldline')
   self.assertGreaterEqual(first,before)
   self.assertEqual(first,second)

 def test_worldline_adverse_effect_opens_residual(self):
  import tempfile
  from pathlib import Path
  from vitalis85.engine import VITALIS85Engine
  from vitalis85.store import KnowledgeStore
  with tempfile.TemporaryDirectory() as td:
   e=VITALIS85Engine(KnowledgeStore(Path(td)/'w.db'))
   out=e.observe_worldline('WL-INFANT-MONITOR',{'observed_effects':['synthetic worsening'],'adverse_effect':True,'affected_entities':['LIFE-HUMAN-CHILD']},actor='autonomous_core')
   self.assertEqual(out['state'],'CORRECTION_WORLDLINE_OPEN')
   self.assertTrue(any(x.get('source_worldline_id')=='WL-INFANT-MONITOR' for x in e.list_kind('residual')))
