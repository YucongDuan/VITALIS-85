from __future__ import annotations
import unittest
from vitalis85.protocols import parse_fhir,parse_hl7_v2,parse_cda,parse_vendor_webhook,InterfaceValidationError,filter_dicom_catalog
class ProtocolTests(unittest.TestCase):
 def test_fhir_patient(self):self.assertEqual(parse_fhir({'resourceType':'Patient','id':'p1'})[0].external_id,'p1')
 def test_fhir_bundle(self):self.assertEqual(len(parse_fhir({'resourceType':'Bundle','type':'collection','entry':[{'resource':{'resourceType':'Patient','id':'p1'}},{'resource':{'resourceType':'Observation','id':'o1','subject':{'reference':'Patient/p1'}}}]})),2)
 def test_fhir_invalid(self):
  with self.assertRaises(InterfaceValidationError):parse_fhir({'id':'x'})
 def test_hl7(self):
  m='MSH|^~\\&|LIS|H|V85|H|20260815||ORU^R01|M1|P|2.5\rPID|||P001||SYNTH^PATIENT\rPV1|||||||||||||||||V001\rOBX|1|NM|GLU^Glucose||5.6|mmol/L|3.9-6.1|N|||F\r';r=parse_hl7_v2(m);self.assertEqual(r.patient_key,'P001');self.assertEqual(len(r.normalized['observations']),1)
 def test_hl7_invalid(self):
  with self.assertRaises(InterfaceValidationError):parse_hl7_v2('PID|x')
 def test_cda(self):
  x='<ClinicalDocument xmlns="urn:hl7-org:v3"><id extension="D1"/><title>Synthetic</title><recordTarget><patientRole><id extension="P1"/></patientRole></recordTarget></ClinicalDocument>';self.assertEqual(parse_cda(x).patient_key,'P1')
 def test_cda_doctype(self):
  with self.assertRaises(InterfaceValidationError):parse_cda('<!DOCTYPE x><ClinicalDocument/>')
 def test_webhook(self):self.assertEqual(parse_vendor_webhook({'event_id':'e1','patient_id':'p1'}).external_id,'e1')
 def test_dicom(self):self.assertTrue(filter_dicom_catalog({'Modality':'MR'}))
 def test_dicom_empty(self):self.assertFalse(filter_dicom_catalog({'Modality':'US'}))
if __name__=='__main__':unittest.main()
