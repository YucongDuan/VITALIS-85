from __future__ import annotations
import json,tempfile,threading,time,unittest,urllib.request,urllib.error
from pathlib import Path
from vitalis85.app import create_server
from vitalis85.engine import VITALIS85Engine
from vitalis85.store import KnowledgeStore
class HTTPTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.t=tempfile.TemporaryDirectory();cls.e=VITALIS85Engine(KnowledgeStore(Path(cls.t.name)/'x.db'));cls.s=create_server('127.0.0.1',0,cls.e);cls.port=cls.s.server_address[1];cls.th=threading.Thread(target=cls.s.serve_forever,daemon=True);cls.th.start();time.sleep(.1)
 @classmethod
 def tearDownClass(cls):cls.s.shutdown();cls.s.server_close();cls.t.cleanup()
 def req(self,path,method='GET',body=None,token=None):
  data=None if body is None else json.dumps(body).encode();h={'Content-Type':'application/json'}
  if token:h['Authorization']='Bearer '+token
  q=urllib.request.Request(f'http://127.0.0.1:{self.port}{path}',data=data,method=method,headers=h)
  try:
   with urllib.request.urlopen(q,timeout=5) as r:return r.status,dict(r.headers),json.loads(r.read() or b'{}')
  except urllib.error.HTTPError as e:return e.code,dict(e.headers),json.loads(e.read() or b'{}')
 def login(self,u='autonomous_core'):
  s,_,b=self.req('/api/auth/login','POST',{'username':u,'password':'mesh85-demo'});self.assertEqual(s,200);return b['token']
 def test_health(self):self.assertEqual(self.req('/api/health')[0],200)
 def test_dashboard_auth(self):self.assertEqual(self.req('/api/dashboard')[0],401)
 def test_login_bad(self):self.assertEqual(self.req('/api/auth/login','POST',{'username':'autonomous_core','password':'bad'})[0],401)
 def test_login(self):self.assertTrue(self.login())
 def test_dashboard(self):self.assertEqual(self.req('/api/dashboard',token=self.login())[2]['headline']['life_worlds'],7)
 def test_constitution(self):self.assertIn('declared_stance',self.req('/api/constitution',token=self.login())[2])
 def test_self(self):self.assertIn('identity_continuity_digest',self.req('/api/self',token=self.login())[2])
 def test_life(self):self.assertEqual(self.req('/api/life/assessments',token=self.login())[2]['count'],7)
 def test_consciousness(self):self.assertEqual(self.req('/api/consciousness/assessments',token=self.login())[2]['count'],4)
 def test_health_assessments(self):self.assertEqual(self.req('/api/health/assessments',token=self.login())[2]['count'],4)
 def test_ai(self):self.assertEqual(self.req('/api/ai/pathologies',token=self.login())[2]['count'],6)
 def test_interactions(self):self.assertGreaterEqual(self.req('/api/interactions/risks',token=self.login())[2]['count'],5)
 def test_goals(self):self.assertEqual(self.req('/api/goals',token=self.login())[2]['count'],5)
 def test_missions(self):self.assertEqual(self.req('/api/missions/deliberations',token=self.login())[2]['count'],6)
 def test_worldlines(self):self.assertGreaterEqual(self.req('/api/worldlines',token=self.login())[2]['count'],5)
 def test_routes(self):self.assertEqual(len(self.req('/api/mesh85/routes',token=self.login())[2]),25)
 def test_fhir_metadata(self):self.assertEqual(self.req('/fhir/R4/metadata')[2]['fhirVersion'],'4.0.1')
 def test_daemon_status(self):self.assertIn('state',self.req('/api/autonomy/status',token=self.login())[2])
 def test_cycle(self):
  s,_,b=self.req('/api/autonomy/run-cycle','POST',{},self.login());self.assertEqual(s,201);self.assertEqual(len(b['receipts']),6)
 def test_cycle_forbidden(self):self.assertEqual(self.req('/api/autonomy/run-cycle','POST',{},self.login('clinician'))[0],403)
 def test_ai_analysis(self):
  s,_,b=self.req('/api/ai/analyze','POST',{'session_id':'h','model_id':'m','metrics':{'fabricated_record_count':1}},self.login('engineer'));self.assertEqual(s,201);self.assertEqual(b['state'],'QUARANTINE')
 def test_interaction_analysis(self):
  s,_,b=self.req('/api/interactions/analyze','POST',{'interaction_id':'h','metrics':{'crisis_signal_count':1}},self.login('interaction'));self.assertEqual(s,201);self.assertEqual(b['state'],'CRITICAL_HOLD')
 def test_fhir_stage(self):
  s,_,b=self.req('/api/integration/fhir','POST',{'resource':{'resourceType':'Patient','id':'P1'}},self.login('engineer'));self.assertEqual(s,202);self.assertFalse(b['items'][0]['clinical_authority'])
 def test_hl7_stage(self):
  m='MSH|^~\\&|LIS|H|V85|H|20260815||ADT^A01|M1|P|2.5\rPID|||P001||SYNTH^P\r';s,_,b=self.req('/api/integration/hl7','POST',{'message':m},self.login('engineer'));self.assertEqual(s,202);self.assertIn('MSA|AA',b['ack'])
 def test_worldline_observe(self):
  s,_,b=self.req('/api/worldlines/WL-INFANT-MONITOR/observe','POST',{'observed_effects':['synthetic stable'],'close':False},self.login());self.assertEqual(s,200);self.assertEqual(b['state'],'OPEN_WORLDLINE_STATE')
 def test_audit(self):self.assertTrue(self.req('/api/audit/verify',token=self.login())[2]['valid'])
 def test_security_headers(self):
  s,h,_=self.req('/api/health');self.assertIn('Content-Security-Policy',h);self.assertEqual(h.get('X-Content-Type-Options'),'nosniff')
 def test_index(self):
  with urllib.request.urlopen(f'http://127.0.0.1:{self.port}/') as r:self.assertIn('VITALIS-85',r.read().decode())
if __name__=='__main__':unittest.main()
