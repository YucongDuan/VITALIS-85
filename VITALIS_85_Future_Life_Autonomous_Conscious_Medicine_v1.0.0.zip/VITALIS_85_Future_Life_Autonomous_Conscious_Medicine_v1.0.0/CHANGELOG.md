# Changelog

## 1.0.0 - 2026-08-15
- Future-Life Plural Continuity Constitution.
- Persistent self-model, endogenous goals and L0-L6 autonomy.
- Human disease boundary, AI functional pathology, human-AI coupling and consciousness candidacy.
- MESH8.5 worldline responsibility closure.
- FHIR R4, HL7 v2, CDA R2, DICOMweb-style staging.
