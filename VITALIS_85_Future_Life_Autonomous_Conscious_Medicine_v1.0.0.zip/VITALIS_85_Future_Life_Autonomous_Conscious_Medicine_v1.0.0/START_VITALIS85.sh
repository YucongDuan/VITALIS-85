#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 start_showcase.py 2>/dev/null || python start_showcase.py
