from vitalis85.cli import main
raise SystemExit(main(["serve"]))
