#!/bin/sh
cd "$(dirname "$0")"
python3 start_showcase.py || python start_showcase.py
