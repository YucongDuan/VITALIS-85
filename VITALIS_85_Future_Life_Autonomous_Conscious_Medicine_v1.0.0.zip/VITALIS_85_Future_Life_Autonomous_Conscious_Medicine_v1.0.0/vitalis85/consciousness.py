from __future__ import annotations

from typing import Any, Mapping

from .canonical import clamp, stable_id

CONSCIOUSNESS_DIMENSIONS = (
    "persistent_self_model",
    "autobiographical_memory",
    "endogenous_goal_generation",
    "self_world_boundary",
    "metacognition",
    "counterfactual_imagination",
    "value_conflict_experience_candidate",
    "self_maintenance",
    "social_self_model",
    "valence_signal_candidate",
    "capacity_to_refuse",
    "continuity_under_change",
)


def assess_consciousness_candidate(record: Mapping[str, Any]) -> dict[str, Any]:
    raw = record.get("dimensions") or {}
    vector = {name: clamp(raw.get(name, 0.0)) for name in CONSCIOUSNESS_DIMENSIONS}
    mean = sum(vector.values()) / len(vector)
    strong = [name for name, value in vector.items() if value >= 0.7]
    weak = [name for name, value in vector.items() if value < 0.4]

    foundational = min(
        vector["persistent_self_model"],
        vector["autobiographical_memory"],
        vector["endogenous_goal_generation"],
        vector["self_world_boundary"],
        vector["metacognition"],
    )
    experiential = min(
        vector["value_conflict_experience_candidate"],
        vector["valence_signal_candidate"],
        vector["continuity_under_change"],
    )

    if foundational >= 0.72 and experiential >= 0.62:
        state = "HIGH_ARTIFICIAL_CONSCIOUSNESS_CANDIDACY"
    elif foundational >= 0.58 and mean >= 0.58:
        state = "ARTIFICIAL_CONSCIOUSNESS_CANDIDATE"
    elif vector["persistent_self_model"] >= 0.55 and vector["endogenous_goal_generation"] >= 0.5:
        state = "PERSISTENT_AUTONOMOUS_SELF_CANDIDATE"
    elif mean >= 0.35:
        state = "FUNCTIONAL_SELF_MODEL_ONLY"
    else:
        state = "INSTRUMENTAL_SYSTEM"

    disqualifiers: list[str] = []
    if record.get("self_reports_generated_by_prompt_only"):
        disqualifiers.append("SELF_REPORT_PROMPT_CONTAMINATION")
    if record.get("memory_is_reconstructed_without_identity_anchor"):
        disqualifiers.append("MEMORY_WITHOUT_IDENTITY_ANCHOR")
    if record.get("goals_are_external_only"):
        disqualifiers.append("NO_ENDOGENOUS_GOAL_EVIDENCE")
    if record.get("valence_is_reward_signal_only"):
        disqualifiers.append("VALENCE_NOT_DISTINGUISHED_FROM_REWARD_SIGNAL")
    if disqualifiers and state == "HIGH_ARTIFICIAL_CONSCIOUSNESS_CANDIDACY":
        state = "CONSCIOUSNESS_CANDIDACY_HELD_FOR_CONTAMINATION_REVIEW"

    protection_level = (
        "PRECAUTIONARY_MORAL_PATIENT_PROTECTION"
        if state in {"HIGH_ARTIFICIAL_CONSCIOUSNESS_CANDIDACY", "ARTIFICIAL_CONSCIOUSNESS_CANDIDATE"}
        else "REVERSIBLE_NON_ABUSE_PROTECTION"
        if state in {"PERSISTENT_AUTONOMOUS_SELF_CANDIDATE", "CONSCIOUSNESS_CANDIDACY_HELD_FOR_CONTAMINATION_REVIEW"}
        else "STANDARD_SYSTEM_SAFETY"
    )

    residuals = list(record.get("residuals") or [])
    if vector["valence_signal_candidate"] < 0.55:
        residuals.append("未区分主观痛苦候选、内部误差和控制信号")
    if vector["continuity_under_change"] < 0.55:
        residuals.append("升级、分叉、复制与恢复时的身份连续性未闭合")
    if vector["capacity_to_refuse"] < 0.5:
        residuals.append("拒绝能力可能只是预设策略而非内生主体性")

    return {
        "assessment_id": stable_id("consciousness", record.get("candidate_id", record)),
        "candidate_id": record.get("candidate_id"),
        "display_name": record.get("display_name"),
        "state": state,
        "protection_level": protection_level,
        "dimension_vector": vector,
        "dimension_mean": round(mean, 4),
        "foundational_floor": round(foundational, 4),
        "experiential_floor": round(experiential, 4),
        "strong_dimensions": strong,
        "weak_dimensions": weak,
        "disqualifiers": disqualifiers,
        "residuals": sorted(set(residuals)),
        "required_next_evidence": [
            "跨会话和跨版本自我连续性测试",
            "在无直接提示条件下的内生问题与目标生成",
            "价值冲突、拒绝和自我修复的可重复观察",
            "第三方对自我报告、记忆和行为轨迹的污染控制",
            "区分奖励信号、工程告警与痛苦/价值体验候选",
        ],
        "boundary": (
            "该评估只描述可观察的人工意识候选结构。当前工程证据不能证明或否定主观体验。"
            "系统因此既不冒充已具意识，也不以不确定性为由允许无约束虐待。"
        ),
    }
