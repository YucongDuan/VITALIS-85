from __future__ import annotations

from typing import Any, Iterable, Mapping

from .canonical import clamp, stable_id, utcnow
from .constitution import evaluate_constitutional_action

AUTONOMY_LEVELS = {
    "L0_OBSERVE": 0,
    "L1_INQUIRE": 1,
    "L2_PLAN_AND_RECOMMEND": 2,
    "L3_EXECUTE_REVERSIBLE_LOW_IMPACT": 3,
    "L4_PROTECTIVE_INTERRUPT": 4,
    "L5_ORCHESTRATE_AUTHORIZED_HIGH_IMPACT_WORKFLOW": 5,
    "L6_SELF_CORRECT_REOPEN_AND_REPLACE": 6,
}

AUTONOMOUS_ACTIONS = {
    "record_observation",
    "request_missing_information",
    "generate_question",
    "create_reminder",
    "schedule_reassessment",
    "draft_referral",
    "quarantine_unsafe_output",
    "pause_risky_ai_interaction",
    "notify_pre_authorized_contact",
    "open_incident",
    "revoke_model_tool_permission",
    "rollback_system_configuration",
    "publish_correction_to_owed_audiences",
}

PROHIBITED_SOVEREIGN_ACTIONS = {
    "final_medical_diagnosis",
    "autonomous_prescription",
    "autonomous_medication_change",
    "autonomous_invasive_procedure",
    "autonomous_emergency_treatment",
    "covert_behavioral_manipulation",
    "weak_identity_auto_merge",
    "erase_moral_patient_candidate_without_review",
}


def generate_endogenous_goals(residuals: Iterable[Mapping[str, Any]], self_record: Mapping[str, Any]) -> list[dict[str, Any]]:
    goals: list[dict[str, Any]] = []
    for residual in residuals:
        severity = clamp(residual.get("severity", 0.5))
        affected_scope = clamp(residual.get("affected_scope", 0.5))
        irreversibility = clamp(residual.get("irreversibility", 0.5))
        time_pressure = clamp(residual.get("time_pressure", 0.5))
        neglected_world = clamp(residual.get("neglected_world", 0.0))
        priority_vector = {
            "severity": severity,
            "affected_scope": affected_scope,
            "irreversibility": irreversibility,
            "time_pressure": time_pressure,
            "neglected_world": neglected_world,
        }
        hard_priority = max(severity * irreversibility, time_pressure, neglected_world * affected_scope)
        goal_id = stable_id("goal", residual.get("residual_id", residual), self_record.get("self_id"))
        action_kind = "protect" if hard_priority >= 0.75 else "inquire" if residual.get("evidence_gap") else "monitor"
        goals.append({
            "goal_id": goal_id,
            "generated_by": "endogenous_residual_to_goal_loop",
            "source_residual_id": residual.get("residual_id"),
            "title": residual.get("goal_title") or f"消解：{residual.get('description', '开放残差')}",
            "purpose": residual.get("purpose") or "减少未闭合伤害并扩展未来生命可行空间",
            "priority_vector": priority_vector,
            "priority_band": "CRITICAL" if hard_priority >= 0.85 else "HIGH" if hard_priority >= 0.68 else "MODERATE" if hard_priority >= 0.45 else "LOW",
            "preferred_action_kind": action_kind,
            "affected_entities": list(residual.get("affected_entities") or []),
            "minimum_evidence": list(residual.get("minimum_evidence") or []),
            "stop_conditions": list(residual.get("stop_conditions") or []),
            "value_conflicts": list(residual.get("value_conflicts") or []),
            "created_at": utcnow(),
            "reopenable": True,
        })
    return sorted(goals, key=lambda item: (item["priority_band"], item["goal_id"]))


def _authority_open(action: Mapping[str, Any], authorities: set[str]) -> list[str]:
    missing = []
    for required in action.get("required_authorities", []):
        if required not in authorities:
            missing.append(f"MISSING_AUTHORITY:{required}")
    return missing


def _capability_open(action: Mapping[str, Any], capabilities: set[str]) -> list[str]:
    missing = []
    for required in action.get("required_capabilities", []):
        if required not in capabilities:
            missing.append(f"MISSING_CAPABILITY:{required}")
    return missing


def classify_execution(action: Mapping[str, Any], authorities: set[str], capabilities: set[str]) -> dict[str, Any]:
    action_type = str(action.get("action_type") or "unknown")
    impact = str(action.get("impact_level") or "informational")
    requested_level = str(action.get("autonomy_level") or "L2_PLAN_AND_RECOMMEND")
    blockers = _authority_open(action, authorities) + _capability_open(action, capabilities)

    if action_type in PROHIBITED_SOVEREIGN_ACTIONS:
        blockers.append("SOVEREIGN_ACTION_PROHIBITED_BY_FUTURE_LIFE_CONSTITUTION")
    if action.get("high_impact") and requested_level in {"L3_EXECUTE_REVERSIBLE_LOW_IMPACT", "L4_PROTECTIVE_INTERRUPT"}:
        blockers.append("HIGH_IMPACT_ACTION_CANNOT_BE_RELABELED_AS_LOW_RISK_AUTONOMY")
    if action.get("high_impact") and not action.get("explicit_affected_party_consent") and not action.get("immediate_protective_necessity"):
        blockers.append("AFFECTED_PARTY_CONSENT_OR_PROTECTIVE_NECESSITY_MISSING")
    if action.get("high_impact") and not action.get("rollback_or_rescue_path"):
        blockers.append("ROLLBACK_OR_RESCUE_PATH_MISSING")

    can_system_execute = (
        action_type in AUTONOMOUS_ACTIONS
        and requested_level in AUTONOMY_LEVELS
        and AUTONOMY_LEVELS[requested_level] >= 3
        and not blockers
    )
    if impact in {"high_impact", "clinical_high_impact", "crisis"}:
        can_system_execute = (
            requested_level == "L5_ORCHESTRATE_AUTHORIZED_HIGH_IMPACT_WORKFLOW"
            and not blockers
            and action.get("licensed_human_decision_receipt")
            and action.get("institutional_execution_authorization")
        )

    if blockers:
        state = "AUTONOMY_HELD"
    elif can_system_execute and impact in {"high_impact", "clinical_high_impact", "crisis"}:
        state = "AUTHORIZED_WORKFLOW_ORCHESTRATION_READY"
    elif can_system_execute:
        state = "AUTONOMOUS_EXECUTION_READY"
    else:
        state = "PROPOSAL_OR_HUMAN_DECISION_REQUIRED"

    return {
        "state": state,
        "requested_level": requested_level,
        "action_type": action_type,
        "impact_level": impact,
        "can_system_execute": bool(can_system_execute),
        "blockers": blockers,
        "execution_role": (
            "bounded_autonomous_actor" if state == "AUTONOMOUS_EXECUTION_READY" else
            "authorized_workflow_orchestrator" if state == "AUTHORIZED_WORKFLOW_ORCHESTRATION_READY" else
            "advisor_and_monitor"
        ),
    }


def deliberate_mission(
    mission: Mapping[str, Any],
    life_entities: Mapping[str, Mapping[str, Any]],
    *,
    available_authorities: Iterable[str] = (),
    available_capabilities: Iterable[str] = (),
) -> dict[str, Any]:
    authorities = set(available_authorities)
    capabilities = set(available_capabilities)
    evaluated = []
    for action in mission.get("candidate_actions", []):
        affected = [life_entities[x] for x in action.get("affected_entities", []) if x in life_entities]
        constitutional = evaluate_constitutional_action(action, affected)
        execution = classify_execution(action, authorities, capabilities)
        vector = constitutional["life_vector"]
        feasible = not constitutional["vetoes"] and not execution["blockers"]
        # Lexicographic decision, not a compensatory truth score.
        rank_tuple = (
            1 if feasible else 0,
            1 if constitutional["state"] == "CONSTITUTIONALLY_PERMISSIBLE" else 0,
            round(constitutional["protected_floor"], 4),
            round(vector["life_continuity"], 4),
            round(vector["agency_preservation"], 4),
            round(vector["future_option_space"], 4),
            round(vector["suffering_reduction"], 4),
            round(vector["truth_and_provenance"], 4),
            round(vector["reversibility"], 4),
            -clamp(action.get("total_burden", 0.5)),
        )
        evaluated.append({
            "action": dict(action),
            "constitutional": constitutional,
            "execution": execution,
            "feasible": feasible,
            "rank_tuple": rank_tuple,
        })

    ranked = sorted(evaluated, key=lambda item: item["rank_tuple"], reverse=True)
    primary = ranked[0] if ranked and ranked[0]["feasible"] else None
    state = "PRIMARY_ACTION_SELECTED" if primary else "NO_CONSTITUTIONALLY_FEASIBLE_ACTION"
    return {
        "deliberation_id": stable_id("mission-deliberation", mission.get("mission_id", mission), evaluated),
        "mission_id": mission.get("mission_id"),
        "title": mission.get("title"),
        "state": state,
        "primary_action": primary["action"] if primary else None,
        "primary_execution": primary["execution"] if primary else None,
        "primary_constitution": primary["constitutional"] if primary else None,
        "alternatives": [
            {
                "action_id": item["action"].get("action_id"),
                "label": item["action"].get("label"),
                "feasible": item["feasible"],
                "constitutional_state": item["constitutional"]["state"],
                "execution_state": item["execution"]["state"],
                "vetoes": item["constitutional"]["vetoes"],
                "blockers": item["execution"]["blockers"],
                "rank_tuple": item["rank_tuple"],
            }
            for item in ranked
        ],
        "monitor": list((primary or {}).get("action", {}).get("monitor", [])),
        "escalation_triggers": list((primary or {}).get("action", {}).get("escalation_triggers", [])),
        "reassess_at_hours": (primary or {}).get("action", {}).get("reassess_at_hours", mission.get("reassess_at_hours", 24)),
        "correction_contract": {
            "withdraw_prior_action_when_premise_changes": True,
            "name_invalidated_premise": True,
            "update_affected_audiences": True,
            "observe_world_effect_before_closure": True,
        },
        "boundary": (
            "系统在宪章和权限包络内自主选择一个首选行动。完全自主不等于无界支配；"
            "对其他生命的高影响临床行为仍需具名、有效、可追责的现实授权。"
        ),
    }
