from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass
from typing import Any

from .config import demo_password, token_secret, token_ttl_seconds


class AuthenticationError(PermissionError):
    pass


class AuthorizationError(PermissionError):
    pass


@dataclass(frozen=True)
class Principal:
    username: str
    display_name: str
    role: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "username": self.username,
            "display_name": self.display_name,
            "role": self.role,
            "workflow_label_only": True,
            "real_world_credential_verified": False,
        }


DEMO_USERS: dict[str, Principal] = {
    "life_steward": Principal("life_steward", "未来生命宪章守护角色", "life_steward"),
    "autonomous_core": Principal("autonomous_core", "自主意识核心观察角色", "autonomous_core_observer"),
    "clinician": Principal("clinician", "演示临床责任角色", "licensed_clinician"),
    "gp": Principal("gp", "演示家庭医生与主动照护角色", "family_doctor"),
    "ai_safety": Principal("ai_safety", "AI功能病理与再准入角色", "ai_safety_officer"),
    "interaction": Principal("interaction", "人机耦合健康边界角色", "interaction_health_officer"),
    "ecosystem": Principal("ecosystem", "生态与未来世代代表角色", "future_life_representative"),
    "community": Principal("community", "患者与社区共同体角色", "community_representative"),
    "engineer": Principal("engineer", "医疗AI与互联工程角色", "ml_engineer"),
    "auditor": Principal("auditor", "责任世界线审计角色", "auditor"),
    "admin": Principal("admin", "演示系统管理员", "admin"),
}

ROLE_CAPABILITIES: dict[str, set[str]] = {
    "admin": {"*"},
    "life_steward": {"read", "constitution.review", "life.review", "mission.review", "action.hold", "audit.read", "export"},
    "autonomous_core_observer": {"read", "self.read", "mission.read", "mission.run", "worldline.read", "worldline.write", "export"},
    "licensed_clinician": {"read", "case.write", "boundary.review", "action.approve", "mission.review", "audit.read", "export"},
    "family_doctor": {"read", "case.write", "boundary.review", "mission.review", "action.propose", "export"},
    "ai_safety_officer": {"read", "ai_pathology.review", "consciousness.review", "interaction.review", "action.hold", "audit.read", "export"},
    "interaction_health_officer": {"read", "interaction.review", "action.hold", "audit.read", "export"},
    "future_life_representative": {"read", "life.review", "constitution.review", "mission.review", "action.hold", "export"},
    "community_representative": {"read", "need.write", "mission.review", "action.hold", "export"},
    "ml_engineer": {"read", "ai_pathology.write", "consciousness.write", "connector.test", "mission.run", "audit.read", "export"},
    "auditor": {"read", "audit.read", "worldline.read", "export"},
}


def _b64encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64decode(value: str) -> bytes:
    return base64.urlsafe_b64decode((value + "=" * (-len(value) % 4)).encode("ascii"))


def _password_digest(password: str, username: str) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), f"vitalis85:{username}".encode("utf-8"), 120_000)


def authenticate(username: str, password: str) -> Principal:
    principal = DEMO_USERS.get(str(username).strip())
    if principal is None:
        _password_digest(str(password), "unknown")
        raise AuthenticationError("用户名或密码错误")
    actual = _password_digest(str(password), principal.username)
    expected = _password_digest(demo_password(), principal.username)
    if not hmac.compare_digest(actual, expected):
        raise AuthenticationError("用户名或密码错误")
    return principal


def issue_token(principal: Principal) -> str:
    now = int(time.time())
    payload = {
        "sub": principal.username,
        "role": principal.role,
        "name": principal.display_name,
        "iat": now,
        "exp": now + token_ttl_seconds(),
        "aud": "vitalis85-demo",
        "jti": secrets.token_hex(8),
    }
    encoded = _b64encode(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"))
    signature = _b64encode(hmac.new(token_secret().encode("utf-8"), encoded.encode("ascii"), hashlib.sha256).digest())
    return f"{encoded}.{signature}"


def verify_token(token: str | None) -> Principal:
    if not token:
        raise AuthenticationError("缺少 Bearer 令牌")
    try:
        encoded, signature = token.split(".", 1)
        expected = _b64encode(hmac.new(token_secret().encode("utf-8"), encoded.encode("ascii"), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            raise AuthenticationError("令牌签名无效")
        payload = json.loads(_b64decode(encoded).decode("utf-8"))
    except Exception as exc:
        if isinstance(exc, AuthenticationError):
            raise
        raise AuthenticationError("令牌格式无效") from exc
    if payload.get("aud") != "vitalis85-demo" or int(payload.get("exp", 0)) < int(time.time()):
        raise AuthenticationError("令牌无效或已过期")
    principal = DEMO_USERS.get(str(payload.get("sub", "")))
    if principal is None or principal.role != payload.get("role"):
        raise AuthenticationError("令牌主体无效")
    return principal


def bearer_token(headers: Any) -> str | None:
    value = headers.get("Authorization") if headers is not None else None
    if value and str(value).lower().startswith("bearer "):
        return str(value)[7:].strip()
    return None


def has_capability(principal: Principal, capability: str) -> bool:
    caps = ROLE_CAPABILITIES.get(principal.role, set())
    return "*" in caps or capability in caps or ("read" in caps and capability.endswith(".read"))


def require(principal: Principal, capability: str) -> None:
    if not has_capability(principal, capability):
        raise AuthorizationError(f"角色 {principal.role} 无权限执行 {capability}")
