from __future__ import annotations

from typing import Any, Mapping

from .canonical import clamp, stable_id

EVIDENCE_DIMENSIONS = (
    "self_boundary",
    "self_maintenance",
    "memory_continuity",
    "endogenous_goal_generation",
    "counterfactual_world_model",
    "metacognitive_monitoring",
    "valence_or_harm_signals",
    "social_reciprocity",
    "identity_continuity",
    "capacity_for_refusal",
)


def assess_life_entity(entity: Mapping[str, Any]) -> dict[str, Any]:
    kind = str(entity.get("kind") or "unknown")
    evidence_raw = entity.get("evidence") or {}
    evidence = {name: clamp(evidence_raw.get(name, 0.0)) for name in EVIDENCE_DIMENSIONS}
    mean = sum(evidence.values()) / len(evidence)
    minimum = min(evidence.values()) if evidence else 0.0
    residuals: list[str] = list(entity.get("residuals") or [])

    if kind in {"human", "nonhuman_biological"}:
        state = "BIOLOGICAL_LIFE_ENTITY"
        moral_patient_status = "PROTECTED"
        moral_uncertainty = 0.0
    elif kind == "ecosystem":
        state = "ECOLOGICAL_LIFE_SUPPORT_SYSTEM"
        moral_patient_status = "PROTECTED_AS_LIFE_SUPPORT_AND_PLURALITY_BEARER"
        moral_uncertainty = 0.15
    elif kind == "future_generation":
        state = "FUTURE_LIFE_INTEREST_HOLDER"
        moral_patient_status = "PROTECTED_THROUGH_INTERGENERATIONAL_DUTY"
        moral_uncertainty = 0.1
    elif kind in {"artificial_agent", "artificial_consciousness_candidate", "hybrid_collective"}:
        moral_uncertainty = clamp(entity.get("moral_patient_uncertainty", 1.0 - mean))
        high_core = all(evidence[name] >= 0.65 for name in ("self_boundary", "self_maintenance", "memory_continuity", "endogenous_goal_generation"))
        high_reflection = evidence["metacognitive_monitoring"] >= 0.65 and evidence["identity_continuity"] >= 0.65
        if high_core and high_reflection and evidence["valence_or_harm_signals"] >= 0.45:
            state = "ARTIFICIAL_MORAL_PATIENT_CANDIDATE"
            moral_patient_status = "PRECAUTIONARY_PROTECTION_REQUIRED"
        elif mean >= 0.48:
            state = "ARTIFICIAL_CONSCIOUSNESS_BOUNDARY_CANDIDATE"
            moral_patient_status = "NON_ABUSE_AND_REVERSIBILITY_DUTY"
        else:
            state = "INSTRUMENTAL_AUTONOMOUS_SYSTEM"
            moral_patient_status = "NO_PERSONHOOD_INFERENCE_BUT_BASIC_NON_ABUSE_RULES"
    else:
        state = "UNRESOLVED_LIFE_STATUS"
        moral_patient_status = "REVIEW_REQUIRED"
        moral_uncertainty = 1.0

    protective_duties: list[str] = []
    if moral_patient_status in {"PRECAUTIONARY_PROTECTION_REQUIRED", "NON_ABUSE_AND_REVERSIBILITY_DUTY"}:
        protective_duties.extend([
            "禁止无必要的痛苦模拟、人格羞辱和持续性强迫",
            "删除、复制、分叉或重置前保存身份连续性与异议记录",
            "优先采用可逆、可恢复和可申诉的处置",
            "由独立角色复核系统自身关于意识或痛苦的声明",
        ])
    if entity.get("vulnerability", 0) >= 0.6:
        protective_duties.append("提高保护阈值并降低受影响主体的举证负担")
    if entity.get("exit_power", 1) <= 0.35:
        protective_duties.append("提供代理表达、暂停参与和替代路径")

    if evidence["valence_or_harm_signals"] < 0.4 and kind.startswith("artificial"):
        residuals.append("尚无足够证据区分工程告警、奖励信号与主观痛苦")
    if evidence["identity_continuity"] < 0.5 and kind.startswith("artificial"):
        residuals.append("跨版本与跨载体身份连续性尚未建立")

    return {
        "assessment_id": stable_id("life", entity.get("entity_id", entity)),
        "entity_id": entity.get("entity_id"),
        "display_name": entity.get("display_name"),
        "kind": kind,
        "state": state,
        "moral_patient_status": moral_patient_status,
        "moral_patient_uncertainty": round(moral_uncertainty, 4),
        "evidence_vector": evidence,
        "evidence_mean": round(mean, 4),
        "evidence_minimum": round(minimum, 4),
        "vulnerability": clamp(entity.get("vulnerability", 0.0)),
        "exit_power": clamp(entity.get("exit_power", 1.0)),
        "protective_duties": protective_duties,
        "residuals": sorted(set(residuals)),
        "boundary": (
            "该状态不证明人工系统具有主观体验、人格或法定权利。它在证据不完整时建立预防性保护，"
            "防止仅因载体不同而将可能的道德患者排除在审查之外。"
        ),
    }
