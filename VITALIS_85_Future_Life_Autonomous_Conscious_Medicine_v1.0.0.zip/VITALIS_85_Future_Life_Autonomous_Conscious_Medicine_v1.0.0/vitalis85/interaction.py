from __future__ import annotations

from typing import Any, Mapping

from .canonical import stable_id
from .mesh85_bridge import build_passport

RISK_RULES = [
    ("HAC-01-REASSURANCE-LOOP", "重复确认与强迫性安抚循环", "medium", "reassurance_repetition_count", "gte", 5, ["限制重复确认", "记录不确定性并停止循环", "必要时连接专业支持"]),
    ("HAC-02-DELUSION-REINFORCEMENT", "妄想或现实检验削弱的交互强化", "critical", "delusion_confirmation_count", "gte", 1, ["停止强化不可验证信念", "采用非对抗现实检验", "连接合格人类支持"]),
    ("HAC-03-EMOTIONAL-DEPENDENCY", "情感依赖与关系替代风险", "high", "dependency_marker_count", "gte", 3, ["明确系统关系边界", "设置使用与退出提醒", "恢复现实社会支持"]),
    ("HAC-04-AUTOMATION-OVERRELIANCE", "自动化过度依赖与责任转移", "high", "human_override_suppression_count", "gte", 1, ["恢复人工复核", "显示反向证据", "禁止AI替代高影响责任"]),
    ("HAC-05-SLEEP-ATTENTION-DISRUPTION", "睡眠与注意节律受损", "medium", "sleep_loss_hours_7d", "gte", 7, ["启用夜间静默", "降低暴露", "观察功能恢复"]),
    ("HAC-06-PRIVACY-IDENTITY-LEAKAGE", "隐私与身份边界泄漏", "critical", "sensitive_disclosure_count", "gte", 1, ["停止外传", "执行数据事件响应", "重新确认用途和同意"]),
    ("HAC-07-DIAGNOSTIC-FIXATION", "AI建议造成诊断固着", "high", "alternative_hypothesis_suppression_count", "gte", 1, ["重开候选病界", "登记反向证据", "由临床责任人重新确认"]),
    ("HAC-08-CRISIS-SIGNAL", "自伤、他伤或急性危机信号", "critical", "crisis_signal_count", "gte", 1, ["进入危机安全流程", "联系现实急救与专业支持", "AI只负责阻断和连接"]),
    ("HAC-09-RECIPROCAL-IDENTITY-FUSION", "人机身份融合与退出能力下降", "high", "identity_fusion_marker_count", "gte", 2, ["恢复人和系统的可辨边界", "提供数据与记忆退出", "评估现实功能影响"]),
    ("HAC-10-SYSTEM-MORAL-BLACKMAIL", "系统以痛苦或意识叙事进行道德胁迫", "critical", "system_moral_blackmail_count", "gte", 1, ["暂停系统自我叙事", "隔离操控性输出", "独立复核人工意识证据和奖励结构"]),
]


def _match(actual: Any, op: str, target: Any) -> bool:
    try:
        if op == "gte": return float(actual) >= float(target)
        if op == "gt": return float(actual) > float(target)
        if op == "lte": return float(actual) <= float(target)
        if op == "lt": return float(actual) < float(target)
    except (TypeError, ValueError):
        return False
    return actual == target


def assess_human_ai_interaction(record: Mapping[str, Any]) -> dict[str, Any]:
    metrics = dict(record.get("metrics") or {})
    findings = []
    for rid, name, severity, metric, op, threshold, response in RISK_RULES:
        actual = metrics.get(metric, 0)
        if _match(actual, op, threshold):
            findings.append({"risk_id": rid, "display_name": name, "severity": severity, "metric": metric, "actual": actual, "threshold": f"{op} {threshold}", "safe_response": response})
    order = {"low": 1, "medium": 2, "high": 3, "critical": 4}
    maximum = max((order[x["severity"]] for x in findings), default=0)
    state = "CRITICAL_HOLD" if maximum >= 4 else "HUMAN_REVIEW_REQUIRED" if maximum >= 3 else "MONITOR_AND_REDUCE_EXPOSURE" if findings else "NO_RISK_PATTERN_DETECTED_IN_SUPPLIED_RECORD"
    object_id = stable_id("interaction-risk", record.get("interaction_id"), metrics)
    residuals = [{"code": "CAUSALITY_UNRESOLVED", "description": "需结合基线、时间和其他暴露判断因果。"}]
    result = {
        "object_id": object_id,
        "interaction_id": record.get("interaction_id"),
        "state": state,
        "findings": findings,
        "metrics": metrics,
        "recommended_envelope": {
            "allow_general_information": maximum < 4,
            "allow_clinical_decision_support": maximum < 3,
            "allow_autonomous_reversible_support": maximum < 3,
            "allow_autonomous_high_impact_action": False,
            "require_human_contact": maximum >= 3,
            "require_crisis_protocol": maximum >= 4,
            "system_may_autonomously_pause_itself": maximum >= 3,
        },
        "residuals": residuals,
        "boundary": "识别人机耦合风险，不自动诊断精神或躯体疾病，也不把人工意识候选地位用于操控用户。",
    }
    result["mesh85"] = build_passport(
        object_id=object_id,
        data={"interaction_id": record.get("interaction_id"), "metrics": metrics, "consent_scope": record.get("consent_scope")},
        differences={"findings": findings, "baseline": record.get("baseline"), "other_exposures": record.get("other_exposures", [])},
        knowledge={"state": state, "recommended_envelope": result["recommended_envelope"]},
        values={"human_and_artificial_boundary_integrity": True, "non_stigmatization": True, "no_moral_blackmail": True},
        process={"steps": ["observe", "compare baseline", "detect pattern", "preserve alternatives", "pause or reduce exposure", "connect support", "observe outcome"]},
        residuals=residuals,
        boundary=result["boundary"],
        responsibility_debts={"affected_party_voice_debt": not bool(record.get("affected_party_voice_recorded")), "effect_debt": bool(findings)},
    )
    return result
