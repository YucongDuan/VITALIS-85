from __future__ import annotations

import os
import socket
import socketserver
from datetime import datetime, timezone

from .engine import MEDCommonsEngine
from .protocols import InterfaceValidationError, hl7_ack, parse_hl7_v2

MLLP_START = b"\x0b"
MLLP_END = b"\x1c\x0d"
DEFAULT_MAX_FRAME_BYTES = 4 * 1024 * 1024


def allowed_mllp_ips() -> set[str]:
    return {item.strip() for item in os.environ.get("MEDCOMMONS81_MLLP_ALLOWED_IPS", "127.0.0.1,::1").split(",") if item.strip()}


def decode_hl7_frame(raw: bytes) -> str:
    for encoding in ("utf-8", "gb18030"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise InterfaceValidationError("MLLP frame must be UTF-8 or GB18030 text")


def error_ack(control_id: str, message: str) -> str:
    safe = str(message).replace("\r", " ").replace("\n", " ").replace("|", "/")[:240]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return (
        f"MSH|^~\\&|MEDCOMMONS81|OPEN-COMMONS|SOURCE|INSTITUTION|{stamp}||ACK|ACK-ERROR|P|2.5\r"
        f"MSA|AE|{control_id or 'UNKNOWN'}|{safe}\r"
    )


class MLLPRequestHandler(socketserver.BaseRequestHandler):
    engine: MEDCommonsEngine
    max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES

    def handle(self) -> None:
        client_ip = str(self.client_address[0])
        if client_ip not in allowed_mllp_ips():
            return
        self.request.settimeout(float(os.environ.get("MEDCOMMONS81_MLLP_TIMEOUT_SECONDS", "15")))
        buffer = bytearray()
        while True:
            try:
                chunk = self.request.recv(65536)
            except socket.timeout:
                return
            if not chunk:
                return
            buffer.extend(chunk)
            if len(buffer) > self.max_frame_bytes + len(MLLP_START) + len(MLLP_END):
                self.request.sendall(MLLP_START + error_ack("", "message exceeds configured maximum").encode("utf-8") + MLLP_END)
                return
            while True:
                start = buffer.find(MLLP_START)
                end = buffer.find(MLLP_END, start + 1 if start >= 0 else 0)
                if start < 0 or end < 0:
                    break
                frame = bytes(buffer[start + 1:end])
                del buffer[: end + len(MLLP_END)]
                self._process_frame(frame, client_ip)

    def _process_frame(self, frame: bytes, client_ip: str) -> None:
        control_id = ""
        try:
            text = decode_hl7_frame(frame)
            result = parse_hl7_v2(text)
            control_id = result.external_id
            source = str(result.normalized.get("sending_application") or "HL7-MLLP")
            facility = str(result.normalized.get("sending_facility") or "").strip()
            source_system = f"{source}@{facility}" if facility else source
            self.engine._stage_protocol_result(result, actor=f"mllp:{client_ip}", source_system=source_system)
            ack = hl7_ack(result)
        except Exception as exc:
            ack = error_ack(control_id, str(exc))
        self.request.sendall(MLLP_START + ack.encode("utf-8") + MLLP_END)


class ThreadingMLLPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def build_mllp_server(host: str, port: int, engine: MEDCommonsEngine) -> ThreadingMLLPServer:
    class BoundMLLPHandler(MLLPRequestHandler):
        pass

    BoundMLLPHandler.engine = engine
    max_bytes = os.environ.get("MEDCOMMONS81_MLLP_MAX_FRAME_BYTES")
    if max_bytes:
        BoundMLLPHandler.max_frame_bytes = max(1024, min(int(max_bytes), 32 * 1024 * 1024))
    return ThreadingMLLPServer((host, port), BoundMLLPHandler)
