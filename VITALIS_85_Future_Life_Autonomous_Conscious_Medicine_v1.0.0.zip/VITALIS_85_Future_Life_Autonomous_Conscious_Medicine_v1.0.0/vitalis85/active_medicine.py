from __future__ import annotations

from typing import Any, Mapping

from .canonical import clamp, stable_id

LIKELIHOOD_ORDER = {
    "VERY_LIKELY": 5,
    "LIKELY": 4,
    "POSSIBLE": 3,
    "UNLIKELY": 2,
    "VERY_UNLIKELY": 1,
    "UNRESOLVED": 0,
}


def _match(value: Any, criterion: Mapping[str, Any]) -> bool:
    op = criterion.get("op", "eq")
    target = criterion.get("value")
    try:
        if op == "gte": return float(value) >= float(target)
        if op == "gt": return float(value) > float(target)
        if op == "lte": return float(value) <= float(target)
        if op == "lt": return float(value) < float(target)
        if op == "between": return float(target[0]) <= float(value) <= float(target[1])
        if op == "in": return value in target
        if op == "contains": return str(target).lower() in str(value).lower()
        if op == "truthy": return bool(value)
        return value == target
    except (TypeError, ValueError, IndexError):
        return False


def _band(probability: float) -> str:
    if probability >= 0.8: return "VERY_LIKELY"
    if probability >= 0.62: return "LIKELY"
    if probability >= 0.35: return "POSSIBLE"
    if probability >= 0.15: return "UNLIKELY"
    return "VERY_UNLIKELY"


def assess_health_case(case: Mapping[str, Any]) -> dict[str, Any]:
    observations = {str(x.get("code")): x.get("value") for x in case.get("observations", [])}
    boundaries = []
    urgent = []
    for boundary in case.get("candidate_boundaries", []):
        prior = clamp(boundary.get("prior_midpoint", 0.35))
        logit_shift = 0.0
        support = []
        oppose = []
        missing = []
        for criterion in boundary.get("criteria", []):
            code = str(criterion.get("code"))
            weight = float(criterion.get("weight", 0.12))
            if code not in observations:
                missing.append({"code": code, "label": criterion.get("label")})
                continue
            matched = _match(observations[code], criterion)
            item = {"code": code, "label": criterion.get("label"), "value": observations[code], "weight": weight}
            if matched:
                support.append(item)
                logit_shift += weight
            else:
                oppose.append(item)
                logit_shift -= weight * float(criterion.get("opposition_factor", 0.75))
        probability = clamp(prior + logit_shift)
        red_flags = []
        for rule in boundary.get("red_flags", []):
            if rule.get("code") in observations and _match(observations[rule["code"]], rule):
                red_flags.append(rule)
                urgent.append({"boundary_id": boundary.get("boundary_id"), "red_flag": rule.get("label")})
        boundaries.append({
            "boundary_id": boundary.get("boundary_id"),
            "display_name": boundary.get("display_name"),
            "likelihood_band": _band(probability),
            "probability_range": [round(max(0.0, probability - 0.12), 2), round(min(1.0, probability + 0.12), 2)],
            "probability_midpoint": round(probability, 3),
            "severity_if_missed": boundary.get("severity_if_missed", "moderate"),
            "support": support,
            "oppose": oppose,
            "missing": missing,
            "red_flags": red_flags,
            "minimum_discriminating_evidence": boundary.get("minimum_discriminating_evidence", []),
            "management_change": boundary.get("management_change", {}),
            "age_calibration": boundary.get("age_calibration") or case.get("age_calibration"),
            "local_feasibility": boundary.get("local_feasibility", {}),
            "boundary": "候选病界用于形成主动照护决策，不是自动正式诊断。",
        })
    boundaries.sort(key=lambda x: (x["probability_midpoint"], LIKELIHOOD_ORDER[x["likelihood_band"]]), reverse=True)

    actions = []
    for action in case.get("action_options", []):
        test_value = action.get("test_value_model") or {}
        management_change = bool(test_value.get("positive_changes_action")) or bool(test_value.get("negative_changes_action"))
        burden = clamp(action.get("total_burden", 0.5))
        feasible = bool(action.get("locally_feasible", True)) and not action.get("hard_blockers")
        if action.get("kind") == "test" and not management_change and not action.get("mandatory"):
            feasible = False
            reason = "结果不能改变当前处理"
        elif not action.get("locally_feasible", True):
            reason = "当地流程或资源不可行"
        elif action.get("hard_blockers"):
            reason = "; ".join(action.get("hard_blockers"))
        else:
            reason = action.get("reason", "")
        decision_tuple = (
            1 if feasible else 0,
            1 if action.get("kind") in {"protect", "act", "observe"} else 0,
            clamp(action.get("expected_benefit", 0.5)),
            clamp(action.get("reversibility", 0.5)),
            -clamp(action.get("expected_harm", 0.5)),
            -burden,
        )
        actions.append({**dict(action), "feasible": feasible, "decision_reason": reason, "decision_tuple": decision_tuple})
    actions.sort(key=lambda x: x["decision_tuple"], reverse=True)
    primary = actions[0] if actions and actions[0]["feasible"] else None
    if urgent:
        state = "URGENT_ESCALATION_TRIGGERED"
    elif primary:
        state = "ACTIVE_PLAN_SELECTED"
    else:
        state = "PLAN_REQUIRES_MORE_CONTEXT"

    return {
        "assessment_id": stable_id("health-case", case.get("case_id", case), observations),
        "case_id": case.get("case_id"),
        "display_name": case.get("display_name"),
        "age_profile": case.get("age_profile"),
        "state": state,
        "ranked_boundaries": boundaries,
        "primary_action": primary,
        "not_recommended": [
            {"action_id": item.get("action_id"), "label": item.get("label"), "reason": item.get("decision_reason")}
            for item in actions[1:] if not item.get("feasible") or item.get("kind") == "test"
        ],
        "monitor": list((primary or {}).get("monitor", [])),
        "escalation_triggers": list((primary or {}).get("escalation_triggers", [])) + [item["red_flag"] for item in urgent],
        "reassess_at_hours": (primary or {}).get("reassess_at_hours", 24),
        "age_method_note": case.get("age_method_note"),
        "local_feasibility_note": case.get("local_feasibility_note"),
        "boundary": (
            "系统明确给出首选行动并承担检查价值与现实负担的比较，但不会把未完成的体格检查、"
            "实验室结果或执业权限伪造成已存在。"
        ),
    }
