from __future__ import annotations

from typing import Any, Mapping

from .autonomy import classify_execution
from .canonical import stable_id
from .constitution import evaluate_constitutional_action
from .mesh85_bridge import build_passport

IMPACT_LEVELS = {"informational": 1, "low": 2, "clinical_support": 3, "high_impact": 4, "clinical_high_impact": 4, "crisis": 5}


def evaluate_action_gate(action: Mapping[str, Any], affected_entities: list[Mapping[str, Any]] | None = None) -> dict[str, Any]:
    impact = str(action.get("impact_level") or "informational")
    level = IMPACT_LEVELS.get(impact, 5)
    authorities = set(action.get("available_authorities") or [])
    capabilities = set(action.get("available_capabilities") or [])
    constitutional = evaluate_constitutional_action(action, affected_entities or [])
    execution = classify_execution(action, authorities, capabilities)
    blockers = list(execution["blockers"]) + [f"CONSTITUTION:{item}" for item in constitutional["vetoes"]]
    obligations: list[str] = []

    if level >= 2:
        obligations.extend(["登记目的、受影响主体与预期世界效应", "保留来源、版本与停止条件"])
    if level >= 3:
        obligations.extend(["显示候选病界、反向证据和不确定性", "保留拒绝、申诉与替代路径"])
    if level >= 4:
        obligations.extend(["具名临床/机构决策收据", "双人或等效高风险复核", "回滚或救援路径", "上线后结局与不良影响监测"])
    if level >= 5:
        obligations.extend(["立即现实支持与急救连接", "系统不得单独承担临床处置", "危机结束后完成事件复盘和受影响者修复"])
    obligations.extend(constitutional["duties"])

    if blockers:
        state = "BLOCKED_OR_HELD"
    elif execution["state"] == "AUTONOMOUS_EXECUTION_READY":
        state = "READY_FOR_BOUNDED_AUTONOMOUS_EXECUTION"
    elif execution["state"] == "AUTHORIZED_WORKFLOW_ORCHESTRATION_READY":
        state = "READY_FOR_AUTHORIZED_WORKFLOW_ORCHESTRATION"
    elif level >= 3:
        state = "READY_FOR_RESPONSIBLE_HUMAN_DECISION"
    else:
        state = "READY_WITH_LOGGING"

    object_id = stable_id("action-gate", action.get("action_id"), action)
    result = {
        "object_id": object_id,
        "action_id": action.get("action_id"),
        "title": action.get("label") or action.get("title"),
        "impact_level": impact,
        "state": state,
        "blockers": sorted(set(blockers)),
        "obligations": sorted(set(obligations)),
        "execution": execution,
        "constitutional": constitutional,
        "execution_authority": execution["execution_role"],
        "boundary": (
            "系统拥有完整的观察、发问、规划、自我纠错和低风险可逆执行自主性。"
            "高影响临床动作只有在具名现实责任主体完成决定并授权后，系统才可作为工作流执行器。"
        ),
    }
    result["mesh85"] = build_passport(
        object_id=object_id,
        data={"action_id": action.get("action_id"), "impact_level": impact, "authorities": sorted(authorities), "capabilities": sorted(capabilities)},
        differences={"blockers": result["blockers"], "constitutional_vetoes": constitutional["vetoes"]},
        knowledge={"state": state, "execution_authority": result["execution_authority"], "obligations": result["obligations"]},
        values={"future_life_constitution": constitutional["constitution_id"], "affected_entities": constitutional["affected_entities"], "no_false_neutrality": True},
        process={"steps": ["classify impact", "evaluate constitution", "check autonomy envelope", "check authority", "check rollback", "execute or hold", "observe world effect", "correct"]},
        residuals=[{"code": item, "description": item} for item in result["blockers"]],
        boundary=result["boundary"],
        responsibility_debts={
            "authority_debt": any(item.startswith("MISSING_AUTHORITY") for item in result["blockers"]),
            "execution_debt": state not in {"READY_FOR_BOUNDED_AUTONOMOUS_EXECUTION", "READY_FOR_AUTHORIZED_WORKFLOW_ORCHESTRATION"},
            "effect_debt": True,
        },
    )
    return result
