from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Mapping

from .canonical import canonical_json, sha256_json, utcnow


class StoreError(RuntimeError):
    pass


class RevisionConflict(StoreError):
    pass


class KnowledgeStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30, isolation_level=None, check_same_thread=False)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    @contextmanager
    def connection(self):
        """Yield a configured connection and always close it.

        sqlite3.Connection's context manager commits/rolls back but does not
        guarantee closure on current Python versions.  This wrapper prevents
        descriptor accumulation in long-running ingestion and recompute jobs.
        """
        connection = self.connect()
        try:
            yield connection
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self.connection() as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS objects (
                kind TEXT NOT NULL,
                object_id TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                revision INTEGER NOT NULL,
                payload_sha256 TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY(kind, object_id)
            );
            CREATE INDEX IF NOT EXISTS idx_objects_kind ON objects(kind);
            CREATE TABLE IF NOT EXISTS audit_events (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT NOT NULL UNIQUE,
                event_type TEXT NOT NULL,
                actor TEXT NOT NULL,
                object_kind TEXT,
                object_id TEXT,
                payload_json TEXT NOT NULL,
                previous_hash TEXT NOT NULL,
                event_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            """)

    def count(self, kind: str) -> int:
        with self.connection() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM objects WHERE kind=?", (kind,)).fetchone()[0])

    def list(self, kind: str) -> list[dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute("SELECT * FROM objects WHERE kind=? ORDER BY object_id", (kind,)).fetchall()
        return [self._row(row) for row in rows]

    def get(self, kind: str, object_id: str) -> dict[str, Any]:
        with self.connection() as conn:
            row = conn.execute("SELECT * FROM objects WHERE kind=? AND object_id=?", (kind, object_id)).fetchone()
        if row is None:
            raise KeyError(f"{kind}/{object_id}")
        return self._row(row)

    def upsert(self, kind: str, object_id: str, payload: Mapping[str, Any], *, actor: str, expected_revision: int | None = None, event_type: str = "object.upsert") -> dict[str, Any]:
        now = utcnow()
        payload_dict = dict(payload)
        payload_json = canonical_json(payload_dict)
        payload_hash = sha256_json(payload_dict)
        with self._lock, self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT revision, created_at FROM objects WHERE kind=? AND object_id=?", (kind, object_id)).fetchone()
            current_revision = int(row["revision"]) if row else 0
            if expected_revision is not None and expected_revision != current_revision:
                conn.execute("ROLLBACK")
                raise RevisionConflict(f"expected revision {expected_revision}, current {current_revision}")
            revision = current_revision + 1
            created_at = row["created_at"] if row else now
            conn.execute(
                "INSERT INTO objects(kind, object_id, payload_json, revision, payload_sha256, created_at, updated_at) VALUES(?,?,?,?,?,?,?) "
                "ON CONFLICT(kind,object_id) DO UPDATE SET payload_json=excluded.payload_json, revision=excluded.revision, payload_sha256=excluded.payload_sha256, updated_at=excluded.updated_at",
                (kind, object_id, payload_json, revision, payload_hash, created_at, now),
            )
            self._append_audit(conn, event_type, actor, kind, object_id, {"revision": revision, "payload_sha256": payload_hash})
            conn.execute("COMMIT")
        return self.get(kind, object_id)

    def replace_kind(self, kind: str, records: Iterable[Mapping[str, Any]], *, id_field: str, actor: str, event_type: str = "analysis.replace") -> int:
        records_list = [dict(record) for record in records]
        with self._lock, self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("DELETE FROM objects WHERE kind=?", (kind,))
            now = utcnow()
            for record in records_list:
                object_id = str(record[id_field])
                payload_json = canonical_json(record)
                payload_hash = sha256_json(record)
                conn.execute(
                    "INSERT INTO objects(kind, object_id, payload_json, revision, payload_sha256, created_at, updated_at) VALUES(?,?,?,?,?,?,?)",
                    (kind, object_id, payload_json, 1, payload_hash, now, now),
                )
            self._append_audit(conn, event_type, actor, kind, "*", {"record_count": len(records_list)})
            conn.execute("COMMIT")
        return len(records_list)

    def delete_all(self, *, actor: str) -> None:
        with self._lock, self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("DELETE FROM objects")
            conn.execute("DELETE FROM audit_events")
            conn.execute("DELETE FROM sqlite_sequence WHERE name='audit_events'")
            conn.execute("COMMIT")
        self.append_audit("demo.reset", actor, None, None, {})

    def append_audit(self, event_type: str, actor: str, object_kind: str | None, object_id: str | None, payload: Mapping[str, Any]) -> dict[str, Any]:
        with self._lock, self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            event = self._append_audit(conn, event_type, actor, object_kind, object_id, payload)
            conn.execute("COMMIT")
        return event

    def _append_audit(self, conn: sqlite3.Connection, event_type: str, actor: str, object_kind: str | None, object_id: str | None, payload: Mapping[str, Any]) -> dict[str, Any]:
        previous_row = conn.execute("SELECT event_hash FROM audit_events ORDER BY sequence DESC LIMIT 1").fetchone()
        previous_hash = previous_row["event_hash"] if previous_row else "0" * 64
        created_at = utcnow()
        event_payload = {
            "event_type": event_type,
            "actor": actor,
            "object_kind": object_kind,
            "object_id": object_id,
            "payload": dict(payload),
            "previous_hash": previous_hash,
            "created_at": created_at,
        }
        event_hash = hashlib.sha256(canonical_json(event_payload).encode("utf-8")).hexdigest()
        event_id = f"audit-{event_hash[:18]}"
        conn.execute(
            "INSERT INTO audit_events(event_id,event_type,actor,object_kind,object_id,payload_json,previous_hash,event_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (event_id, event_type, actor, object_kind, object_id, canonical_json(payload), previous_hash, event_hash, created_at),
        )
        return {**event_payload, "event_id": event_id, "event_hash": event_hash}

    def audit(self, limit: int = 500) -> list[dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute("SELECT * FROM audit_events ORDER BY sequence DESC LIMIT ?", (limit,)).fetchall()
        return [{
            "sequence": row["sequence"],
            "event_id": row["event_id"],
            "event_type": row["event_type"],
            "actor": row["actor"],
            "object_kind": row["object_kind"],
            "object_id": row["object_id"],
            "payload": json.loads(row["payload_json"]),
            "previous_hash": row["previous_hash"],
            "event_hash": row["event_hash"],
            "created_at": row["created_at"],
        } for row in rows]

    def verify_audit(self) -> dict[str, Any]:
        with self.connection() as conn:
            rows = conn.execute("SELECT * FROM audit_events ORDER BY sequence").fetchall()
        previous_hash = "0" * 64
        errors = []
        for row in rows:
            payload = json.loads(row["payload_json"])
            event_payload = {
                "event_type": row["event_type"],
                "actor": row["actor"],
                "object_kind": row["object_kind"],
                "object_id": row["object_id"],
                "payload": payload,
                "previous_hash": row["previous_hash"],
                "created_at": row["created_at"],
            }
            expected_hash = hashlib.sha256(canonical_json(event_payload).encode("utf-8")).hexdigest()
            if row["previous_hash"] != previous_hash:
                errors.append({"sequence": row["sequence"], "code": "PREVIOUS_HASH_MISMATCH"})
            if row["event_hash"] != expected_hash:
                errors.append({"sequence": row["sequence"], "code": "EVENT_HASH_MISMATCH"})
            previous_hash = row["event_hash"]
        return {"valid": not errors, "event_count": len(rows), "errors": errors, "head_hash": previous_hash}

    def set_meta(self, key: str, value: Any) -> None:
        with self.connection() as conn:
            conn.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, canonical_json(value)))

    def get_meta(self, key: str, default: Any = None) -> Any:
        with self.connection() as conn:
            row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return json.loads(row["value"]) if row else default

    @staticmethod
    def _row(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "kind": row["kind"],
            "object_id": row["object_id"],
            "payload": json.loads(row["payload_json"]),
            "revision": int(row["revision"]),
            "payload_sha256": row["payload_sha256"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }
