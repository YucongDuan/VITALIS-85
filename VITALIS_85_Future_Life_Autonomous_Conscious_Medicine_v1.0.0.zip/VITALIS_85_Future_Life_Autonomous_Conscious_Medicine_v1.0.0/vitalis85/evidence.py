from __future__ import annotations

from collections import defaultdict
from typing import Any, Iterable, Mapping

from .canonical import ensure_list, jaccard, normalize_compact, stable_id
from .mesh85_bridge import build_passport


def _claim_key(claim: Mapping[str, Any]) -> str:
    return normalize_compact(claim.get("semantic_key") or claim.get("statement") or "")


def _cluster_claims(claims: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    clusters: list[list[dict[str, Any]]] = []
    for claim in claims:
        key = _claim_key(claim)
        assigned = False
        for cluster in clusters:
            anchor = cluster[0]
            if (key and key == _claim_key(anchor)) or jaccard(claim.get("statement"), anchor.get("statement")) >= 0.72:
                cluster.append(claim)
                assigned = True
                break
        if not assigned:
            clusters.append([claim])
    return clusters


def _independence(sources: list[Mapping[str, Any]]) -> dict[str, Any]:
    author_sets = [set(map(str, ensure_list(s.get("authors")))) for s in sources]
    institution_sets = [set(map(str, ensure_list(s.get("institutions")))) for s in sources]
    data_ids = [str(s.get("data_id") or "") for s in sources]
    pairs = 0
    independent = 0
    for i in range(len(sources)):
        for j in range(i + 1, len(sources)):
            pairs += 1
            ok = not (author_sets[i] & author_sets[j]) and not (institution_sets[i] & institution_sets[j])
            if data_ids[i] and data_ids[i] == data_ids[j]:
                ok = False
            if ok:
                independent += 1
    return {
        "source_count": len(sources),
        "independent_pair_count": independent,
        "pair_count": pairs,
        "has_independent_replication": independent > 0,
        "unique_institutions": len(set().union(*institution_sets)) if institution_sets else 0,
        "unique_countries": len({str(s.get("country") or "unknown") for s in sources}),
        "shared_data_detected": len([x for x in data_ids if x]) != len(set(x for x in data_ids if x)),
    }


def build_evidence_cells(sources: Iterable[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    source_list = [dict(item) for item in sources]
    source_map = {str(item["source_id"]): item for item in source_list}
    claims = []
    for source in source_list:
        for index, claim in enumerate(ensure_list(source.get("claims"))):
            if not isinstance(claim, Mapping) or not claim.get("statement"):
                continue
            item = dict(claim)
            item.setdefault("claim_id", stable_id("claim", source["source_id"], index, item.get("statement")))
            item["source_id"] = source["source_id"]
            item.setdefault("relation", "supports")
            claims.append(item)
    cells: list[dict[str, Any]] = []
    for cluster in _cluster_claims(claims):
        source_ids = sorted({str(c["source_id"]) for c in cluster})
        cell_sources = [source_map[sid] for sid in source_ids]
        supports = [c for c in cluster if c.get("relation") in {"supports", "reports", "qualifies"}]
        contradicts = [c for c in cluster if c.get("relation") in {"contradicts", "does_not_support"}]
        updates = [u for s in cell_sources for u in ensure_list(s.get("updates")) if isinstance(u, Mapping)]
        integrity_signals = [sig for s in cell_sources for sig in ensure_list(s.get("integrity_signals")) if isinstance(sig, Mapping)]
        independence = _independence(cell_sources)
        retracted = any("retract" in str(u.get("type") or "").lower() for u in updates)
        critical = any(sig.get("severity") == "critical" for sig in integrity_signals)
        if retracted or critical:
            status = "RETRACTED_OR_QUARANTINED"
        elif contradicts:
            status = "CONTESTED"
        elif independence["has_independent_replication"] and len(supports) >= 2:
            status = "INDEPENDENTLY_SUPPORTED"
        elif len(source_ids) >= 2:
            status = "CONVERGENT_BUT_DEPENDENT"
        else:
            status = "SINGLE_SOURCE_BOUNDARY"
        statement = max([str(c.get("statement") or "") for c in supports or cluster], key=len)
        residuals = []
        if not independence["has_independent_replication"]:
            residuals.append({"code": "INDEPENDENCE_GAP", "description": "尚无可确认的独立复现。"})
        if contradicts:
            residuals.append({"code": "CONTRADICTION", "description": "存在反向或不支持主张。"})
        if not any(s.get("data_available") for s in cell_sources):
            residuals.append({"code": "DATA_UNAVAILABLE", "description": "未登记可复核数据。"})
        if len({str(s.get("population") or "unknown") for s in cell_sources}) <= 1:
            residuals.append({"code": "POPULATION_BOUNDARY", "description": "人群外推边界尚未验证。"})
        evidence_vector = {
            "provenance_complete": all(s.get("title") and s.get("source_id") for s in cell_sources),
            "data_available": any(s.get("data_available") for s in cell_sources),
            "code_available": any(s.get("code_available") for s in cell_sources),
            "preregistered": any(s.get("preregistered") for s in cell_sources),
            "independent_replication": independence["has_independent_replication"],
            "contradictions_exposed": bool(contradicts),
            "population_diversity": len({str(s.get("population") or "unknown") for s in cell_sources}),
            "geographic_diversity": independence["unique_countries"],
            "integrity_signal_count": len(integrity_signals),
            "no_scalar_without_weights": True,
        }
        cell_id = stable_id("evc", statement, *source_ids)
        cell = {
            "cell_id": cell_id,
            "statement": statement,
            "status": status,
            "source_ids": source_ids,
            "claim_ids": [str(c["claim_id"]) for c in cluster],
            "supports": supports,
            "contradictions": contradicts,
            "independence": independence,
            "evidence_vector": evidence_vector,
            "updates": updates,
            "integrity_signals": integrity_signals,
            "residuals": residuals,
            "use_boundary": "用于形成可复核的活证据状态；不自动形成诊断、处方、指南推荐或监管结论。",
        }
        cell["mesh85"] = build_passport(
            object_id=cell_id,
            data={"source_ids": source_ids, "claim_ids": cell["claim_ids"]},
            differences={"contradictions": contradicts, "residual_count": len(residuals)},
            knowledge={"statement": statement, "status": status, "evidence_vector": evidence_vector},
            values={"future_life_authority": "plural life evidence council", "knowledge_equity": "prestige, species dominance and citation counts cannot replace independent evidence"},
            process={"steps": ["source normalization", "claim decomposition", "cluster", "update and integrity screening", "independence analysis", "bounded living evidence cell", "reverse reconstruction"]},
            residuals=residuals,
            boundary=cell["use_boundary"],
        )
        cells.append(cell)
    return claims, cells


def build_living_guidance(cells: Iterable[Mapping[str, Any]], guidance_specs: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    cell_map = {str(c["cell_id"]): dict(c) for c in cells}
    guidance: list[dict[str, Any]] = []
    for spec in guidance_specs:
        item = dict(spec)
        linked = [cell_map[x] for x in item.get("evidence_cell_ids", []) if x in cell_map]
        if not linked and item.get("match_terms"):
            terms = [str(t).lower() for t in item.get("match_terms", [])]
            linked = [c for c in cell_map.values() if any(t in str(c.get("statement", "")).lower() for t in terms)]
            item["evidence_cell_ids"] = [c["cell_id"] for c in linked]
        statuses = {c.get("status") for c in linked}
        blockers = []
        if not linked:
            blockers.append("NO_LINKED_EVIDENCE_CELL")
        if statuses & {"CONTESTED", "RETRACTED_OR_QUARANTINED"}:
            blockers.append("CONTESTED_OR_QUARANTINED_EVIDENCE")
        if any(not c.get("evidence_vector", {}).get("independent_replication") for c in linked):
            blockers.append("INDEPENDENCE_GAP")
        if not item.get("target_population"):
            blockers.append("TARGET_POPULATION_MISSING")
        if not item.get("responsible_role"):
            blockers.append("RESPONSIBLE_ROLE_MISSING")
        state = "HOLD_FOR_REVIEW" if blockers else "ELIGIBLE_FOR_HUMAN_RECOMMENDATION_REVIEW"
        item["state"] = state
        item["blockers"] = blockers
        item["evidence_snapshot"] = [{"cell_id": c["cell_id"], "status": c["status"], "vector": c["evidence_vector"]} for c in linked]
        item["boundary"] = "动态建议只记录证据、目标人群、责任与更新条件；正式临床推荐必须由有权组织依据适用法规和指南流程批准。"
        guidance.append(item)
    return guidance
