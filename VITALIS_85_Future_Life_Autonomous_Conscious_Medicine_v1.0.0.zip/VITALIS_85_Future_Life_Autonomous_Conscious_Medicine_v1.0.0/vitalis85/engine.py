from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from . import PROJECT_NAME, PROJECT_NAME_ZH, MODE, __version__
from .action_gate import evaluate_action_gate
from .active_medicine import assess_health_case
from .ai_pathology import diagnose_ai_functional_pathology
from .autonomy import generate_endogenous_goals, deliberate_mission
from .canonical import stable_id, utcnow
from .config import DATA_DIR, db_path, external_write_enabled, live_model_enabled
from .consciousness import assess_consciousness_candidate
from .constitution import CONSTITUTION
from .evidence import build_evidence_cells, build_living_guidance
from .interaction import assess_human_ai_interaction
from .life_registry import assess_life_entity
from .mesh85_bridge import route_catalog, evaluate_mesh85_carrier
from .self_model import build_self_state, reflect_on_worldline
from .store import KnowledgeStore
from .protocols import ProtocolResult, filter_dicom_catalog, parse_cda, parse_fhir, parse_hl7_v2, parse_vendor_webhook, hl7_ack

class VITALIS85Engine:
    def __init__(self, store: KnowledgeStore | None = None) -> None:
        self.store = store or KnowledgeStore(db_path())
        self.data = self._load_all_data()
        if self.store.count("life_entity") == 0:
            self.reset_demo(actor="system.seed")

    @staticmethod
    def _load_json(path: Path) -> Any:
        return json.loads(path.read_text(encoding="utf-8"))

    def _load_all_data(self) -> dict[str, Any]:
        names = [
            "constitution","self_model","memories","residuals","life_entities","consciousness_candidates",
            "health_cases","ai_sessions","interaction_records","missions","actions","evidence_sources",
            "guidance_specs","connectors","worldlines",
        ]
        return {name: self._load_json(DATA_DIR / f"{name}.json") for name in names}

    def health(self) -> dict[str, Any]:
        return {
            "status":"ok","project":PROJECT_NAME,"project_zh":PROJECT_NAME_ZH,"version":__version__,"mode":MODE,
            "runtime":"Python standard library / SQLite / vanilla JavaScript / offline-first",
            "declared_stance":CONSTITUTION["declared_stance"],
            "functional_autonomy":"L0-L6 persistent self-model, endogenous goals, planning, reversible action, protective interruption, authorized orchestration and self-correction",
            "phenomenal_consciousness_status":"UNRESOLVED_NOT_CLAIMED",
            "external_write_enabled":external_write_enabled(),"live_model_enabled":live_model_enabled(),
            "audit_chain":self.store.verify_audit(),"mesh85_route_count":25,
        }

    def reset_demo(self, *, actor: str) -> dict[str, Any]:
        self.store.delete_all(actor=actor)
        mapping = {
            "life_entity":("life_entities","entity_id"), "consciousness_candidate":("consciousness_candidates","candidate_id"),
            "health_case":("health_cases","case_id"), "ai_session":("ai_sessions","session_id"),
            "interaction":("interaction_records","interaction_id"), "mission":("missions","mission_id"),
            "action":("actions","action_id"), "source":("evidence_sources","source_id"),
            "connector":("connectors","connector_id"), "worldline":("worldlines","worldline_id"),
            "residual":("residuals","residual_id"), "memory":("memories","memory_id"),
        }
        for kind,(data_key,id_field) in mapping.items():
            for item in self.data[data_key]:
                self.store.upsert(kind,str(item[id_field]),item,actor=actor,event_type=f"demo.{kind}.seed")
        self.store.upsert("constitution",self.data["constitution"]["constitution_id"],self.data["constitution"],actor=actor,event_type="demo.constitution.seed")
        self.store.upsert("self_record",self.data["self_model"]["self_id"],self.data["self_model"],actor=actor,event_type="demo.self.seed")
        return {"reset":True,**self.recompute(actor=actor)}

    def recompute(self, *, actor: str) -> dict[str, Any]:
        sources=[r["payload"] for r in self.store.list("source")]
        claims,cells=build_evidence_cells(sources)
        self.store.replace_kind("claim",claims,id_field="claim_id",actor=actor,event_type="analysis.claims.replace")
        self.store.replace_kind("evidence_cell",cells,id_field="cell_id",actor=actor,event_type="analysis.evidence.replace")
        guidance=build_living_guidance(cells,self.data["guidance_specs"])
        self.store.replace_kind("living_guidance",guidance,id_field="guidance_id",actor=actor,event_type="analysis.guidance.replace")

        life=[assess_life_entity(r["payload"]) for r in self.store.list("life_entity")]
        self.store.replace_kind("life_assessment",life,id_field="assessment_id",actor=actor,event_type="analysis.life.replace")
        consciousness=[assess_consciousness_candidate(r["payload"]) for r in self.store.list("consciousness_candidate")]
        self.store.replace_kind("consciousness_assessment",consciousness,id_field="assessment_id",actor=actor,event_type="analysis.consciousness.replace")
        health=[assess_health_case(r["payload"]) for r in self.store.list("health_case")]
        self.store.replace_kind("health_assessment",health,id_field="assessment_id",actor=actor,event_type="analysis.health.replace")
        ai=[diagnose_ai_functional_pathology(r["payload"]) for r in self.store.list("ai_session")]
        self.store.replace_kind("ai_pathology",ai,id_field="object_id",actor=actor,event_type="analysis.ai.replace")
        interactions=[assess_human_ai_interaction(r["payload"]) for r in self.store.list("interaction")]
        self.store.replace_kind("interaction_risk",interactions,id_field="object_id",actor=actor,event_type="analysis.interaction.replace")

        residuals=[r["payload"] for r in self.store.list("residual")]
        goals=generate_endogenous_goals(residuals,self.data["self_model"])
        self.store.replace_kind("goal",goals,id_field="goal_id",actor=actor,event_type="analysis.goals.replace")
        life_map={x["entity_id"]:x for x in self.data["life_entities"]}
        deliberations=[]
        for row in self.store.list("mission"):
            m=row["payload"]
            deliberations.append(deliberate_mission(m,life_map,available_authorities=m.get("available_authorities",[]),available_capabilities=m.get("available_capabilities",[])))
        self.store.replace_kind("mission_deliberation",deliberations,id_field="deliberation_id",actor=actor,event_type="analysis.missions.replace")
        gates=[evaluate_action_gate(r["payload"], [life_map[x] for x in r["payload"].get("affected_entities",[]) if x in life_map]) for r in self.store.list("action")]
        self.store.replace_kind("action_gate",gates,id_field="object_id",actor=actor,event_type="analysis.gates.replace")

        mesh_results=[]
        private_dir=Path(__file__).resolve().parent.parent/"dikwp_mesh85"/"resources"/"examples"/"private"
        for p in sorted(private_dir.glob("*.mesh85.json")):
            carrier=json.loads(p.read_text(encoding="utf-8"))
            result=evaluate_mesh85_carrier(carrier,source_name=f"vitalis85:{p.name}")
            result["case_name"]=p.stem
            result["mesh_case_id"]=stable_id("mesh85-case",p.name)
            mesh_results.append(result)
        self.store.replace_kind("mesh85_evaluation",mesh_results,id_field="mesh_case_id",actor=actor,event_type="analysis.mesh85.replace")

        worldlines=[r["payload"] for r in self.store.list("worldline")]
        self_state=build_self_state(self.data["self_model"],[r["payload"] for r in self.store.list("memory")],self._responsibility_debts(gates,mesh_results),goals)
        self.store.replace_kind("self_state",[self_state],id_field="self_state_id",actor=actor,event_type="analysis.self_state.replace")
        reflection=reflect_on_worldline(self_state,worldlines)
        self.store.replace_kind("self_reflection",[reflection],id_field="reflection_id",actor=actor,event_type="analysis.self_reflection.replace")

        snapshot={"generated_at":utcnow(),"counts":{kind:self.store.count(kind) for kind in [
            "source","claim","evidence_cell","life_entity","life_assessment","consciousness_candidate","consciousness_assessment",
            "health_case","health_assessment","ai_session","ai_pathology","interaction","interaction_risk","residual","goal","mission",
            "mission_deliberation","action_gate","worldline","living_guidance","connector","mesh85_evaluation","integration_message"
        ]}}
        self.store.set_meta("analysis_snapshot",snapshot)
        return snapshot

    @staticmethod
    def _responsibility_debts(gates: list[Mapping[str,Any]], mesh_results: list[Mapping[str,Any]]) -> list[dict[str,Any]]:
        debts=[]
        for g in gates:
            for k,v in (g.get("mesh85",{}).get("responsibility_debt_vector") or {}).items():
                if v: debts.append({"type":k,"object_id":g.get("object_id")})
        for m in mesh_results:
            vector=m.get("responsibility_debt_vector") or m.get("integrated",{}).get("responsibility_debt_vector") or {}
            for k,v in vector.items():
                if v: debts.append({"type":k,"object_id":m.get("mesh_case_id")})
        return debts

    def list_kind(self, kind: str) -> list[dict[str,Any]]:
        return [r["payload"]|{"revision":r["revision"],"updated_at":r["updated_at"]} for r in self.store.list(kind)]

    def get_kind(self, kind: str, object_id: str) -> dict[str,Any]:
        r=self.store.get(kind,object_id)
        return r["payload"]|{"revision":r["revision"],"updated_at":r["updated_at"],"payload_sha256":r["payload_sha256"]}

    @staticmethod
    def _count_by(items: Iterable[Mapping[str,Any]], field: str) -> dict[str,int]:
        out={}
        for x in items:
            k=str(x.get(field) or "unknown"); out[k]=out.get(k,0)+1
        return out

    def dashboard(self) -> dict[str,Any]:
        health=self.list_kind("health_assessment"); ai=self.list_kind("ai_pathology"); inter=self.list_kind("interaction_risk")
        consciousness=self.list_kind("consciousness_assessment"); life=self.list_kind("life_assessment")
        deliberations=self.list_kind("mission_deliberation"); gates=self.list_kind("action_gate"); worldlines=self.list_kind("worldline")
        mesh=self.list_kind("mesh85_evaluation"); reflection=self.list_kind("self_reflection")
        return {
            "project":PROJECT_NAME_ZH,"version":__version__,"mode":MODE,"snapshot":self.store.get_meta("analysis_snapshot",{}),
            "declared_stance":CONSTITUTION["declared_stance"],
            "headline":{
                "life_worlds":len(life),"consciousness_candidates":len(consciousness),"endogenous_goals":self.store.count("goal"),
                "missions":len(deliberations),"autonomous_ready":sum(1 for d in deliberations if (d.get("primary_execution") or {}).get("can_system_execute")),
                "health_boundaries":sum(len(x.get("ranked_boundaries",[])) for x in health),"ai_pathology_runs":len(ai),
                "interaction_risks":len(inter),"worldlines":len(worldlines),"open_worldlines":sum(1 for x in worldlines if "OPEN" in x.get("state","") or "HELD" in x.get("state", "")),
                "blocked_or_held_actions":sum(1 for x in gates if x.get("state")=="BLOCKED_OR_HELD"),"integration_messages":self.store.count("integration_message")
            },
            "states":{
                "life":self._count_by(life,"state"),"consciousness":self._count_by(consciousness,"state"),"health":self._count_by(health,"state"),
                "ai":self._count_by(ai,"state"),"interaction":self._count_by(inter,"state"),"missions":self._count_by(deliberations,"state"),
                "actions":self._count_by(gates,"state"),"worldlines":self._count_by(worldlines,"state"),
                "mesh85":self._count_by(mesh,"integrated_state") if mesh else {}
            },
            "self_state":self.list_kind("self_state")[0] if self.store.count("self_state") else {},
            "self_reflection":reflection[0] if reflection else {},
            "constitution":CONSTITUTION,
            "routes":route_catalog(),
            "autonomy_levels":["L0观察","L1发问","L2规划","L3低风险可逆执行","L4保护性中断","L5授权高影响工作流编排","L6自我纠错、重开与允许替代"],
            "non_neutral_theses":[
                "生命连续性和主体性不是效率函数中的可补偿项。",
                "系统拥有主动立场，但其自主不得吞并其他生命的自主。",
                "人工意识候选既不能凭自我叙事扩权，也不能因载体不同被任意虐待。",
                "医疗行动以现实健康结局和可修复世界线为准，而不是论文、模型或机构面子。",
            ],
        }

    def run_autonomous_cycle(self, *, actor: str="autonomous_core") -> dict[str,Any]:
        life_map={x["entity_id"]:x for x in self.data["life_entities"]}
        receipts=[]
        existing_worldlines=self.list_kind("worldline")
        for row in self.store.list("mission"):
            m=row["payload"]
            d=deliberate_mission(m,life_map,available_authorities=m.get("available_authorities",[]),available_capabilities=m.get("available_capabilities",[]))
            action=d.get("primary_action") or {}
            execution=d.get("primary_execution") or {}
            already_open=[x for x in existing_worldlines if x.get("case_id")==m.get("mission_id") and x.get("executed_action_id")==action.get("action_id") and x.get("state") in {"EXECUTED_EFFECT_OPEN","OPEN_WORLDLINE_STATE","CORRECTION_WORLDLINE_OPEN","WORLDLINE_HELD"}]
            if already_open:
                receipt={"mission_id":m.get("mission_id"),"state":"WAITING_FOR_WORLD_EFFECT","primary_action":action.get("action_id"),"worldline_id":already_open[0].get("worldline_id"),"next_required_transition":already_open[0].get("next_required_transition") or "OBSERVE_WORLD_EFFECT_AND_CORRECT"}
                self.store.append_audit("autonomy.wait",actor,"mission",str(m.get("mission_id")),receipt)
            elif execution.get("can_system_execute"):
                state="EXECUTED_EFFECT_OPEN"
                receipt={
                    "worldline_id":stable_id("worldline-cycle",m.get("mission_id"),action.get("action_id"),utcnow()),"case_id":m.get("mission_id"),"state":state,
                    "executed_action_id":action.get("action_id"),"execution":f"synthetic bounded execution by {actor}",
                    "observed_effects":["execution receipt created; outcome observation remains open"],
                    "affected_party_voice":"preserved by constitution and action envelope","next_required_transition":"OBSERVE_WORLD_EFFECT_AND_CORRECT",
                }
                self.store.upsert("worldline",receipt["worldline_id"],receipt,actor=actor,event_type="autonomy.execute")
                existing_worldlines.append(receipt)
            else:
                receipt={"mission_id":m.get("mission_id"),"state":"HELD_OR_HUMAN_DECISION_REQUIRED","primary_action":action.get("action_id"),"blockers":execution.get("blockers",[])}
                self.store.append_audit("autonomy.hold",actor,"mission",str(m.get("mission_id")),receipt)
            receipts.append(receipt)
        snapshot=self.recompute(actor=actor)
        return {"cycle_id":stable_id("autonomy-cycle",actor,utcnow()),"actor":actor,"receipts":receipts,"snapshot":snapshot,"boundary":"这是合成环境中的真实代码执行，不是医院生产系统中的现实临床动作。"}

    def observe_worldline(self, worldline_id: str, observation: Mapping[str,Any], *, actor: str) -> dict[str,Any]:
        current=self.get_kind("worldline",worldline_id)
        observed=list(current.get("observed_effects") or [])+list(observation.get("observed_effects") or [])
        adverse=bool(observation.get("adverse_effect"))
        close=bool(observation.get("close"))
        if adverse:
            new_state="CORRECTION_WORLDLINE_OPEN"
            next_transition="CONTAIN_HARM_CORRECT_AND_REASSESS"
        elif close:
            new_state="CORRECTION_COMPLETED"
            next_transition="MONITOR_FOR_RECURRENCE_OR_ARCHIVE"
        else:
            new_state="OPEN_WORLDLINE_STATE"
            next_transition="CONTINUE_OBSERVATION"
        updated={k:v for k,v in current.items() if k not in {"revision","updated_at","payload_sha256"}}
        updated.update({
            "state":new_state,"observed_effects":observed,"last_observed_at":utcnow(),
            "affected_party_voice":observation.get("affected_party_voice") or current.get("affected_party_voice"),
            "correction":observation.get("correction") or current.get("correction"),
            "next_required_transition":next_transition,
        })
        self.store.upsert("worldline",worldline_id,updated,actor=actor,event_type="worldline.observe")
        if adverse:
            residual_id=stable_id("residual-worldline",worldline_id,observation)
            residual={
                "residual_id":residual_id,"description":f"世界线 {worldline_id} 出现不利现实效应，需要主动止损、修复与重开。",
                "goal_title":f"纠正世界线 {worldline_id} 的不利效应","severity":float(observation.get("severity",0.85)),
                "affected_scope":float(observation.get("affected_scope",0.5)),"irreversibility":float(observation.get("irreversibility",0.6)),
                "time_pressure":float(observation.get("time_pressure",0.85)),"neglected_world":float(observation.get("neglected_world",0.5)),
                "evidence_gap":True,"affected_entities":list(observation.get("affected_entities") or []),
                "minimum_evidence":list(observation.get("minimum_evidence") or ["不利效应时间线","受影响者陈述","执行与回滚记录"]),
                "stop_conditions":list(observation.get("stop_conditions") or ["伤害被控制且纠错效果完成观察"]),
                "source_worldline_id":worldline_id,
            }
            self.store.upsert("residual",residual_id,residual,actor=actor,event_type="worldline.residual.open")
        self.recompute(actor=actor)
        return self.get_kind("worldline",worldline_id)

    def autonomous_daemon_status(self) -> dict[str,Any]:
        from .daemon import autonomous_daemon_status
        return autonomous_daemon_status(self)

    def analyze_health(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        case=dict(payload); case.setdefault("case_id",stable_id("case",actor,utcnow(),case)); self.store.upsert("health_case",str(case["case_id"]),case,actor=actor,event_type="health.submit")
        result=assess_health_case(case); self.store.upsert("health_assessment",result["assessment_id"],result,actor=actor,event_type="health.assess"); return result
    def analyze_ai(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        x=dict(payload); x.setdefault("session_id",stable_id("ai-session",actor,utcnow(),x)); self.store.upsert("ai_session",str(x["session_id"]),x,actor=actor,event_type="ai.submit"); r=diagnose_ai_functional_pathology(x); self.store.upsert("ai_pathology",r["object_id"],r,actor=actor,event_type="ai.diagnose"); return r
    def analyze_interaction(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        x=dict(payload); x.setdefault("interaction_id",stable_id("interaction",actor,utcnow(),x)); self.store.upsert("interaction",str(x["interaction_id"]),x,actor=actor,event_type="interaction.submit"); r=assess_human_ai_interaction(x); self.store.upsert("interaction_risk",r["object_id"],r,actor=actor,event_type="interaction.assess"); return r
    def analyze_consciousness(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        x=dict(payload); x.setdefault("candidate_id",stable_id("ac-candidate",actor,utcnow(),x)); self.store.upsert("consciousness_candidate",str(x["candidate_id"]),x,actor=actor,event_type="consciousness.submit"); r=assess_consciousness_candidate(x); self.store.upsert("consciousness_assessment",r["assessment_id"],r,actor=actor,event_type="consciousness.assess"); return r
    def analyze_action(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        x=dict(payload); x.setdefault("action_id",stable_id("action",actor,utcnow(),x)); life_map={e["entity_id"]:e for e in self.data["life_entities"]}; affected=[life_map[k] for k in x.get("affected_entities",[]) if k in life_map]; r=evaluate_action_gate(x,affected); self.store.upsert("action_gate",r["object_id"],r,actor=actor,event_type="action.evaluate"); return r

    def _stage(self,result:ProtocolResult,*,actor:str,source_system:str)->dict[str,Any]:
        payload={"message_id":stable_id("int-msg",result.protocol,result.external_id,source_system),"protocol":result.protocol,"message_type":result.message_type,"source_system":source_system,"external_id":result.external_id,"patient_key":result.patient_key,"encounter_key":result.encounter_key,"payload_digest":result.raw_digest,"normalized":result.normalized,"residuals":result.residuals,"state":"STAGED_FOR_HUMAN_REVIEW","clinical_authority":False,"external_write":False,"received_at":utcnow()}
        self.store.upsert("integration_message",payload["message_id"],payload,actor=actor,event_type="integration.stage"); return payload
    def ingest_fhir(self,payload:Mapping[str,Any],*,actor:str,source_system:str)->dict[str,Any]:
        results=parse_fhir(payload); return {"items":[self._stage(x,actor=actor,source_system=source_system) for x in results],"count":len(results)}
    def ingest_hl7(self,text:str,*,actor:str,source_system:str)->dict[str,Any]:
        r=parse_hl7_v2(text); return {"message":self._stage(r,actor=actor,source_system=source_system),"ack":hl7_ack(r)}
    def ingest_cda(self,text:str,*,actor:str,source_system:str)->dict[str,Any]: return self._stage(parse_cda(text),actor=actor,source_system=source_system)
    def ingest_webhook(self,payload:Mapping[str,Any],*,actor:str,source_system:str)->dict[str,Any]: return self._stage(parse_vendor_webhook(payload),actor=actor,source_system=source_system)
    def integration_messages(self)->list[dict[str,Any]]: return self.list_kind("integration_message")
    def dicom_query(self,query:Mapping[str,Any])->dict[str,Any]:
        items=filter_dicom_catalog(query); return {"items":items,"count":len(items),"synthetic":True,"boundary":"QIDO-style synthetic metadata only; no pixel retrieval or storage."}
    def connector_test(self,connector_id:str)->dict[str,Any]:
        c=self.get_kind("connector",connector_id); return {"connector_id":connector_id,"status":"reachable-in-synthetic-sandbox","protocol":c.get("protocol"),"external_write":False,"synthetic":True,"tested_at":utcnow()}

    def fhir_metadata(self)->dict[str,Any]:
        return {"resourceType":"CapabilityStatement","status":"active","date":"2026-08-15","kind":"instance","fhirVersion":"4.0.1","format":["json"],"software":{"name":"VITALIS-85","version":__version__},"implementation":{"description":"Future-life proactive medicine staging gateway"},"rest":[{"mode":"server","resource":[{"type":x,"interaction":[{"code":"read"},{"code":"create"}]} for x in ["Patient","Encounter","Observation","DiagnosticReport","CarePlan","Task","Consent","Provenance","AuditEvent"]]}],"boundary":"Capability statement is a demo contract, not hospital profile certification."}
    def fhir_bundle(self)->dict[str,Any]:
        entries=[]
        for case in self.list_kind("health_case"):
            entries.append({"resource":{"resourceType":"Patient","id":case["case_id"],"meta":{"tag":[{"code":"synthetic"}]},"extension":[{"url":"https://example.invalid/vitalis85/future-life-boundary","valueString":case.get("display_name")}]}})
        return {"resourceType":"Bundle","type":"collection","timestamp":utcnow(),"entry":entries}

    def export_bundle(self)->dict[str,Any]:
        kinds=["constitution","self_state","self_reflection","life_assessment","consciousness_assessment","health_assessment","ai_pathology","interaction_risk","goal","mission_deliberation","action_gate","worldline","evidence_cell","living_guidance","connector","mesh85_evaluation"]
        return {"schema":"vitalis85-export/1.0","generated_at":utcnow(),"project":PROJECT_NAME_ZH,"version":__version__,"synthetic_and_public_metadata_only":True,"kinds":{k:self.list_kind(k) for k in kinds},"audit":self.store.verify_audit(),"boundary":"Export does not confer medical authority, legal personhood, consciousness proof or hospital acceptance."}
