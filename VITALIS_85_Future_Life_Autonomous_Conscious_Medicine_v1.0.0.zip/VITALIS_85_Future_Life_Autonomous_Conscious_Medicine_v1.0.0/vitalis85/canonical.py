from __future__ import annotations

import hashlib
import json
import math
import re
import unicodedata
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

_WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_\-\.]*|[\u3400-\u9fff]")
_SPACE_RE = re.compile(r"\s+")
_PUNCT_RE = re.compile(r"[^A-Za-z0-9\u3400-\u9fff]+")


def utcnow() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def normalize_text(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).strip().lower()
    text = _SPACE_RE.sub(" ", text)
    return text


def normalize_compact(value: Any) -> str:
    return _PUNCT_RE.sub("", normalize_text(value))


def tokens(value: Any) -> list[str]:
    text = normalize_text(value)
    raw = _WORD_RE.findall(text)
    return [token for token in raw if len(token) > 1 or "\u3400" <= token <= "\u9fff"]


def token_set(value: Any) -> set[str]:
    return set(tokens(value))


def jaccard(a: Any, b: Any) -> float:
    aa, bb = token_set(a), token_set(b)
    if not aa and not bb:
        return 1.0
    if not aa or not bb:
        return 0.0
    return len(aa & bb) / len(aa | bb)


def cosine_sparse(a: Mapping[str, float], b: Mapping[str, float]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(float(v) * float(b.get(k, 0.0)) for k, v in a.items())
    na = math.sqrt(sum(float(v) ** 2 for v in a.values()))
    nb = math.sqrt(sum(float(v) ** 2 for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def term_frequency(value: Any) -> dict[str, float]:
    toks = tokens(value)
    if not toks:
        return {}
    counts: dict[str, float] = {}
    for tok in toks:
        counts[tok] = counts.get(tok, 0.0) + 1.0
    total = float(len(toks))
    return {k: v / total for k, v in counts.items()}


def gini(values: Iterable[float]) -> float:
    xs = sorted(max(0.0, float(v)) for v in values)
    n = len(xs)
    if n == 0 or sum(xs) == 0:
        return 0.0
    weighted = sum((i + 1) * value for i, value in enumerate(xs))
    return (2.0 * weighted) / (n * sum(xs)) - (n + 1.0) / n


def stable_id(prefix: str, *parts: Any, length: int = 14) -> str:
    digest = hashlib.sha256("|".join(normalize_text(part) for part in parts).encode("utf-8")).hexdigest()
    return f"{prefix}-{digest[:length]}"


def clamp(value: Any, low: float = 0.0, high: float = 1.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return low
    return max(low, min(high, number))


def ensure_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]
