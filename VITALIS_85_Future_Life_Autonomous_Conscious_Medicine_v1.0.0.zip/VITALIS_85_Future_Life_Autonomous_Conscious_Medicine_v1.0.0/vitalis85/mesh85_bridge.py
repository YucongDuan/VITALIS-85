from __future__ import annotations

import json
import re
from typing import Any, Mapping, Sequence

from dikwp_mesh85.integrated import evaluate_integrated
from dikwp_mesh85.normalize import normalize_core
from dikwp_mesh85.closure import evaluate_closure

from .canonical import sha256_json, utcnow

POSITIONS = ("D", "I", "K", "W", "P")


def route_catalog() -> list[dict[str, str]]:
    return [{"route": f"{a}->{b}", "source": a, "target": b} for a in POSITIONS for b in POSITIONS]


def _payload(value: Any) -> dict[str, str]:
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return {"encoding": "utf-8", "value": value}


def _safe_id(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.:-]", "-", str(value))[:60].strip("-.") or "object"


def build_passport(
    *,
    object_id: str,
    data: Mapping[str, Any],
    differences: Mapping[str, Any],
    knowledge: Mapping[str, Any],
    values: Mapping[str, Any],
    process: Mapping[str, Any],
    residuals: Sequence[Mapping[str, Any]] | Sequence[str],
    boundary: str,
    responsibility_debts: Mapping[str, bool] | None = None,
) -> dict[str, Any]:
    sid = _safe_id(object_id)
    ids = {
        "d": f"d.source.{sid}", "i": f"i.diff.{sid}", "w": f"w.value.{sid}",
        "pf": f"p.forward.{sid}", "k": f"k.bound.{sid}", "pr": f"p.return.{sid}",
        "dr": f"d.return.{sid}", "ir": f"i.return.{sid}", "wr": f"w.return.{sid}",
        "sd": f"d.same.d.{sid}", "si": f"d.same.i.{sid}", "sw": f"d.same.w.{sid}",
    }
    records: list[dict[str, Any]] = [
        {"id": ids["d"], "kind": "D", "given": bool(data), "refs": [], "payload": _payload(dict(data))},
        {"id": ids["i"], "kind": "I", "given": bool(differences), "refs": [], "payload": _payload(dict(differences))},
        {"id": ids["w"], "kind": "W", "given": bool(values), "refs": [], "payload": _payload(dict(values))},
        {"id": ids["dr"], "kind": "D", "given": bool(data), "refs": [], "payload": _payload(dict(data))},
        {"id": ids["ir"], "kind": "I", "given": bool(differences), "refs": [], "payload": _payload(dict(differences))},
        {"id": ids["wr"], "kind": "W", "given": bool(values), "refs": [], "payload": _payload(dict(values))},
        {"id": ids["sd"], "kind": "D", "given": True, "refs": [ids["d"], ids["dr"]], "payload": None},
        {"id": ids["si"], "kind": "D", "given": True, "refs": [ids["i"], ids["ir"]], "payload": None},
        {"id": ids["sw"], "kind": "D", "given": True, "refs": [ids["w"], ids["wr"]], "payload": None},
        {"id": ids["pf"], "kind": "P", "given": bool(process), "input": {"refs": [ids["d"], ids["i"], ids["w"]], "payload": _payload(dict(process))}, "output": {"refs": [ids["k"]], "payload": None}},
        {"id": ids["pr"], "kind": "P", "given": True, "input": {"refs": [ids["k"]], "payload": None}, "output": {"refs": [ids["dr"], ids["ir"], ids["wr"], ids["sd"], ids["si"], ids["sw"]], "payload": None}},
    ]
    records.append({
        "id": ids["k"], "kind": "K", "given": bool(knowledge), "refs": [r["id"] for r in records],
        "payload": _payload({"knowledge": dict(knowledge), "residuals": list(residuals), "boundary": boundary}),
    })
    routes = [
        {"source": ids["d"], "target": ids["pf"]}, {"source": ids["i"], "target": ids["pf"]}, {"source": ids["w"], "target": ids["pf"]},
        {"source": ids["pf"], "target": ids["k"]}, {"source": ids["k"], "target": ids["pr"]},
    ] + [{"source": ids["pr"], "target": x} for x in [ids["dr"], ids["ir"], ids["wr"], ids["sd"], ids["si"], ids["sw"]]]
    artifact = normalize_core({"mesh_version": "8.5", "records": records, "routes": routes}, source_name=f"vitalis85:{object_id}")
    closure = evaluate_closure(artifact, profile="bidirectional")
    best = closure["best"]
    debts = dict(responsibility_debts or {})
    debts.setdefault("semantic_debt", not best["full_closure"])
    return {
        "spec": "vitalis85-mesh85-passport/1.0",
        "object_id": object_id,
        "created_at": utcnow(),
        "vector": best["vector"],
        "vector_compact": best["vector_compact"],
        "semantic_closure_complete": best["full_closure"],
        "open_reasons": best["open_reasons"],
        "route_count": 25,
        "routes": route_catalog(),
        "residuals": list(residuals),
        "responsibility_debt_vector": debts,
        "responsibility_debt_noncompensatory": True,
        "semantic_authority": ["D", "I", "K", "W", "P"],
        "non_core_semantic_authority": 0,
        "boundary": boundary,
        "passport_sha256": sha256_json({
            "object_id": object_id, "data": data, "differences": differences, "knowledge": knowledge,
            "values": values, "process": process, "residuals": list(residuals), "boundary": boundary, "debts": debts,
        }),
    }


def evaluate_mesh85_carrier(carrier: Mapping[str, Any], *, source_name: str = "vitalis85") -> dict[str, Any]:
    return evaluate_integrated(dict(carrier), source_name=source_name)
