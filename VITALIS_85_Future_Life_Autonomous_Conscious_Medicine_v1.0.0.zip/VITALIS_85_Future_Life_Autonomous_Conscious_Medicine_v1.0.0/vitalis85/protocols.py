from __future__ import annotations

import hashlib
import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Any, Mapping

MAX_INTERFACE_BYTES = 4 * 1024 * 1024
FHIR_TYPES = {
    "Patient", "Encounter", "Observation", "DiagnosticReport", "DocumentReference",
    "Appointment", "CarePlan", "Task", "ServiceRequest", "MedicationRequest",
    "ImagingStudy", "Consent", "Provenance", "AuditEvent", "Bundle", "Condition",
    "Procedure", "Organization", "Practitioner", "PractitionerRole", "Location",
}


class InterfaceValidationError(ValueError):
    def __init__(self, message: str, *, details: Mapping[str, Any] | None = None) -> None:
        super().__init__(message)
        self.details = dict(details or {})


@dataclass(frozen=True)
class ProtocolResult:
    protocol: str
    message_type: str
    external_id: str
    patient_key: str
    encounter_key: str
    normalized: dict[str, Any]
    residuals: list[dict[str, Any]]
    raw_digest: str


def _digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _ensure_size(raw: bytes) -> None:
    if len(raw) > MAX_INTERFACE_BYTES:
        raise InterfaceValidationError(
            "interface payload is too large",
            details={"max_bytes": MAX_INTERFACE_BYTES, "actual_bytes": len(raw)},
        )


def _identifier_value(resource: Mapping[str, Any]) -> str:
    identifiers = resource.get("identifier")
    if isinstance(identifiers, list):
        for item in identifiers:
            if isinstance(item, Mapping) and item.get("value"):
                system = str(item.get("system") or "").strip()
                value = str(item.get("value") or "").strip()
                return f"{system}|{value}" if system else value
    return str(resource.get("id") or "").strip()


def _reference_id(value: Any) -> str:
    if isinstance(value, Mapping):
        value = value.get("reference")
    text = str(value or "")
    return text.split("/", 1)[-1] if "/" in text else text


def parse_fhir(payload: Mapping[str, Any]) -> list[ProtocolResult]:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    _ensure_size(raw)
    resource_type = str(payload.get("resourceType") or "")
    if resource_type not in FHIR_TYPES:
        raise InterfaceValidationError(
            "unsupported or missing FHIR resourceType",
            details={"resourceType": resource_type, "supported": sorted(FHIR_TYPES)},
        )
    if resource_type == "Bundle":
        entries = payload.get("entry")
        if not isinstance(entries, list):
            raise InterfaceValidationError("FHIR Bundle.entry must be an array")
        results: list[ProtocolResult] = []
        for index, entry in enumerate(entries):
            if not isinstance(entry, Mapping) or not isinstance(entry.get("resource"), Mapping):
                raise InterfaceValidationError("FHIR Bundle entry lacks resource", details={"index": index})
            results.extend(parse_fhir(entry["resource"]))
        if not results:
            raise InterfaceValidationError("FHIR Bundle contains no resources")
        return results

    resource_id = str(payload.get("id") or "").strip()
    external_id = resource_id or _digest(raw)[:20]
    subject = payload.get("subject") or payload.get("patient")
    patient_key = ""
    if resource_type == "Patient":
        patient_key = _identifier_value(payload)
    elif resource_type == "Appointment":
        participants = payload.get("participant")
        if isinstance(participants, list):
            for participant in participants:
                if not isinstance(participant, Mapping):
                    continue
                actor = participant.get("actor")
                reference = str(actor.get("reference") or "") if isinstance(actor, Mapping) else str(actor or "")
                if reference.startswith("Patient/"):
                    patient_key = _reference_id(reference)
                    break
        if not patient_key:
            patient_key = _reference_id(subject)
    else:
        patient_key = _reference_id(subject)
    encounter_key = _reference_id(payload.get("encounter"))
    residuals: list[dict[str, Any]] = []
    if not resource_id:
        residuals.append({"code": "FHIR_ID_ABSENT", "field": "id", "message": "resource id was absent; digest-derived external id used"})
    if resource_type not in {"Organization", "Practitioner", "PractitionerRole", "Location", "Patient"} and not patient_key:
        residuals.append({"code": "FHIR_PATIENT_REFERENCE_OPEN", "field": "subject", "message": "patient/subject reference was not supplied"})
    if "meta" not in payload:
        residuals.append({"code": "FHIR_META_ABSENT", "field": "meta", "message": "source profile/version metadata was not supplied"})

    normalized = {
        "resource_type": resource_type,
        "resource_id": external_id,
        "patient_key": patient_key,
        "encounter_key": encounter_key,
        "status": payload.get("status"),
        "code": payload.get("code"),
        "effective": payload.get("effectiveDateTime") or payload.get("effectivePeriod") or payload.get("issued"),
        "resource": dict(payload),
        "boundary": "FHIR载体仅完成安全暂存；临床含义仍需医院Profile、术语、身份、同意和人工复核。",
    }
    return [ProtocolResult("FHIR_R4", resource_type, external_id, patient_key, encounter_key, normalized, residuals, _digest(raw))]


def _hl7_unescape(value: str) -> str:
    replacements = {"\\F\\": "|", "\\S\\": "^", "\\R\\": "~", "\\T\\": "&", "\\E\\": "\\"}
    for src, dst in replacements.items():
        value = value.replace(src, dst)
    return value


def parse_hl7_v2(raw_text: str) -> ProtocolResult:
    raw = raw_text.encode("utf-8")
    _ensure_size(raw)
    text = raw_text.replace("\r\n", "\r").replace("\n", "\r").strip("\r\x0b\x1c")
    segments = [segment for segment in text.split("\r") if segment]
    if not segments or not segments[0].startswith("MSH"):
        raise InterfaceValidationError("HL7 v2 message must begin with MSH")
    separator = segments[0][3:4] or "|"
    parsed: dict[str, list[list[str]]] = {}
    for segment in segments:
        fields = segment.split(separator)
        parsed.setdefault(fields[0], []).append(fields)
    msh = parsed["MSH"][0]
    message_type = (msh[8] if len(msh) > 8 else "").replace("^", "_") or "UNKNOWN"
    control_id = msh[9] if len(msh) > 9 else ""
    external_id = control_id or _digest(raw)[:20]
    pid = parsed.get("PID", [[]])[0]
    patient_id = pid[3] if len(pid) > 3 else ""
    patient_key = _hl7_unescape(patient_id.split("~")[0].split("^")[0])
    patient_name = pid[5] if len(pid) > 5 else ""
    pv1 = parsed.get("PV1", [[]])[0]
    encounter_key = pv1[19].split("^")[0] if len(pv1) > 19 else ""
    observations: list[dict[str, Any]] = []
    for fields in parsed.get("OBX", []):
        observations.append({
            "set_id": fields[1] if len(fields) > 1 else None,
            "value_type": fields[2] if len(fields) > 2 else None,
            "code": fields[3] if len(fields) > 3 else None,
            "value": _hl7_unescape(fields[5]) if len(fields) > 5 else None,
            "unit": fields[6] if len(fields) > 6 else None,
            "reference_range": fields[7] if len(fields) > 7 else None,
            "abnormal_flag": fields[8] if len(fields) > 8 else None,
            "status": fields[11] if len(fields) > 11 else None,
        })
    residuals: list[dict[str, Any]] = []
    if not control_id:
        residuals.append({"code": "HL7_CONTROL_ID_ABSENT", "field": "MSH-10", "message": "message control id absent"})
    if not patient_key:
        residuals.append({"code": "HL7_PATIENT_ID_OPEN", "field": "PID-3", "message": "patient identifier absent"})
    if not encounter_key:
        residuals.append({"code": "HL7_VISIT_ID_OPEN", "field": "PV1-19", "message": "visit number absent or not applicable"})
    normalized = {
        "message_type": message_type,
        "message_control_id": external_id,
        "sending_application": msh[2] if len(msh) > 2 else None,
        "sending_facility": msh[3] if len(msh) > 3 else None,
        "receiving_application": msh[4] if len(msh) > 4 else None,
        "receiving_facility": msh[5] if len(msh) > 5 else None,
        "message_time": msh[6] if len(msh) > 6 else None,
        "patient_key": patient_key,
        "patient_name_raw": patient_name,
        "encounter_key": encounter_key,
        "observations": observations,
        "segment_counts": {name: len(values) for name, values in parsed.items()},
        "boundary": "HL7字段保留源位置并进入暂存；字段映射不构成临床确认。",
    }
    return ProtocolResult("HL7_V2", message_type, external_id, patient_key, encounter_key, normalized, residuals, _digest(raw))


def hl7_ack(result: ProtocolResult, *, acknowledgement_code: str = "AA", text: str = "Accepted for staging") -> str:
    message_code = result.message_type.split("_")[0]
    return (
        "MSH|^~\\&|MEDCOMMONS81|OPEN-COMMONS|SOURCE|INSTITUTION|20260813000000||ACK^"
        f"{message_code}|ACK-{result.external_id}|P|2.5\r"
        f"MSA|{acknowledgement_code}|{result.external_id}|{text}\r"
    )


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _first_attribute(root: ET.Element, local_name: str, attribute: str) -> str:
    for element in root.iter():
        if _local_name(element.tag) == local_name and element.get(attribute):
            return str(element.get(attribute))
    return ""


def _first_text(root: ET.Element, local_name: str) -> str:
    for element in root.iter():
        if _local_name(element.tag) == local_name and element.text:
            return element.text.strip()
    return ""


def parse_cda(raw_text: str) -> ProtocolResult:
    raw = raw_text.encode("utf-8")
    _ensure_size(raw)
    upper = raw_text.upper()
    if "<!DOCTYPE" in upper or "<!ENTITY" in upper:
        raise InterfaceValidationError("CDA external entities and document type declarations are prohibited")
    try:
        root = ET.fromstring(raw_text)
    except ET.ParseError as exc:
        raise InterfaceValidationError("invalid CDA XML", details={"parse_error": str(exc)}) from exc
    if _local_name(root.tag) != "ClinicalDocument":
        raise InterfaceValidationError("CDA root element must be ClinicalDocument")
    document_id = _first_attribute(root, "id", "extension") or _first_attribute(root, "id", "root") or _digest(raw)[:20]
    patient_id = ""
    for patient_role in root.iter():
        if _local_name(patient_role.tag) == "patientRole":
            for child in patient_role:
                if _local_name(child.tag) == "id":
                    patient_id = str(child.get("extension") or child.get("root") or "")
                    break
            break
    title = _first_text(root, "title")
    effective_time = _first_attribute(root, "effectiveTime", "value")
    section_titles: list[str] = []
    for section in root.iter():
        if _local_name(section.tag) == "section":
            for child in section:
                if _local_name(child.tag) == "title" and child.text:
                    section_titles.append(child.text.strip())
                    break
    residuals: list[dict[str, Any]] = []
    if not patient_id:
        residuals.append({"code": "CDA_PATIENT_ID_OPEN", "field": "recordTarget/patientRole/id", "message": "patient id absent"})
    if not title:
        residuals.append({"code": "CDA_TITLE_OPEN", "field": "title", "message": "document title absent"})
    normalized = {
        "document_id": document_id,
        "patient_key": patient_id,
        "title": title,
        "effective_time": effective_time,
        "section_titles": section_titles,
        "section_count": len(section_titles),
        "boundary": "CDA叙事保留为文档载体，不静默拆解为已确认临床事实。",
    }
    return ProtocolResult("CDA_R2", "ClinicalDocument", document_id, patient_id, "", normalized, residuals, _digest(raw))


def parse_vendor_webhook(payload: Mapping[str, Any]) -> ProtocolResult:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    _ensure_size(raw)
    event_id = str(payload.get("event_id") or payload.get("id") or _digest(raw)[:20])
    event_type = str(payload.get("event_type") or payload.get("type") or "vendor_event")
    patient_key = str(payload.get("patient_id") or payload.get("patient_key") or "")
    encounter_key = str(payload.get("encounter_id") or payload.get("visit_id") or "")
    residuals: list[dict[str, Any]] = []
    if not patient_key:
        residuals.append({"code": "VENDOR_PATIENT_ID_OPEN", "field": "patient_id", "message": "vendor event lacks patient identifier"})
    normalized = {
        "event_id": event_id,
        "event_type": event_type,
        "patient_key": patient_key,
        "encounter_key": encounter_key,
        "payload": dict(payload),
        "boundary": "厂商载荷在版本化映射、明确用途和人工批准前保持来源域限定。",
    }
    return ProtocolResult("VENDOR_REST", event_type, event_id, patient_key, encounter_key, normalized, residuals, _digest(raw))


def dicom_demo_catalog() -> list[dict[str, Any]]:
    return [
        {"StudyInstanceUID": "1.2.840.113619.2.55.3.604688654.8101", "PatientID": "MC81-P001", "PatientName": "合成居民甲", "StudyDate": "20260801", "Modality": "MR", "StudyDescription": "颅脑MRI（合成目录）", "SeriesCount": 5, "InstanceCount": 84, "access": "QIDO metadata only; WADO/STOW disabled in demo"},
        {"StudyInstanceUID": "1.2.840.113619.2.55.3.604688654.8102", "PatientID": "MC81-P002", "PatientName": "合成居民乙", "StudyDate": "20260802", "Modality": "CT", "StudyDescription": "胸部CT（合成目录）", "SeriesCount": 3, "InstanceCount": 126, "access": "QIDO metadata only; WADO/STOW disabled in demo"},
    ]


def filter_dicom_catalog(query: Mapping[str, Any]) -> list[dict[str, Any]]:
    patient_id = str(query.get("PatientID") or query.get("patient_id") or "").strip()
    modality = str(query.get("Modality") or query.get("modality") or "").strip().upper()
    study_uid = str(query.get("StudyInstanceUID") or query.get("study_uid") or "").strip()
    result = []
    for item in dicom_demo_catalog():
        if patient_id and item["PatientID"] != patient_id:
            continue
        if modality and item["Modality"] != modality:
            continue
        if study_uid and item["StudyInstanceUID"] != study_uid:
            continue
        result.append(item)
    return result
