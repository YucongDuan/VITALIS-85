from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
WEB_DIR = ROOT / "web"
VAR_DIR = ROOT / "var"
OUTPUT_DIR = ROOT / "outputs"


def db_path() -> Path:
    return Path(os.environ.get("VITALIS85_DB", str(VAR_DIR / "vitalis85.db"))).expanduser().resolve()


def host() -> str:
    return os.environ.get("VITALIS85_HOST", "127.0.0.1")


def port() -> int:
    try:
        value = int(os.environ.get("VITALIS85_PORT", "8788"))
    except ValueError:
        value = 8788
    return max(1, min(value, 65535))


def token_secret() -> str:
    return os.environ.get("VITALIS85_TOKEN_SECRET", "vitalis85-local-demo-secret-change-in-production")


def demo_password() -> str:
    return os.environ.get("VITALIS85_DEMO_PASSWORD", "mesh85-demo")


def token_ttl_seconds() -> int:
    try:
        value = int(os.environ.get("VITALIS85_TOKEN_TTL_SECONDS", "28800"))
    except ValueError:
        value = 28800
    return max(300, min(value, 7 * 24 * 3600))


def live_model_enabled() -> bool:
    return os.environ.get("VITALIS85_ENABLE_LIVE_MODEL", "0") == "1"


def external_write_enabled() -> bool:
    return os.environ.get("VITALIS85_ENABLE_EXTERNAL_WRITE", "0") == "1"
