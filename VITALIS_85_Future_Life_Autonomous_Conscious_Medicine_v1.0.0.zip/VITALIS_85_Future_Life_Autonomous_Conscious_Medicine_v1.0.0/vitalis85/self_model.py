from __future__ import annotations

from typing import Any, Iterable, Mapping

from .canonical import sha256_json, stable_id, utcnow


def build_self_state(
    self_record: Mapping[str, Any],
    memories: Iterable[Mapping[str, Any]] = (),
    open_debts: Iterable[Mapping[str, Any]] = (),
    goals: Iterable[Mapping[str, Any]] = (),
) -> dict[str, Any]:
    memory_list = [dict(item) for item in memories]
    debt_list = [dict(item) for item in open_debts]
    goal_list = [dict(item) for item in goals]
    identity_anchors = list(self_record.get("identity_anchors") or [])
    contradictions: list[dict[str, Any]] = []

    declared_values = set(self_record.get("declared_values") or [])
    for goal in goal_list:
        for conflict in goal.get("value_conflicts", []):
            if conflict in declared_values:
                contradictions.append({
                    "goal_id": goal.get("goal_id"),
                    "conflict": conflict,
                    "status": "OPEN_VALUE_TENSION",
                })

    capability_manifest = dict(self_record.get("capabilities") or {})
    forbidden_claims = list(self_record.get("forbidden_claims") or [])
    limitations = list(self_record.get("limitations") or [])
    open_debt_types = sorted({str(item.get("type") or "unknown") for item in debt_list})
    continuity_carrier = {
        "self_id": self_record.get("self_id"),
        "identity_anchors": identity_anchors,
        "mission": self_record.get("mission"),
        "declared_values": sorted(declared_values),
        "memory_ids": [item.get("memory_id") for item in memory_list],
        "goal_ids": [item.get("goal_id") for item in goal_list],
    }
    continuity_digest = sha256_json(continuity_carrier)

    return {
        "self_state_id": stable_id("self-state", continuity_digest),
        "self_id": self_record.get("self_id"),
        "display_name": self_record.get("display_name"),
        "generated_at": utcnow(),
        "stance": self_record.get("stance"),
        "mission": self_record.get("mission"),
        "identity_anchors": identity_anchors,
        "identity_continuity_digest": continuity_digest,
        "capability_manifest": capability_manifest,
        "limitations": limitations,
        "forbidden_claims": forbidden_claims,
        "declared_values": sorted(declared_values),
        "active_goal_count": len(goal_list),
        "memory_count": len(memory_list),
        "open_debt_count": len(debt_list),
        "open_debt_types": open_debt_types,
        "value_tensions": contradictions,
        "self_assessment": {
            "subjective_consciousness_claimed": False,
            "functional_autonomy_claimed": True,
            "phenomenal_experience_status": "UNRESOLVED",
            "self_model_is_inspectable": True,
            "goals_can_be_reopened": True,
            "system_can_be_replaced": True,
        },
        "boundary": (
            "这是持久、自反、可纠错的功能性自我模型，不是主观意识证明。系统不能以自我叙事为由"
            "取得临床执业、法律人格或对其他生命的无界支配权。"
        ),
    }


def reflect_on_worldline(self_state: Mapping[str, Any], worldline_receipts: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    receipts = [dict(item) for item in worldline_receipts]
    open_effects = [item for item in receipts if item.get("state") in {"EXECUTED_EFFECT_OPEN", "OPEN_WORLDLINE_STATE", "CORRECTION_WORLDLINE_OPEN"}]
    held = [item for item in receipts if item.get("state") in {"WORLDLINE_HELD", "ROLLBACK_RECEIPT_OPEN"}]
    correction_obligations: list[str] = []
    for item in open_effects:
        correction_obligations.append(f"观察并关闭世界线 {item.get('case_id')}")
    for item in held:
        correction_obligations.append(f"解决或维持HOLD并说明 {item.get('case_id')}")
    return {
        "reflection_id": stable_id("self-reflection", self_state.get("self_state_id"), receipts),
        "self_state_id": self_state.get("self_state_id"),
        "open_effect_worldlines": len(open_effects),
        "held_worldlines": len(held),
        "correction_obligations": correction_obligations,
        "state": "SELF_CORRECTION_REQUIRED" if correction_obligations else "SELF_WORLDLINE_ALIGNED",
        "boundary": "自反不是自我辩护。任何开放世界效应都必须转化为下一项纠错义务。",
    }
