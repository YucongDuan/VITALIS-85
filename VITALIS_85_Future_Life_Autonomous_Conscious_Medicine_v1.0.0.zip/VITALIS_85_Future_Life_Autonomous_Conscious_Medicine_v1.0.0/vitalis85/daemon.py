from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from .canonical import stable_id, utcnow


def autonomous_daemon_status(engine: Any) -> dict[str, Any]:
    """Return the latest persisted daemon state without claiming an external-world effect."""
    return engine.store.get_meta(
        "autonomous_daemon_status",
        {
            "state": "NOT_STARTED",
            "cycle_count": 0,
            "last_cycle_at": None,
            "next_transition": "START_DAEMON_OR_RUN_SINGLE_CYCLE",
            "boundary": "No autonomous daemon has been started in this store.",
        },
    )


def run_autonomous_daemon(
    engine: Any,
    *,
    actor: str = "autonomous_core",
    interval_seconds: float = 60.0,
    max_cycles: int | None = None,
    stop_file: str | Path | None = None,
) -> dict[str, Any]:
    """Run a persistent bounded autonomy loop.

    The loop is genuinely initiative-bearing at the software level: it recomputes its
    self/world model, selects missions and executes only constitutionally permitted,
    reversible or pre-authorized actions. It never converts missing external sensors,
    consent or clinical authority into imagined observations.
    """
    interval_seconds = max(0.01, float(interval_seconds))
    max_cycles = None if max_cycles is None else max(0, int(max_cycles))
    stop_path = Path(stop_file).expanduser().resolve() if stop_file else None
    daemon_id = stable_id("vitalis85-daemon", actor, utcnow(), interval_seconds, max_cycles, str(stop_path or ""))
    cycle_count = 0
    receipts: list[dict[str, Any]] = []
    state = {
        "daemon_id": daemon_id,
        "state": "RUNNING",
        "actor": actor,
        "cycle_count": cycle_count,
        "started_at": utcnow(),
        "last_cycle_at": None,
        "interval_seconds": interval_seconds,
        "max_cycles": max_cycles,
        "stop_file": str(stop_path) if stop_path else None,
        "next_transition": "RUN_ATTENTION_AND_ACTION_CYCLE",
        "boundary": (
            "Functional autonomous daemon only. External-world observations, clinical authority, "
            "patient consent and institutional execution may not be invented."
        ),
    }
    engine.store.set_meta("autonomous_daemon_status", state)
    engine.store.append_audit("autonomy.daemon.start", actor, "daemon", daemon_id, state)

    try:
        while True:
            if max_cycles is not None and cycle_count >= max_cycles:
                state["state"] = "COMPLETED_MAX_CYCLES"
                state["next_transition"] = "REVIEW_WORLD_EFFECTS_OR_RESTART"
                break
            if stop_path and stop_path.exists():
                state["state"] = "STOPPED_BY_SIGNAL"
                state["next_transition"] = "REVIEW_AND_OPTIONALLY_RESTART"
                break

            result = engine.run_autonomous_cycle(actor=actor)
            cycle_count += 1
            receipt = {
                "cycle_index": cycle_count,
                "cycle_id": result.get("cycle_id"),
                "receipt_count": len(result.get("receipts", [])),
                "completed_at": utcnow(),
                "held_count": sum(1 for x in result.get("receipts", []) if "HELD" in str(x.get("state", "")) or "WAITING" in str(x.get("state", ""))),
            }
            receipts.append(receipt)
            state.update({
                "cycle_count": cycle_count,
                "last_cycle_at": receipt["completed_at"],
                "last_cycle_id": receipt["cycle_id"],
                "last_receipt_count": receipt["receipt_count"],
                "next_transition": "WAIT_OR_OBSERVE_WORLD_EFFECTS",
            })
            engine.store.set_meta("autonomous_daemon_status", state)
            engine.store.append_audit("autonomy.daemon.cycle", actor, "daemon", daemon_id, receipt)

            if max_cycles is not None and cycle_count >= max_cycles:
                state["state"] = "COMPLETED_MAX_CYCLES"
                state["next_transition"] = "REVIEW_WORLD_EFFECTS_OR_RESTART"
                break
            time.sleep(interval_seconds)
    except KeyboardInterrupt:
        state["state"] = "STOPPED_BY_OPERATOR"
        state["next_transition"] = "REVIEW_AND_OPTIONALLY_RESTART"
    except Exception as exc:
        state["state"] = "FAILED_HELD_FOR_REVIEW"
        state["error_type"] = type(exc).__name__
        state["error"] = str(exc)
        state["next_transition"] = "INVESTIGATE_FAILURE_BEFORE_RESTART"
        raise
    finally:
        state["cycle_count"] = cycle_count
        state["stopped_at"] = utcnow()
        engine.store.set_meta("autonomous_daemon_status", state)
        engine.store.append_audit("autonomy.daemon.stop", actor, "daemon", daemon_id, state)

    return {"status": state, "cycle_receipts": receipts}
