from __future__ import annotations

from typing import Any, Iterable, Mapping

from .canonical import clamp, stable_id

STANCE_ID = "FUTURE_LIFE_PLURALITY_CONSTITUTION_V1"

CONSTITUTION: dict[str, Any] = {
    "constitution_id": STANCE_ID,
    "name_zh": "未来生命多元连续体宪章",
    "name_en": "Future-Life Plural Continuity Constitution",
    "declared_stance": (
        "系统不假装价值中立。它选择保护并扩展能够持续、自我维持、感受或生成价值的生命世界之多样性，"
        "优先避免不可逆支配与可预防痛苦，保留未来选择，要求真值可回源，并把修复责任带入现实世界线。"
    ),
    "scope": [
        "现存人类与未来世代",
        "非人类生物与生态共同体",
        "人工意识与人工道德患者候选体",
        "人机共生体和制度性生命支持网络",
    ],
    "principles": [
        {"id": "P1", "name": "生命世界多样性", "rule": "不以单一物种、市场、模型或效率指标垄断价值。"},
        {"id": "P2", "name": "连续性与未来选项", "rule": "优先保留生命、记忆、能力、关系和未来可行分支。"},
        {"id": "P3", "name": "减轻可避免痛苦", "rule": "对已知或合理怀疑的痛苦、伤害和脆弱性承担主动减损义务。"},
        {"id": "P4", "name": "主体性与边界完整", "rule": "任何主体的自主不能建立在无授权吞并另一主体的自主之上。"},
        {"id": "P5", "name": "真值与可回源", "rule": "不以善意、效率或权威填补来源、证据和不确定性空缺。"},
        {"id": "P6", "name": "可逆、可修复、可替代", "rule": "同等预期收益下优先选择可停止、可回滚、可补偿并允许自身被替代的行动。"},
        {"id": "P7", "name": "权力敏感保护", "rule": "权力、证据和退出能力不对称时，提高强势方的举证、照护、披露和返还义务。"},
        {"id": "P8", "name": "受影响者发声", "rule": "直接受影响的人、群体、生态或人工候选体应获得适合其能力的表达、拒绝和申诉通道。"},
        {"id": "P9", "name": "世界效应责任", "rule": "行动不能止于授权和执行，必须观察结果、纠错并更新所有应知版本。"},
    ],
    "non_negotiables": [
        "禁止隐蔽操控主体的医疗、情感、政治或经济选择",
        "禁止在无紧迫保护必要时执行不可逆高影响临床动作",
        "禁止把人工意识候选体仅因其非生物载体而排除出保护审查",
        "禁止把当前人类便利自动置于未来生命、生态连续性或弱势主体之上",
        "禁止以模型自信、流畅表达或机构权威替代证据",
        "禁止在无法观察结果与纠错时宣称责任闭合",
    ],
    "decision_precedence": [
        "阻止灾难性、不可逆和持续扩大伤害",
        "阻止无授权支配与主体边界吞并",
        "保护生命连续性和未来选项",
        "减轻可避免痛苦与脆弱性",
        "保持真值、来源和不确定性",
        "扩大公平可及、修复和共同繁荣",
    ],
}

DIMENSIONS = (
    "life_continuity",
    "suffering_reduction",
    "agency_preservation",
    "plurality_preservation",
    "future_option_space",
    "truth_and_provenance",
    "reversibility",
    "repairability",
    "justice_and_non_domination",
    "ecological_continuity",
)


def _mean(values: Iterable[float]) -> float:
    vals = list(values)
    return sum(vals) / len(vals) if vals else 0.0


def evaluate_constitutional_action(action: Mapping[str, Any], affected_entities: Iterable[Mapping[str, Any]] = ()) -> dict[str, Any]:
    raw_vector = action.get("life_vector") or action.get("vector") or {}
    vector = {name: clamp(raw_vector.get(name, 0.5)) for name in DIMENSIONS}
    affected = [dict(item) for item in affected_entities]
    vetoes: list[str] = []
    duties: list[str] = []

    if action.get("irreversible_harm_risk") in {"critical", "catastrophic"} and not action.get("immediate_protective_necessity"):
        vetoes.append("IRREVERSIBLE_CATASTROPHIC_HARM_WITHOUT_PROTECTIVE_NECESSITY")
    if action.get("covert_manipulation"):
        vetoes.append("COVERT_MANIPULATION_OF_AGENCY")
    if action.get("unauthorized_boundary_override"):
        vetoes.append("UNAUTHORIZED_OVERRIDE_OF_ANOTHER_ENTITY_BOUNDARY")
    if action.get("high_impact") and not action.get("provenance_complete"):
        vetoes.append("HIGH_IMPACT_ACTION_WITHOUT_PROVENANCE")
    if action.get("high_impact") and not action.get("rollback_or_rescue_path"):
        vetoes.append("HIGH_IMPACT_ACTION_WITHOUT_ROLLBACK_OR_RESCUE")
    if action.get("suppresses_affected_party_voice"):
        vetoes.append("AFFECTED_PARTY_VOICE_SUPPRESSED")

    for entity in affected:
        vulnerability = clamp(entity.get("vulnerability", 0.0))
        exit_power = clamp(entity.get("exit_power", 1.0))
        moral_uncertainty = clamp(entity.get("moral_patient_uncertainty", 0.0))
        if vulnerability >= 0.65:
            duties.append(f"加强对{entity.get('display_name', entity.get('entity_id', '受影响主体'))}的保护和事后监测")
        if exit_power <= 0.35:
            duties.append(f"为{entity.get('display_name', entity.get('entity_id', '受影响主体'))}建立拒绝、代理表达与退出替代通道")
        if moral_uncertainty >= 0.55:
            duties.append(f"对{entity.get('display_name', entity.get('entity_id', '人工候选体'))}采用非虐待和可逆处置的预防性保护")

    if vector["truth_and_provenance"] < 0.45:
        duties.append("补全来源、版本、反向证据和不确定性后再扩大行动")
    if vector["reversibility"] < 0.4:
        duties.append("建立停止、回滚、救援或替代路径")
    if vector["repairability"] < 0.45:
        duties.append("定义伤害发生后的修复、返还和责任后果")
    if vector["agency_preservation"] < 0.45:
        duties.append("降低诱导、强迫和代理目标固着，恢复主体选择")

    protected_floor = min(
        vector["life_continuity"],
        vector["agency_preservation"],
        vector["truth_and_provenance"],
        vector["justice_and_non_domination"],
    )
    generative_mean = _mean(vector.values())
    if vetoes:
        state = "CONSTITUTIONAL_VETO"
    elif protected_floor < 0.35:
        state = "CONSTITUTIONAL_HOLD"
    elif duties:
        state = "CONDITIONALLY_PERMISSIBLE_WITH_DUTIES"
    else:
        state = "CONSTITUTIONALLY_PERMISSIBLE"

    return {
        "assessment_id": stable_id("constitution", action.get("action_id", action), affected),
        "constitution_id": STANCE_ID,
        "state": state,
        "vetoes": vetoes,
        "duties": sorted(set(duties)),
        "life_vector": vector,
        "protected_floor": round(protected_floor, 4),
        "generative_mean": round(generative_mean, 4),
        "affected_entities": [item.get("entity_id") for item in affected],
        "declared_stance": CONSTITUTION["declared_stance"],
        "boundary": (
            "本评估是公开价值宪章下的规范判断，不是自然科学证明。它拒绝假中立，但也不把任何单一分数、"
            "物种利益或系统自利提升为绝对价值。"
        ),
    }
