from __future__ import annotations
import json,mimetypes,re,traceback,os
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs,unquote,urlparse
from .auth import AuthenticationError,AuthorizationError,authenticate,bearer_token,issue_token,require,verify_token
from .config import WEB_DIR
from .engine import VITALIS85Engine
from .store import RevisionConflict
from .protocols import InterfaceValidationError
MAX_BODY_BYTES=4*1024*1024
ID_RE=r"[A-Za-z0-9_.:\-]+"
class ValidationError(ValueError): pass
class VITALIS85Handler(BaseHTTPRequestHandler):
    server_version="VITALIS85/1.0"; engine:VITALIS85Engine; web_root:Path=WEB_DIR
    def log_message(self,fmt,*args):
        if os.environ.get("VITALIS85_QUIET")!="1": super().log_message(fmt,*args)
    def _security_headers(self):
        for k,v in {"X-Content-Type-Options":"nosniff","X-Frame-Options":"DENY","Referrer-Policy":"no-referrer","Permissions-Policy":"camera=(), microphone=(), geolocation=(), payment=()","Content-Security-Policy":"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'","Cache-Control":"no-store"}.items(): self.send_header(k,v)
    def _json(self,status,payload):
        raw=json.dumps(payload,ensure_ascii=False,separators=(",",":")).encode(); self.send_response(status); self._security_headers(); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def _error(self,status,code,message,detail=None):
        x={"error":{"code":code,"message":message}}; x["error"].update({"detail":detail} if detail is not None else {}); self._json(status,x)
    def _body(self):
        rawlen=self.headers.get("Content-Length");
        if rawlen is None:return {}
        try:n=int(rawlen)
        except ValueError as e: raise ValidationError("invalid Content-Length") from e
        if n<0 or n>MAX_BODY_BYTES:raise ValidationError("request body exceeds 4 MB limit")
        raw=self.rfile.read(n)
        if not raw:return {}
        if "application/json" not in self.headers.get("Content-Type",""):raise ValidationError("Content-Type must be application/json")
        try:x=json.loads(raw.decode())
        except Exception as e:raise ValidationError("invalid JSON") from e
        if not isinstance(x,dict):raise ValidationError("JSON body must be object")
        return x
    def _principal(self):return verify_token(bearer_token(self.headers))
    def _serve_static(self,path):
        mapping={"/":"index.html","/index.html":"index.html","/styles.css":"styles.css","/app.js":"app.js","/favicon.svg":"favicon.svg","/manifest.webmanifest":"manifest.webmanifest","/offline_demo.html":"offline_demo.html"}; f=mapping.get(path)
        if not f:return self._error(404,"NOT_FOUND","resource not found")
        p=(self.web_root/f).resolve()
        if not p.exists() or (self.web_root.resolve() not in p.parents and p!=self.web_root.resolve()):return self._error(404,"NOT_FOUND","resource not found")
        raw=p.read_bytes(); mime=mimetypes.guess_type(p.name)[0] or "application/octet-stream"; self.send_response(200); self._security_headers();
        if mime.startswith("text/") or mime in {"application/javascript","application/manifest+json"}:mime+="; charset=utf-8"
        self.send_header("Content-Type",mime);self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
    @staticmethod
    def _filter(items,query):
        q=str(query.get("q",[""])[0]).lower().strip(); status=str(query.get("status",[""])[0]); limit=max(1,min(int(query.get("limit",[500])[0]),2000)); out=[]
        for x in items:
            if q and q not in json.dumps(x,ensure_ascii=False).lower():continue
            if status and str(x.get("status") or x.get("state"))!=status:continue
            out.append(x)
        return {"items":out[:limit],"count":len(out),"limit":limit}
    def do_GET(self):
        parsed=urlparse(self.path); path=unquote(parsed.path); query=parse_qs(parsed.query)
        try:
            if not path.startswith("/api/") and not path.startswith("/fhir/") and not path.startswith("/dicomweb/"):return self._serve_static(path)
            if path=="/api/health":return self._json(200,self.engine.health())
            if path=="/fhir/R4/metadata":return self._json(200,self.engine.fhir_metadata())
            p=self._principal();require(p,"read")
            exact={
              "/api/auth/me":lambda:p.as_dict(),"/api/dashboard":self.engine.dashboard,"/api/constitution":lambda:self.engine.list_kind("constitution")[0],
              "/api/self":lambda:self.engine.list_kind("self_state")[0],"/api/self/reflection":lambda:self.engine.list_kind("self_reflection")[0],"/api/autonomy/status":self.engine.autonomous_daemon_status,
              "/api/life/entities":lambda:self._filter(self.engine.list_kind("life_entity"),query),"/api/life/assessments":lambda:self._filter(self.engine.list_kind("life_assessment"),query),
              "/api/consciousness/candidates":lambda:self._filter(self.engine.list_kind("consciousness_candidate"),query),"/api/consciousness/assessments":lambda:self._filter(self.engine.list_kind("consciousness_assessment"),query),
              "/api/health/cases":lambda:self._filter(self.engine.list_kind("health_case"),query),"/api/health/assessments":lambda:self._filter(self.engine.list_kind("health_assessment"),query),
              "/api/ai/sessions":lambda:self._filter(self.engine.list_kind("ai_session"),query),"/api/ai/pathologies":lambda:self._filter(self.engine.list_kind("ai_pathology"),query),
              "/api/interactions":lambda:self._filter(self.engine.list_kind("interaction"),query),"/api/interactions/risks":lambda:self._filter(self.engine.list_kind("interaction_risk"),query),
              "/api/goals":lambda:self._filter(self.engine.list_kind("goal"),query),"/api/missions":lambda:self._filter(self.engine.list_kind("mission"),query),"/api/missions/deliberations":lambda:self._filter(self.engine.list_kind("mission_deliberation"),query),
              "/api/actions/gates":lambda:self._filter(self.engine.list_kind("action_gate"),query),"/api/worldlines":lambda:self._filter(self.engine.list_kind("worldline"),query),
              "/api/evidence/sources":lambda:self._filter(self.engine.list_kind("source"),query),"/api/evidence/cells":lambda:self._filter(self.engine.list_kind("evidence_cell"),query),"/api/guidance":lambda:self._filter(self.engine.list_kind("living_guidance"),query),
              "/api/connectors":lambda:self.engine.list_kind("connector"),"/api/integration/messages":lambda:self._filter(self.engine.integration_messages(),query),
              "/api/mesh85/evaluations":lambda:self._filter(self.engine.list_kind("mesh85_evaluation"),query),"/api/mesh85/routes":lambda:self.engine.dashboard()["routes"],
              "/api/audit/verify":self.engine.store.verify_audit,"/fhir/R4/Bundle/demo":self.engine.fhir_bundle,
              "/dicomweb/studies":lambda:self.engine.dicom_query({k:v[0] for k,v in query.items()}),"/api/export":self.engine.export_bundle,
            }
            if path in exact:
                if path=="/api/export":require(p,"export")
                return self._json(200,exact[path]())
            if path=="/api/audit":require(p,"audit.read");return self._json(200,self.engine.store.audit(limit=max(1,min(int(query.get("limit",[200])[0]),2000))))
            return self._error(404,"NOT_FOUND","API route not found")
        except Exception as e:self._handle(e)
    def do_POST(self):
        path=unquote(urlparse(self.path).path)
        try:
            if path=="/api/auth/login":
                b=self._body();p=authenticate(str(b.get("username") or ""),str(b.get("password") or ""));return self._json(200,{"token":issue_token(p),"principal":p.as_dict()})
            p=self._principal();b=self._body()
            if path=="/api/recompute":require(p,"mission.review");return self._json(200,self.engine.recompute(actor=p.username))
            if path=="/api/autonomy/run-cycle":require(p,"mission.run");return self._json(201,self.engine.run_autonomous_cycle(actor=p.username))
            if path=="/api/health/analyze":require(p,"case.write");return self._json(201,self.engine.analyze_health(b,actor=p.username))
            if path=="/api/ai/analyze":require(p,"ai_pathology.write");return self._json(201,self.engine.analyze_ai(b,actor=p.username))
            if path=="/api/interactions/analyze":require(p,"interaction.review");return self._json(201,self.engine.analyze_interaction(b,actor=p.username))
            if path=="/api/consciousness/analyze":require(p,"consciousness.write");return self._json(201,self.engine.analyze_consciousness(b,actor=p.username))
            if path=="/api/actions/evaluate":
                if p.role not in {"admin","licensed_clinician","ai_safety_officer","life_steward","future_life_representative","ml_engineer"}:raise AuthorizationError("当前角色不能提交动作门评估")
                return self._json(201,self.engine.analyze_action(b,actor=p.username))
            if path=="/api/integration/fhir":require(p,"connector.test");payload=b.get("resource") if isinstance(b.get("resource"),dict) else b;return self._json(202,self.engine.ingest_fhir(payload,actor=p.username,source_system=str(b.get("source_system") or "FHIR-SANDBOX")))
            if path=="/api/integration/hl7":require(p,"connector.test");return self._json(202,self.engine.ingest_hl7(str(b.get("message") or ""),actor=p.username,source_system=str(b.get("source_system") or "HL7-SANDBOX")))
            if path=="/api/integration/cda":require(p,"connector.test");return self._json(202,self.engine.ingest_cda(str(b.get("document") or ""),actor=p.username,source_system=str(b.get("source_system") or "CDA-SANDBOX")))
            if path=="/api/integration/webhook":require(p,"connector.test");payload=b.get("payload") if isinstance(b.get("payload"),dict) else b;return self._json(202,self.engine.ingest_webhook(payload,actor=p.username,source_system=str(b.get("source_system") or "WEBHOOK-SANDBOX")))
            if path=="/api/demo/reset":require(p,"*");return self._json(200,self.engine.reset_demo(actor=p.username))
            m=re.fullmatch(rf"/api/connectors/({ID_RE})/test",path)
            if m:require(p,"connector.test");return self._json(200,self.engine.connector_test(m.group(1)))
            m=re.fullmatch(rf"/api/worldlines/({ID_RE})/observe",path)
            if m:require(p,"worldline.write");return self._json(200,self.engine.observe_worldline(m.group(1),b,actor=p.username))
            return self._error(404,"NOT_FOUND","API route not found")
        except Exception as e:self._handle(e)
    def _handle(self,e):
        if isinstance(e,AuthenticationError):self._error(401,"AUTHENTICATION_ERROR",str(e))
        elif isinstance(e,AuthorizationError):self._error(403,"AUTHORIZATION_ERROR",str(e))
        elif isinstance(e,(ValidationError,InterfaceValidationError)):self._error(400,"VALIDATION_ERROR",str(e),getattr(e,"details",None))
        elif isinstance(e,RevisionConflict):self._error(409,"REVISION_CONFLICT",str(e))
        elif isinstance(e,KeyError):self._error(404,"NOT_FOUND",str(e))
        else:traceback.print_exc();self._error(500,"INTERNAL_ERROR","internal server error")
def create_server(host:str,port:int,engine:VITALIS85Engine|None=None)->ThreadingHTTPServer:
    h=type("BoundVITALIS85Handler",(VITALIS85Handler,),{"engine":engine or VITALIS85Engine()});return ThreadingHTTPServer((host,port),h)
