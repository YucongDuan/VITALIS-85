#!/usr/bin/env sh
set -eu
DB=${VITALIS85_DB:-/opt/vitalis85/var/vitalis85.db}
OUT=${1:-/opt/vitalis85/backups/vitalis85-$(date +%Y%m%d-%H%M%S).db}
mkdir -p "$(dirname "$OUT")"
python3 - "$DB" "$OUT" <<'PY2'
import sqlite3,sys
a=sqlite3.connect(sys.argv[1]);b=sqlite3.connect(sys.argv[2]);a.backup(b);b.close();a.close()
PY2
echo "$OUT"
