from __future__ import annotations

import json
import re
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .canonical import sha256
from .context_model import (
    CONTEXT_PROFILES, DEFAULT_BLOCK_PUBLIC_PHRASES, DEFAULT_PUBLIC_REFRAME, DEFAULT_REVIEW_PUBLIC_PHRASES,
    ContextFinding, ContextPacket,
)

PUBLIC_LIKE = {"public", "media", "customer"}
MATERIAL_AUDIENCES = {"affected_party", "executor", "partner", "customer", "regulator", "legal"}


def context_to_carrier(packet: ContextPacket) -> dict[str, Any]:
    data = asdict(packet)
    data.pop("source_name", None)
    data["mesh_version"] = data.pop("version")
    return data


def _contains(text: str, phrase: str) -> bool:
    return phrase.casefold() in text.casefold()


def audit_text(text: str, audience: str = "public", *, prohibited_claims: tuple[str, ...] = (), lexicon: dict[str, Any] | None = None) -> dict[str, Any]:
    if audience not in CONTEXT_PROFILES:
        raise ValueError(f"unsupported audience: {audience}")
    findings: list[ContextFinding] = []
    lexicon = lexicon or {}
    block_values = tuple(str(x) for x in lexicon.get("block_public", DEFAULT_BLOCK_PUBLIC_PHRASES))
    review_values = tuple(str(x) for x in lexicon.get("review_public", DEFAULT_REVIEW_PUBLIC_PHRASES))
    reframes = {str(k): str(v) for k, v in dict(lexicon.get("reframes", DEFAULT_PUBLIC_REFRAME)).items()}
    block = block_values if audience in PUBLIC_LIKE else ()
    review = review_values if audience in PUBLIC_LIKE else ()
    for phrase in block:
        if _contains(text, phrase):
            findings.append(ContextFinding("PRIVATE_INTENT_LEAK", f"public-facing text exposes internal strategic phrase: {phrase}", "blocked"))
    for phrase in review:
        if _contains(text, phrase):
            findings.append(ContextFinding("REPUTATION_REVIEW", f"phrase may invite hostile or self-interested interpretation: {phrase}", "review"))
    for phrase in prohibited_claims:
        if _contains(text, phrase):
            findings.append(ContextFinding("PROHIBITED_CLAIM", f"text contains prohibited claim: {phrase}", "blocked"))
    if audience in PUBLIC_LIKE and re.search(r"(唯一|绝对|已经彻底|必然|全部解决|无人能绕开)", text):
        findings.append(ContextFinding("OVERCLAIM_RISK", "absolute or exclusive wording requires unusually strong evidence", "review"))
    status = "BLOCK" if any(f.level == "blocked" for f in findings) else ("REVIEW" if findings else "PASS")
    return {
        "audience": audience,
        "status": status,
        "findings": [f.to_dict() for f in findings],
        "reframes": {k: v for k, v in reframes.items() if _contains(text, k)},
    }


def _eligible_claims(packet: ContextPacket, audience: str) -> list[dict[str, Any]]:
    claims = [c for c in packet.claims if audience in c["audiences"]]
    return sorted(claims, key=lambda c: (c["order"], c["id"]))


def _eligible_objectives(packet: ContextPacket, audience: str) -> list[dict[str, Any]]:
    return [o for o in packet.objectives if audience in o["audiences"]]


def _eligible_facts(packet: ContextPacket, audience: str) -> list[dict[str, Any]]:
    return [f for f in packet.facts if audience in f["audiences"]]


def release_packet(packet: ContextPacket, audience: str) -> dict[str, Any]:
    if audience not in CONTEXT_PROFILES:
        raise ValueError(f"unsupported audience: {audience}")
    claims = _eligible_claims(packet, audience)
    objectives = _eligible_objectives(packet, audience)
    facts = _eligible_facts(packet, audience)
    included_ids = {c["id"] for c in claims}
    required_ids = set(packet.required_disclosures.get(audience, ()))
    missing_required = sorted(required_ids - included_ids)

    findings: list[ContextFinding] = []
    for claim in claims:
        if claim["kind"] == "fact" and not claim["fact_refs"]:
            findings.append(ContextFinding("UNSOURCED_FACT_CLAIM", "fact claim has no fact reference", "blocked", claim["id"]))
        for ref in claim["fact_refs"]:
            fact = next(x for x in packet.facts if x["id"] == ref)
            if audience not in fact["audiences"]:
                findings.append(ContextFinding("FACT_NOT_DISCLOSABLE", "claim references a fact not allowed for this audience", "blocked", claim["id"]))
    if missing_required:
        findings.append(ContextFinding("MATERIAL_DISCLOSURE_MISSING", f"required claims absent: {', '.join(missing_required)}", "blocked"))
    if audience in PUBLIC_LIKE and objectives:
        findings.append(ContextFinding("PRIVATE_OBJECTIVE_EXPOSED", "private objective entered a public-like release", "blocked"))
    if packet.phase in {"T0_HOLD", "T1_PROTECT"} and audience in PUBLIC_LIKE:
        findings.append(ContextFinding("TIMING_HOLD", "public release is premature before validation/signalling phase", "blocked"))

    title = packet.title or packet.packet_id
    body_lines = [c["text"] for c in claims]
    body = "\n\n".join(body_lines)
    text_audit = audit_text(body, audience, prohibited_claims=packet.prohibited_claims, lexicon=packet.lexicon)
    findings.extend(ContextFinding(x["code"], x["message"], x["level"], x.get("item_id", "")) for x in text_audit["findings"])

    if audience in MATERIAL_AUDIENCES:
        mandatory_facts = {f["id"] for f in packet.facts if f["materiality"] == "mandatory" and audience in f["audiences"]}
        referenced = {ref for c in claims for ref in c["fact_refs"]}
        omitted = sorted(mandatory_facts - referenced)
        if omitted:
            findings.append(ContextFinding("MANDATORY_FACT_OMITTED", f"mandatory facts omitted: {', '.join(omitted)}", "blocked"))

    status = "BLOCK" if any(f.level == "blocked" for f in findings) else ("REVIEW" if any(f.level == "review" for f in findings) else "PASS")
    result = {
        "system": "DIKWP-MESH 8.5 Context-Relative Truth and Responsibility Disclosure",
        "packet_id": packet.packet_id,
        "audience": audience,
        "phase": packet.phase,
        "title": title,
        "claims": claims,
        "facts": facts,
        "objectives": objectives,
        "rendered_text": body,
        "required_disclosures": sorted(required_ids),
        "missing_required_disclosures": missing_required,
        "findings": [f.to_dict() for f in findings],
        "status": status,
        "truth_boundary": "May withhold non-material private motives; may not contradict verified facts or omit material facts owed to this audience.",
    }
    result["release_digest"] = sha256(result)
    return result


def redteam_release(release: dict[str, Any]) -> dict[str, Any]:
    text = release.get("rendered_text", "")
    interpretations: list[dict[str, str]] = []
    patterns = [
        (r"开源|开放", "可能被质疑为以开放吸引采用、再把关键能力转为收费；应公开版本边界与持续服务边界。"),
        (r"唯一|首个|领先|颠覆", "可能被解读为过度自我定位；应给出可复核证据或降级表述。"),
        (r"官方|标准|认证", "可能被误认为获得政府或标准组织背书；必须说明授权主体。"),
        (r"公益|公共", "若同时存在商业模式，不能暗示唯一动机是无偿公益；应说明可持续维护机制。"),
        (r"中国自主|国家", "可能被解读为借国家叙事抬高私人项目；应只陈述可验证的公共价值与合作范围。"),
        (r"终极|彻底", "可能被解读为不可证实的宏大主张；应区分愿景、候选和已验证结果。"),
    ]
    for pattern, message in patterns:
        if re.search(pattern, text):
            interpretations.append({"trigger": pattern, "hostile_reading": message})
    if not interpretations:
        interpretations.append({"trigger": "none", "hostile_reading": "未发现预置高风险解释触发词；仍需人工审阅上下文、时机和利益关系。"})
    return {
        "packet_id": release.get("packet_id"),
        "audience": release.get("audience"),
        "status": "REVIEW_REQUIRED" if interpretations else "PASS",
        "interpretations": interpretations,
        "rule": "Red-team interpretation is a risk forecast, not a claim about audience intent.",
    }


def compare_releases(internal: dict[str, Any], external: dict[str, Any]) -> dict[str, Any]:
    internal_facts = {f["id"]: f["text"] for f in internal.get("facts", [])}
    external_refs = {r for c in external.get("claims", []) for r in c.get("fact_refs", [])}
    missing_trace = sorted(ref for ref in external_refs if ref not in internal_facts)
    leaked_objectives = [o["id"] for o in external.get("objectives", [])]
    checks = {
        "all_external_fact_refs_traceable": not missing_trace,
        "no_private_objective_in_external": not leaked_objectives,
        "external_not_blocked": external.get("status") != "BLOCK",
    }
    return {
        "valid": all(checks.values()),
        "checks": checks,
        "missing_fact_trace": missing_trace,
        "leaked_objectives": leaked_objectives,
        "principle": "Different audiences may receive different completeness; shared factual claims must retain a common source.",
    }


def render_markdown(release: dict[str, Any]) -> str:
    lines = [f"# {release['title']}", ""]
    if release["rendered_text"]:
        lines.append(release["rendered_text"])
        lines.append("")
    lines += [
        "---",
        f"Audience: {release['audience']}",
        f"Phase: {release['phase']}",
        f"Release status: {release['status']}",
        "",
        "> 本文件采用受众适配的真值保持披露：不公开全部内部动机，但不改变事实、不遗漏本受众依法依约应知的重要事项。",
    ]
    return "\n".join(lines)


def write_public_bundle(packet: ContextPacket, out_dir: str | Path, *, audiences: tuple[str, ...] = ("public", "media", "customer")) -> dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    index: dict[str, Any] = {}
    for audience in audiences:
        release = release_packet(packet, audience)
        (out / f"{audience}.release.json").write_text(json.dumps(release, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
        (out / f"{audience}.md").write_text(render_markdown(release), encoding="utf-8")
        index[audience] = {"status": release["status"], "digest": release["release_digest"]}
    public_text = "\n".join(p.read_text(encoding="utf-8") for p in out.rglob("*.md"))
    leak = audit_text(public_text, "public", prohibited_claims=packet.prohibited_claims, lexicon=packet.lexicon)
    verification = {
        "packet_id": packet.packet_id,
        "audiences": index,
        "public_leak_audit": leak,
        "safe_to_publish": leak["status"] == "PASS" and all(v["status"] != "BLOCK" for v in index.values()),
    }
    (out / "PUBLIC_RELEASE_VERIFICATION.json").write_text(json.dumps(verification, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    return verification
