from __future__ import annotations

from copy import deepcopy
from typing import Any

from .canonical import sha256
from .errors import SpecError

ROLE_KEYS = (
    "analysis_owner", "decision_owner", "execution_owner",
    "disclosure_approver", "appeal_reviewer",
)


def _id(value: Any, path: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SpecError(f"{path} must be a non-empty string")
    return value.strip()


def normalize_authority(raw: Any, *, source_name: str = "") -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise SpecError("authority carrier must be an object")
    value = deepcopy(raw)
    if str(value.get("mesh_version", "")) not in {"8.5", "8.5.0"}:
        raise SpecError("authority mesh_version must be 8.5")
    value["mesh_version"] = "8.5"
    value["case_id"] = _id(value.get("case_id"), "authority.case_id")
    actors = value.setdefault("actors", [])
    if not isinstance(actors, list) or not actors:
        raise SpecError("authority.actors must be a non-empty list")
    seen: set[str] = set()
    for index, actor in enumerate(actors):
        actor_id = _id(actor.get("id"), f"authority.actors[{index}].id")
        if actor_id in seen:
            raise SpecError(f"duplicate authority actor: {actor_id}")
        seen.add(actor_id)
        actor["id"] = actor_id
        actor.setdefault("roles", [])
        actor.setdefault("permissions", [])
        actor.setdefault("independent_from", [])
        actor.setdefault("organization", "")
    assignments = value.setdefault("assignments", {})
    if not isinstance(assignments, dict):
        raise SpecError("authority.assignments must be an object")
    for key in ROLE_KEYS:
        assignments.setdefault(key, "")
        if assignments[key] and assignments[key] not in seen:
            raise SpecError(f"authority.assignments.{key} references absent actor")
    value.setdefault("required_permissions", {})
    value.setdefault("separation_rules", [
        ["decision_owner", "execution_owner"],
        ["decision_owner", "appeal_reviewer"],
    ])
    affected = value.setdefault("affected_party_voice", {})
    affected.setdefault("required", True)
    affected.setdefault("represented", False)
    affected.setdefault("representative_id", "")
    affected.setdefault("notice_required", True)
    affected.setdefault("consent_required", False)
    affected.setdefault("appeal_channel", "")
    affected.setdefault("participation_record", "")
    execution = value.setdefault("execution_authorization", {})
    execution.setdefault("authorized", False)
    execution.setdefault("authorization_id", "")
    execution.setdefault("action_id", "")
    execution.setdefault("approved_by", "")
    execution.setdefault("scope", [])
    execution.setdefault("expires_at", "")
    execution.setdefault("conditions", [])
    value.setdefault("source_name", source_name)
    return value


def evaluate_authority(authority: dict[str, Any], decision: dict[str, Any]) -> dict[str, Any]:
    actors = {actor["id"]: actor for actor in authority["actors"]}
    assignments = authority["assignments"]
    primary = decision.get("primary_action") or {}
    required = set(primary.get("required_authorities", []))
    checks: dict[str, bool] = {}
    findings: list[dict[str, str]] = []

    for key in ROLE_KEYS:
        checks[f"{key}_named"] = bool(assignments.get(key))
        if not checks[f"{key}_named"]:
            findings.append({"code": "AUTHORITY_ROLE_OPEN", "role": key, "message": f"{key} is not assigned"})

    decision_owner = actors.get(assignments.get("decision_owner", ""), {})
    actor_permissions = set(decision_owner.get("permissions", []))
    checks["primary_authority_available"] = required.issubset(actor_permissions)
    if not checks["primary_authority_available"]:
        findings.append({
            "code": "PRIMARY_AUTHORITY_MISSING",
            "message": "decision owner lacks required permissions: " + ", ".join(sorted(required - actor_permissions)),
        })

    checks["declared_separation_of_duties"] = True
    for left_role, right_role in authority.get("separation_rules", []):
        left = assignments.get(left_role)
        right = assignments.get(right_role)
        if left and right and left == right:
            checks["declared_separation_of_duties"] = False
            findings.append({"code": "SEPARATION_OF_DUTIES_OPEN", "message": f"{left_role} and {right_role} are assigned to the same actor"})

    appeal_id = assignments.get("appeal_reviewer", "")
    appeal_actor = actors.get(appeal_id, {})
    checks["appeal_independence"] = bool(appeal_id) and assignments.get("decision_owner") in set(appeal_actor.get("independent_from", []))
    if not checks["appeal_independence"]:
        findings.append({"code": "APPEAL_INDEPENDENCE_OPEN", "message": "appeal reviewer is not declared independent from decision owner"})

    affected = authority["affected_party_voice"]
    required_voice = bool(affected.get("required", True)) and bool(primary.get("affected_parties"))
    checks["affected_party_voice"] = (not required_voice) or (
        bool(affected.get("represented")) and bool(affected.get("appeal_channel")) and bool(affected.get("participation_record"))
    )
    if not checks["affected_party_voice"]:
        findings.append({"code": "AFFECTED_PARTY_VOICE_OPEN", "message": "affected party participation, notice, or appeal channel is incomplete"})

    auth = authority["execution_authorization"]
    primary_id = primary.get("id", "")
    checks["authorization_action_matches"] = (not auth.get("authorized")) or auth.get("action_id") == primary_id
    checks["authorization_approver_matches"] = (not auth.get("authorized")) or auth.get("approved_by") == assignments.get("decision_owner")
    checks["authorization_receipt_complete"] = (not auth.get("authorized")) or all([
        auth.get("authorization_id"), auth.get("action_id"), auth.get("approved_by"), auth.get("scope"),
    ])
    if auth.get("authorized") and not all((checks["authorization_action_matches"], checks["authorization_approver_matches"], checks["authorization_receipt_complete"])):
        findings.append({"code": "INVALID_EXECUTION_AUTHORIZATION", "message": "authorization receipt is incomplete or does not match the primary action"})

    recommendation_ready = all(v for k, v in checks.items() if k not in {"authorization_action_matches", "authorization_approver_matches", "authorization_receipt_complete"})
    execution_ready = recommendation_ready and bool(auth.get("authorized")) and checks["authorization_action_matches"] and checks["authorization_approver_matches"] and checks["authorization_receipt_complete"]
    state = "AUTHORIZED_FOR_EXECUTION" if execution_ready else ("READY_FOR_HUMAN_AUTHORIZATION" if recommendation_ready else "OPEN_AUTHORITY_STATE")
    receipt = {
        "case_id": authority["case_id"],
        "state": state,
        "recommendation_ready": recommendation_ready,
        "execution_ready": execution_ready,
        "checks": checks,
        "findings": findings,
        "execution_authorization": auth,
        "boundary": "A decision recommendation is not execution authority. High-impact action requires a distinct, valid human or institutional authorization receipt.",
    }
    receipt["authority_digest"] = sha256(receipt)
    return receipt
