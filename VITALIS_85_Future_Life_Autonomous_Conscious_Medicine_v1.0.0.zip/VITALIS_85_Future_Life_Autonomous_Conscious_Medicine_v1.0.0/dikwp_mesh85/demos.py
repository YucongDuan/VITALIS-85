from __future__ import annotations

from copy import deepcopy
from typing import Any


def payload(text: str, *, encoding: str = "utf-8") -> dict[str, Any]:
    if encoding == "utf-8":
        return {"encoding": "utf-8", "value": text}
    if encoding == "hex":
        return {"encoding": "hex", "value": text.encode("utf-8").hex()}
    raise ValueError(encoding)


def _non_p(record_id: str, kind: str, text: str = "", refs: list[str] | None = None, *, given: bool = True, encoding: str = "utf-8") -> dict[str, Any]:
    return {
        "id": record_id,
        "kind": kind,
        "given": given,
        "refs": refs or [],
        "payload": payload(text, encoding=encoding) if given and text else None,
    }


def _p(record_id: str, inputs: list[str], outputs: list[str], *, given: bool = True) -> dict[str, Any]:
    return {
        "id": record_id,
        "kind": "P",
        "given": given,
        "input": {"refs": inputs if given else [], "payload": None},
        "output": {"refs": outputs if given else [], "payload": None},
    }


def full_bidirectional(*, encoding: str = "utf-8") -> dict[str, Any]:
    records = [
        _non_p("d.input", "D", "forward input sameness", encoding=encoding),
        _non_p("i.input", "I", "forward input difference", encoding=encoding),
        _non_p("w.input", "W", "preserve all explicit core positions", encoding=encoding),
        _non_p("d.return", "D", "regenerated D content", encoding=encoding),
        _non_p("i.return", "I", "regenerated I content", encoding=encoding),
        _non_p("w.return", "W", "regenerated W content", encoding=encoding),
        _non_p("d.same.d", "D", refs=["d.input", "d.return"], encoding=encoding),
        _non_p("d.same.i", "D", refs=["i.input", "i.return"], encoding=encoding),
        _non_p("d.same.w", "D", refs=["w.input", "w.return"], encoding=encoding),
        _p("p.forward", ["d.input", "i.input", "w.input"], ["k.complete"]),
        _p(
            "p.return",
            ["k.complete"],
            ["d.return", "i.return", "w.return", "d.same.d", "d.same.i", "d.same.w"],
        ),
    ]
    all_except_k = [record["id"] for record in records]
    records.append(
        _non_p(
            "k.complete",
            "K",
            "complete five-position retention",
            refs=all_except_k,
            encoding=encoding,
        )
    )
    routes = [
        {"source": "d.input", "target": "p.forward"},
        {"source": "i.input", "target": "p.forward"},
        {"source": "w.input", "target": "p.forward"},
        {"source": "p.forward", "target": "k.complete"},
        {"source": "k.complete", "target": "p.return"},
    ]
    routes.extend(
        {"source": "p.return", "target": target}
        for target in ["d.return", "i.return", "w.return", "d.same.d", "d.same.i", "d.same.w"]
    )
    return {"mesh_version": "8.5", "records": records, "routes": routes}


def full_aliases() -> dict[str, Any]:
    return {
        "mesh_version": "8.5",
        "bindings": [
            {"alias": "完整五位置语义", "language": "zh-CN", "targets": ["k.complete"]},
            {"alias": "complete five-position semantics", "language": "en", "targets": ["k.complete"]},
            {"alias": "正向生成", "language": "zh-CN", "targets": ["p.forward"]},
            {"alias": "reverse regeneration", "language": "en", "targets": ["p.return"]},
        ],
    }


def forward_only(*, encoding: str = "utf-8") -> dict[str, Any]:
    records = [
        _non_p("d.input", "D", "same", encoding=encoding),
        _non_p("i.input", "I", "different", encoding=encoding),
        _non_p("w.input", "W", "value visible", encoding=encoding),
        _p("p.forward", ["d.input", "i.input", "w.input"], ["k.complete"]),
    ]
    records.append(
        _non_p(
            "k.complete",
            "K",
            "forward complete",
            refs=[record["id"] for record in records],
            encoding=encoding,
        )
    )
    routes = [
        {"source": "d.input", "target": "p.forward"},
        {"source": "i.input", "target": "p.forward"},
        {"source": "w.input", "target": "p.forward"},
        {"source": "p.forward", "target": "k.complete"},
    ]
    return {"mesh_version": "8.5", "records": records, "routes": routes}


def open_difference() -> dict[str, Any]:
    core = full_bidirectional()
    for record in core["records"]:
        if record["id"] == "i.return":
            record["given"] = False
            record["payload"] = None
            record["refs"] = []
    return core


def output_injection() -> dict[str, Any]:
    core = forward_only()
    core["routes"] = [
        route
        for route in core["routes"]
        if not (route["source"] == "p.forward" and route["target"] == "k.complete")
    ]
    return core


def value_visibility_open() -> dict[str, Any]:
    core = forward_only()
    for record in core["records"]:
        if record["id"] == "p.forward":
            record["input"]["refs"] = ["d.input", "i.input"]
    core["routes"] = [
        route
        for route in core["routes"]
        if not (route["source"] == "w.input" and route["target"] == "p.forward")
    ]
    return core


def continuity_parent() -> dict[str, Any]:
    return forward_only()


def continuity_child() -> dict[str, Any]:
    parent = forward_only()
    records = deepcopy(parent["records"])
    routes = deepcopy(parent["routes"])
    new_records = [
        _non_p("d.return", "D", "regenerated D"),
        _non_p("i.return", "I", "regenerated I"),
        _non_p("w.return", "W", "regenerated W"),
        _non_p("d.same.d", "D", refs=["d.input", "d.return"]),
        _non_p("d.same.i", "D", refs=["i.input", "i.return"]),
        _non_p("d.same.w", "D", refs=["w.input", "w.return"]),
        _p("p.forward.2", ["d.input", "i.input", "w.input"], ["k.complete.2"]),
        _p(
            "p.return.2",
            ["k.complete.2"],
            ["d.return", "i.return", "w.return", "d.same.d", "d.same.i", "d.same.w"],
        ),
    ]
    records.extend(new_records)
    all_except_new_k = [record["id"] for record in records]
    records.append(
        _non_p(
            "k.complete.2",
            "K",
            "append-only complete K",
            refs=all_except_new_k,
        )
    )
    routes.extend(
        [
            {"source": "d.input", "target": "p.forward.2"},
            {"source": "i.input", "target": "p.forward.2"},
            {"source": "w.input", "target": "p.forward.2"},
            {"source": "p.forward.2", "target": "k.complete.2"},
            {"source": "k.complete.2", "target": "p.return.2"},
        ]
    )
    routes.extend(
        {"source": "p.return.2", "target": target}
        for target in ["d.return", "i.return", "w.return", "d.same.d", "d.same.i", "d.same.w"]
    )
    return {"mesh_version": "8.5", "records": records, "routes": routes}


def collision_variant() -> dict[str, Any]:
    core = forward_only()
    for record in core["records"]:
        if record["id"] == "d.input":
            record["payload"] = payload("mutated same id")
    return core


def all_demos() -> dict[str, dict[str, Any]]:
    return {
        "full_bidirectional": full_bidirectional(),
        "forward_only": forward_only(),
        "open_difference": open_difference(),
        "output_injection": output_injection(),
        "value_visibility_open": value_visibility_open(),
        "continuity_parent": continuity_parent(),
        "continuity_child": continuity_child(),
    }
