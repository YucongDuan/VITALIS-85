from __future__ import annotations

from copy import deepcopy
from typing import Any

from .errors import SpecError

ALLOWED_DOMAINS = {"general", "medical", "research", "strategy", "governance", "engineering", "public_policy"}
ALLOWED_OPTION_KINDS = {"act", "observe", "test", "escalate", "stop", "defer", "protect", "remedy"}
REQUIRED_VECTOR_KEYS = {
    "benefit", "harm", "delay_cost", "reversibility", "information_gain", "agency_preservation",
    "justice", "provenance", "coordination", "deception_risk", "exploitation_risk", "correction_debt",
}
BURDEN_KEYS = {
    "money", "travel", "time", "procedure_pain", "infection_exposure", "family_disruption", "energy", "opportunity_cost",
}
CONTEXT_AUDIENCES = {
    "internal", "core_team", "affected_party", "executor", "partner", "customer", "public", "media", "regulator", "legal",
}


def _identifier(value: Any, *, path: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SpecError(f"{path} must be a non-empty string")
    if len(value) > 180:
        raise SpecError(f"{path} is too long")
    return value.strip()


def _unit_interval(value: Any, *, path: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise SpecError(f"{path} must be numeric") from exc
    if not 0.0 <= number <= 1.0:
        raise SpecError(f"{path} must be between 0 and 1")
    return number


def _unique_ids(items: list[dict[str, Any]], *, path: str) -> set[str]:
    seen: set[str] = set()
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            raise SpecError(f"{path}[{index}] must be an object")
        item_id = _identifier(item.get("id"), path=f"{path}[{index}].id")
        if item_id in seen:
            raise SpecError(f"duplicate id in {path}: {item_id}")
        seen.add(item_id)
    return seen


def normalize_active_case(raw: Any, *, source_name: str = "") -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise SpecError("active decision carrier must be an object")
    case = deepcopy(raw)
    version = str(case.get("mesh_version", ""))
    if version not in {"8.5", "8.5.0"}:
        raise SpecError("active decision mesh_version must be 8.5")
    case["mesh_version"] = "8.5"
    case["decision_id"] = _identifier(case.get("decision_id", case.get("case_id")), path="decision_id")
    case["title"] = _identifier(case.get("title"), path="title")
    domain = case.get("domain", "general")
    if domain not in ALLOWED_DOMAINS:
        raise SpecError(f"domain must be one of {sorted(ALLOWED_DOMAINS)}")
    case["domain"] = domain
    case["source_name"] = source_name

    context = case.setdefault("context", {})
    if not isinstance(context, dict):
        raise SpecError("context must be an object")
    context.setdefault("time_horizon_hours", 48)
    if float(context["time_horizon_hours"]) <= 0:
        raise SpecError("context.time_horizon_hours must be positive")
    population = context.setdefault("population", {})
    if domain == "medical":
        if not isinstance(population, dict) or not population:
            raise SpecError("medical cases require context.population")
        if not population.get("calibration_profile"):
            raise SpecError("medical cases require population.calibration_profile")
    context.setdefault("local_environment", {})
    context.setdefault("decision_window", "current")

    facts = case.setdefault("facts", [])
    evidence = case.setdefault("evidence", [])
    hypotheses = case.setdefault("hypotheses", [])
    options = case.setdefault("options", [])
    if not all(isinstance(value, list) for value in (facts, evidence, hypotheses, options)):
        raise SpecError("facts, evidence, hypotheses, and options must be lists")
    fact_ids = _unique_ids(facts, path="facts")
    evidence_ids = _unique_ids(evidence, path="evidence")
    hypothesis_ids = _unique_ids(hypotheses, path="hypotheses")
    option_ids = _unique_ids(options, path="options")
    if not hypotheses:
        raise SpecError("at least one hypothesis is required")
    if not options:
        raise SpecError("at least one option is required")

    for index, item in enumerate(facts):
        item["description"] = _identifier(item.get("description"), path=f"facts[{index}].description")
        item["reliability"] = _unit_interval(item.get("reliability", 1.0), path=f"facts[{index}].reliability")
        item.setdefault("status", "observed")
        item.setdefault("observer", "declared_observer")
        item.setdefault("recorded_at", "")

    for index, item in enumerate(evidence):
        item["label"] = _identifier(item.get("label"), path=f"evidence[{index}].label")
        item["reliability"] = _unit_interval(item.get("reliability", 1.0), path=f"evidence[{index}].reliability")
        fact_id = item.get("fact_id")
        if fact_id is not None and fact_id not in fact_ids:
            raise SpecError(f"evidence[{index}].fact_id references absent fact: {fact_id}")
        if item.get("direction", "support") not in {"support", "oppose"}:
            raise SpecError(f"evidence[{index}].direction must be support or oppose")

    for index, item in enumerate(hypotheses):
        item["label"] = _identifier(item.get("label"), path=f"hypotheses[{index}].label")
        for evidence_id in item.get("evidence_ids", []):
            if evidence_id not in evidence_ids:
                raise SpecError(f"hypotheses[{index}] references absent evidence: {evidence_id}")
        if "prior_range" in item:
            values = item["prior_range"]
            if not isinstance(values, list) or len(values) != 2:
                raise SpecError(f"hypotheses[{index}].prior_range must contain two values")
            low = _unit_interval(values[0], path=f"hypotheses[{index}].prior_range[0]")
            high = _unit_interval(values[1], path=f"hypotheses[{index}].prior_range[1]")
            if low > high:
                raise SpecError(f"hypotheses[{index}].prior_range must be ordered")
            item["prior_range"] = [low, high]
        item.setdefault("severity_if_missed", "unknown")
        item.setdefault("action_relevance", "not_declared")
        item.setdefault("residuals", [])

    for index, item in enumerate(options):
        item["label"] = _identifier(item.get("label"), path=f"options[{index}].label")
        kind = item.get("kind")
        if kind not in ALLOWED_OPTION_KINDS:
            raise SpecError(f"options[{index}].kind must be one of {sorted(ALLOWED_OPTION_KINDS)}")
        vector = item.setdefault("vector", {})
        missing = REQUIRED_VECTOR_KEYS - set(vector)
        if missing:
            raise SpecError(f"options[{index}].vector missing {sorted(missing)}")
        for key in REQUIRED_VECTOR_KEYS:
            vector[key] = _unit_interval(vector[key], path=f"options[{index}].vector.{key}")
        burden = item.setdefault("burden", {})
        for key in BURDEN_KEYS:
            burden[key] = _unit_interval(burden.get(key, 0.0), path=f"options[{index}].burden.{key}")
        feasibility = item.setdefault("feasibility", {})
        feasibility["base"] = _unit_interval(feasibility.get("base", 1.0), path=f"options[{index}].feasibility.base")
        feasibility.setdefault("required_capabilities", [])
        item["deadline_hours"] = float(item.get("deadline_hours", context["time_horizon_hours"]))
        if item["deadline_hours"] <= 0:
            raise SpecError(f"options[{index}].deadline_hours must be positive")
        item.setdefault("owner", "responsible_operator")
        item.setdefault("required_authorities", [])
        item.setdefault("affected_parties", [])
        item.setdefault("required_audiences", [])
        if any(a not in CONTEXT_AUDIENCES for a in item["required_audiences"]):
            raise SpecError(f"options[{index}].required_audiences contains unsupported audience")
        item.setdefault("monitor", [])
        item.setdefault("escalation_triggers", [])
        item.setdefault("reasons", [])
        item.setdefault("mandatory_duty_override", False)
        item.setdefault("non_negotiable_violation", False)
        item.setdefault("test_model", None)

    values = case.setdefault("values", {})
    if not isinstance(values, dict):
        raise SpecError("values must be an object")
    values.setdefault("beneficiaries", [])
    values.setdefault("affected_parties", [])
    values.setdefault("non_negotiables", [])
    values.setdefault("power_sensitive", True)
    weights = values.get("weights")
    if weights is not None:
        if not isinstance(weights, dict):
            raise SpecError("values.weights must be an object")
        for key, value in list(weights.items()):
            weights[key] = _unit_interval(value, path=f"values.weights.{key}")

    constraints = case.setdefault("constraints", {})
    constraints.setdefault("available_capabilities", [])
    constraints.setdefault("unavailable_capabilities", [])
    constraints.setdefault("available_authorities", [])
    constraints.setdefault("unavailable_authorities", [])
    constraints.setdefault("notes", [])

    policy = case.setdefault("decision_policy", {})
    policy.setdefault("profile", domain)
    policy.setdefault("risk_tolerance", "balanced")
    policy.setdefault("must_choose_primary", True)
    policy.setdefault("reassessment_hours", context["time_horizon_hours"])
    policy.setdefault("correction_required", True)
    policy.setdefault("require_context_coupling", True)
    policy.setdefault("require_governance_coupling", True)

    case["id_sets"] = {
        "facts": sorted(fact_ids),
        "evidence": sorted(evidence_ids),
        "hypotheses": sorted(hypothesis_ids),
        "options": sorted(option_ids),
    }
    return case
