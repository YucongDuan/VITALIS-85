from __future__ import annotations

from collections import deque

from .model import CoreArtifact


def adjacency(artifact: CoreArtifact) -> dict[str, set[str]]:
    graph = {record_id: set() for record_id in artifact.records}
    for route in artifact.routes:
        graph[route.source].add(route.target)
    return graph


def reverse_adjacency(artifact: CoreArtifact) -> dict[str, set[str]]:
    graph = {record_id: set() for record_id in artifact.records}
    for route in artifact.routes:
        graph[route.target].add(route.source)
    return graph


def reachable(graph: dict[str, set[str]], source: str, target: str) -> bool:
    if source == target:
        return True
    if source not in graph or target not in graph:
        return False
    seen = {source}
    queue = deque([source])
    while queue:
        current = queue.popleft()
        for nxt in graph[current]:
            if nxt == target:
                return True
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return False


def reachable_set(graph: dict[str, set[str]], source: str) -> set[str]:
    if source not in graph:
        return set()
    seen = {source}
    queue = deque([source])
    while queue:
        current = queue.popleft()
        for nxt in graph[current]:
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return seen
