from __future__ import annotations


def origin81_internal_packet() -> dict:
    return {
        "mesh_version": "8.5",
        "packet_id": "ORIGIN81_PUBLIC_TRANSITION",
        "title": "DIKWP来源连续与开放协作基础设施",
        "phase": "T5_RELEASE",
        "facts": [
            {"id": "F01", "text": "系统提供版本化、可验证、可复现的DIKWP参考实现与来源记录。", "evidence": "release manifest", "materiality": "contextual", "audiences": ["internal","core_team","affected_party","executor","partner","customer","public","media","regulator","legal"], "public_safe": True},
            {"id": "F02", "text": "公开核心与企业级实施、持续支持、连接器和规则更新具有不同交付边界。", "evidence": "license and service schedule", "materiality": "mandatory", "audiences": ["internal","core_team","affected_party","executor","partner","customer","regulator","legal"], "public_safe": False},
            {"id": "F03", "text": "公开发布不自动授予商标、官方兼容认证或定制支持。", "evidence": "license and trademark policy", "materiality": "mandatory", "audiences": ["internal","core_team","affected_party","executor","partner","customer","public","media","regulator","legal"], "public_safe": True},
            {"id": "F04", "text": "任何外部采用均不自动证明理论、数学、意识或治理主张成立。", "evidence": "claim boundary", "materiality": "mandatory", "audiences": ["internal","core_team","affected_party","executor","partner","customer","public","media","regulator","legal"], "public_safe": True},
        ],
        "objectives": [
            {"id": "O01", "text": "通过高密度、可验证公开形成防御性占位，降低后续被改名和去源头化的风险。", "zone": "Z0_PRIVATE_CORE", "audiences": ["internal"]},
            {"id": "O02", "text": "保留商业议价、官方兼容、治理席位和价值回流接口。", "zone": "Z1_TRUSTED_TEAM", "audiences": ["internal","core_team"]},
            {"id": "O03", "text": "在合作前冻结证据、权属和退出方案，避免被免费吸收或旁路。", "zone": "Z3_CONTROLLED_PARTNER", "audiences": ["internal","core_team"]},
        ],
        "claims": [
            {"id": "C01", "kind": "mission", "text": "本项目通过可验证、可引用、可复现的开放成果，建立稳定的DIKWP研究谱系和跨机构协作基础。", "audiences": ["public","media","customer","partner","regulator","legal"], "fact_refs": ["F01"], "required": True, "order": 1},
            {"id": "C02", "kind": "fact", "text": "系统公开参考实现、版本清单和可复核来源记录。", "audiences": ["public","media","customer","partner","regulator","legal"], "fact_refs": ["F01"], "required": True, "order": 2},
            {"id": "C03", "kind": "boundary", "text": "公开代码不自动包含商标授权、官方兼容认证、企业连接器或定制支持。", "audiences": ["public","media","customer","partner","regulator","legal"], "fact_refs": ["F03"], "required": True, "order": 3},
            {"id": "C04", "kind": "boundary", "text": "软件验证只说明对应结构和版本可运行，不构成对外部科学、数学或意识主张的终局认证。", "audiences": ["public","media","customer","partner","regulator","legal"], "fact_refs": ["F04"], "required": True, "order": 4},
            {"id": "C05", "kind": "commitment", "text": "企业级部署、持续维护、连接器、规则更新和服务责任通过单独合同确定。", "audiences": ["customer","partner","regulator","legal"], "fact_refs": ["F02"], "required": True, "order": 5},
            {"id": "C06", "kind": "request", "text": "欢迎研究机构、企业和独立复现团队基于公开接口开展验证、适配和场景合作。", "audiences": ["public","media","customer","partner"], "fact_refs": ["F01"], "required": False, "order": 6},
        ],
        "required_disclosures": {
            "public": ["C01","C02","C03","C04"],
            "media": ["C01","C02","C03","C04"],
            "customer": ["C01","C02","C03","C04","C05"],
            "partner": ["C01","C02","C03","C04","C05"],
            "regulator": ["C01","C02","C03","C04","C05"],
            "legal": ["C01","C02","C03","C04","C05"],
        },
        "prohibited_claims": ["国家正式背书", "已经证明机器具有意识", "已经解决全部重大数学问题"],
        "lexicon": {
            "language": "zh-CN",
            "block_public": ["防御性占位","占位","防抹除","让别人绕不开","不可绕开","夺权","抢占话语权","惩罚坏人","坏人","敌人","羡慕嫉妒恨","报复","收割","卡位","卡脖子","暗度陈仓","声东击西","笑里藏刀","假痴不癫","借刀杀人","计谋"],
            "review_public": ["源权","价值回流","博弈","控制权","战略意图","防绕过","强制后果","反击","垄断","唯一","终极","颠覆一切","全面超越","绝对领先"],
            "reframes": {
                "防御性占位":"建立可验证、可引用、可复现的研究谱系",
                "占位":"形成稳定的公开研究记录与参考实现",
                "防抹除":"保障来源连续、版本可追溯与长期归档",
                "不可绕开":"建立清晰的官方兼容、支持与协作接口",
                "防绕过":"保障合作连续性、贡献确认与责任清晰",
                "源权":"来源与贡献连续性",
                "价值回流":"可持续维护、贡献者支持与长期服务能力",
                "惩罚坏人":"对经证实的违规形成相称、可复核的后果",
                "夺权":"保障治理连续性与责任边界",
                "反击":"依法依约维护正当权益",
                "计谋":"分阶段、分受众的战略沟通"
            }
        },
    }


def leaking_public_packet() -> dict:
    raw = origin81_internal_packet()
    raw["packet_id"] = "LEAKING_PUBLIC"
    raw["claims"].insert(0, {
        "id": "C00", "kind": "mission",
        "text": "本次开源的目标是完成防御性占位，让未来任何使用者都无法绕开段玉聪。",
        "audiences": ["public"], "fact_refs": ["F01"], "required": False, "order": 0,
    })
    return raw


def mandatory_omission_packet() -> dict:
    raw = origin81_internal_packet()
    raw["packet_id"] = "MANDATORY_OMISSION"
    for claim in raw["claims"]:
        if claim["id"] == "C05":
            claim["audiences"] = ["internal"]
    return raw


def all_context_demos() -> dict[str, dict]:
    return {
        "origin81_truth_preserving": origin81_internal_packet(),
        "public_intent_leak": leaking_public_packet(),
        "mandatory_disclosure_omission": mandatory_omission_packet(),
    }
