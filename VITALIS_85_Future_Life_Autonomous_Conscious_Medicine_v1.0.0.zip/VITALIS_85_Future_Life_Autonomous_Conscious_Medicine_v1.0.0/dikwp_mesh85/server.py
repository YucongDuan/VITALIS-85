from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from .cli import EXPECTED, examples_dir, run_conformance
from .dashboard import render_result_dashboard
from .integrated import SYSTEM_NAME, evaluate_integrated


class Handler(BaseHTTPRequestHandler):
    server_version = "Mesh85/8.5.0"

    def _send(self, status, body, ctype="application/json; charset=utf-8"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        url = urlparse(self.path)
        qs = parse_qs(url.query)
        if url.path == "/api/health":
            return self._send(200, json.dumps({"status": "ok", "system": SYSTEM_NAME, "version": "8.5.0"}, ensure_ascii=False))
        if url.path == "/api/conformance":
            return self._send(200, json.dumps(run_conformance(), ensure_ascii=False))
        if url.path == "/api/examples":
            return self._send(200, json.dumps({"examples": list(EXPECTED)}, ensure_ascii=False))
        if url.path == "/api/run":
            name = qs.get("example", ["full_worldline_closed.mesh85.json"])[0]
            if name not in EXPECTED:
                return self._send(404, json.dumps({"error": "unknown example"}))
            path = examples_dir() / "private" / name
            result = evaluate_integrated(json.loads(path.read_text(encoding="utf-8")), source_name=str(path))
            return self._send(200, json.dumps(result, ensure_ascii=False))
        if url.path in {"/", "/index.html"}:
            path = examples_dir() / "private" / "full_worldline_closed.mesh85.json"
            result = evaluate_integrated(json.loads(path.read_text(encoding="utf-8")), source_name=str(path))
            page = render_result_dashboard(result, private=True).replace(
                "</header>",
                '<div style="padding:0 5vw 14px;color:#93aeb3">API: /api/health · /api/conformance · /api/examples · /api/run?example=...</div></header>',
            )
            return self._send(200, page, "text/html; charset=utf-8")
        return self._send(404, json.dumps({"error": "not found"}))

    def log_message(self, fmt, *args):
        pass


def serve(host="127.0.0.1", port=8585):
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"Mesh8.5 dashboard: http://{host}:{port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
