from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

from .errors import SpecError

_ALLOWED_ENCODINGS = {"hex", "utf-8", "json"}


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def decode_payload(raw: Any, *, path: str) -> bytes:
    """Normalize a carrier payload to bytes.

    The carrier encoding has zero semantic-generative authority.  The canonical
    core contains bytes only, represented as hexadecimal text.
    """
    if raw is None:
        return b""
    if not isinstance(raw, dict):
        raise SpecError(f"{path} must be an object with encoding and value")
    extra = set(raw) - {"encoding", "value"}
    if extra:
        raise SpecError(f"{path} contains non-protocol fields: {sorted(extra)}")
    encoding = raw.get("encoding")
    if encoding not in _ALLOWED_ENCODINGS:
        raise SpecError(
            f"{path}.encoding must be one of {sorted(_ALLOWED_ENCODINGS)}"
        )
    if "value" not in raw:
        raise SpecError(f"{path}.value is required")
    value = raw["value"]
    if encoding == "hex":
        if not isinstance(value, str):
            raise SpecError(f"{path}.value must be a hexadecimal string")
        if len(value) % 2:
            raise SpecError(f"{path}.value must have even hexadecimal length")
        try:
            return bytes.fromhex(value)
        except ValueError as exc:
            raise SpecError(f"{path}.value is not valid hexadecimal") from exc
    if encoding == "utf-8":
        if not isinstance(value, str):
            raise SpecError(f"{path}.value must be a string for utf-8")
        return value.encode("utf-8")
    return canonical_json_bytes(deepcopy(value))


def encode_payload(data: bytes, *, encoding: str = "hex") -> dict[str, Any]:
    if encoding == "hex":
        return {"encoding": "hex", "value": data.hex()}
    if encoding == "utf-8":
        try:
            return {"encoding": "utf-8", "value": data.decode("utf-8")}
        except UnicodeDecodeError as exc:
            raise SpecError("payload bytes are not valid UTF-8") from exc
    raise SpecError("encode_payload supports hex or utf-8 output")
