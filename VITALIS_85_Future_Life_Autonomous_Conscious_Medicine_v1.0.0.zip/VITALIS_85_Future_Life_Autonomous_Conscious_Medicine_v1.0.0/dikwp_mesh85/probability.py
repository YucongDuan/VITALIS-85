from __future__ import annotations

import math
from typing import Any

from .active_model import HypothesisAssessment, ProbabilityInterval

BAND_RANGES: dict[str, tuple[float, float]] = {
    "very_unlikely": (0.001, 0.05),
    "unlikely": (0.05, 0.20),
    "possible": (0.20, 0.50),
    "likely": (0.50, 0.80),
    "very_likely": (0.80, 0.99),
}

STRENGTH_LR: dict[str, tuple[float, float]] = {
    "negligible": (1.0, 1.05),
    "weak": (1.1, 1.5),
    "moderate": (1.5, 3.0),
    "strong": (3.0, 10.0),
    "very_strong": (10.0, 30.0),
}


def _clip(value: float) -> float:
    return min(0.999, max(0.001, float(value)))


def _odds(p: float) -> float:
    p = _clip(p)
    return p / (1.0 - p)


def _probability(odds: float) -> float:
    return odds / (1.0 + odds)


def _band_for(low: float, high: float) -> str:
    midpoint = (low + high) / 2.0
    for band, (band_low, band_high) in BAND_RANGES.items():
        if band_low <= midpoint <= band_high:
            return band
    return "very_likely" if midpoint > 0.99 else "very_unlikely"


def _prior(hypothesis: dict[str, Any]) -> tuple[float, float, str]:
    if "prior_range" in hypothesis:
        low, high = hypothesis["prior_range"]
        return _clip(low), _clip(high), "declared_numeric_prior"
    band = hypothesis.get("prior_band", "possible")
    if band not in BAND_RANGES:
        raise ValueError(f"unknown prior band: {band}")
    low, high = BAND_RANGES[band]
    return low, high, "declared_ordinal_prior"


def _lr_range(evidence: dict[str, Any]) -> tuple[float, float, str]:
    if "lr_range" in evidence:
        low, high = [float(v) for v in evidence["lr_range"]]
        if low <= 0 or high <= 0 or low > high:
            raise ValueError("lr_range must be positive and ordered")
        return low, high, "declared_lr"
    strength = evidence.get("strength", "weak")
    if strength not in STRENGTH_LR:
        raise ValueError(f"unknown evidence strength: {strength}")
    low, high = STRENGTH_LR[strength]
    direction = evidence.get("direction", "support")
    if direction == "oppose":
        low, high = 1.0 / high, 1.0 / low
    elif direction != "support":
        raise ValueError("evidence direction must be support or oppose")
    return low, high, "generic_structural_lr"


def assess_hypothesis(hypothesis: dict[str, Any], evidence_map: dict[str, dict[str, Any]]) -> HypothesisAssessment:
    low, high, prior_method = _prior(hypothesis)
    rationale = [f"prior={prior_method}:{low:.3f}-{high:.3f}"]
    used: list[str] = []
    methods = {prior_method}
    low_odds, high_odds = _odds(low), _odds(high)
    for evidence_id in hypothesis.get("evidence_ids", []):
        evidence = evidence_map[evidence_id]
        lr_low, lr_high, method = _lr_range(evidence)
        reliability = min(1.0, max(0.0, float(evidence.get("reliability", 1.0))))
        adjusted_low = math.exp(math.log(lr_low) * reliability)
        adjusted_high = math.exp(math.log(lr_high) * reliability)
        candidates = [
            low_odds * adjusted_low,
            low_odds * adjusted_high,
            high_odds * adjusted_low,
            high_odds * adjusted_high,
        ]
        low_odds, high_odds = min(candidates), max(candidates)
        used.append(evidence_id)
        methods.add(method)
        rationale.append(
            f"{evidence_id}:{evidence.get('direction','support')}/{evidence.get('strength','declared')};"
            f"lr={adjusted_low:.3f}-{adjusted_high:.3f};rel={reliability:.2f}"
        )
    posterior_low = _clip(_probability(low_odds))
    posterior_high = _clip(_probability(high_odds))
    interval = ProbabilityInterval(
        low=posterior_low,
        high=posterior_high,
        method="+".join(sorted(methods)),
        band=_band_for(posterior_low, posterior_high),
        rationale=tuple(rationale),
    )
    return HypothesisAssessment(
        hypothesis_id=hypothesis["id"],
        label=hypothesis["label"],
        probability=interval,
        severity_if_missed=hypothesis.get("severity_if_missed", "unknown"),
        action_relevance=hypothesis.get("action_relevance", "not_declared"),
        evidence_used=tuple(used),
        residuals=tuple(hypothesis.get("residuals", [])),
    )


def assess_all(hypotheses: list[dict[str, Any]], evidence: list[dict[str, Any]]) -> list[HypothesisAssessment]:
    evidence_map = {item["id"]: item for item in evidence}
    assessments = [assess_hypothesis(item, evidence_map) for item in hypotheses]
    severity_order = {"critical": 5, "high": 4, "moderate": 3, "low": 2, "minimal": 1, "unknown": 0}
    return sorted(
        assessments,
        key=lambda item: (item.probability.midpoint, severity_order.get(item.severity_if_missed, 0)),
        reverse=True,
    )
