from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

CONTEXT_PROFILES = ("internal", "core_team", "affected_party", "executor", "partner", "customer", "public", "media", "regulator", "legal")
TIMING_PHASES = (
    "T0_HOLD",
    "T1_PROTECT",
    "T2_VALIDATE",
    "T3_SIGNAL",
    "T4_NEGOTIATE",
    "T5_RELEASE",
    "T6_INSTITUTIONALIZE",
)
DISCLOSURE_ZONES = (
    "Z0_PRIVATE_CORE",
    "Z1_TRUSTED_TEAM",
    "Z2_AFFECTED_PARTY_DUTY",
    "Z3_CONTROLLED_PARTNER",
    "Z4_PUBLIC_PROFESSIONAL",
    "Z5_MATERIAL_DISCLOSURE",
    "Z6_LEGAL_PRIVILEGED",
)
CLAIM_KINDS = ("fact", "mission", "commitment", "boundary", "request")
MATERIALITY_LEVELS = ("nonmaterial", "contextual", "material", "mandatory")

DEFAULT_BLOCK_PUBLIC_PHRASES: tuple[str, ...] = ()
DEFAULT_REVIEW_PUBLIC_PHRASES: tuple[str, ...] = ("唯一", "绝对", "已经彻底", "全面超越")
DEFAULT_PUBLIC_REFRAME: dict[str, str] = {}

@dataclass(frozen=True)
class ContextFinding:
    code: str
    message: str
    level: str = "open"
    item_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        data = {"code": self.code, "message": self.message, "level": self.level}
        if self.item_id:
            data["item_id"] = self.item_id
        return data

@dataclass
class ContextPacket:
    version: str = "8.5"
    packet_id: str = "UNSPECIFIED"
    title: str = ""
    phase: str = "T0_HOLD"
    facts: list[dict[str, Any]] = field(default_factory=list)
    objectives: list[dict[str, Any]] = field(default_factory=list)
    claims: list[dict[str, Any]] = field(default_factory=list)
    required_disclosures: dict[str, tuple[str, ...]] = field(default_factory=dict)
    prohibited_claims: tuple[str, ...] = ()
    lexicon: dict[str, Any] = field(default_factory=dict)
    source_name: str = ""
