from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ProbabilityInterval:
    low: float
    high: float
    method: str
    band: str
    rationale: tuple[str, ...] = ()

    @property
    def midpoint(self) -> float:
        return (self.low + self.high) / 2.0

    @property
    def width(self) -> float:
        return self.high - self.low

    def to_dict(self) -> dict[str, Any]:
        return {
            "low": round(self.low, 4),
            "high": round(self.high, 4),
            "midpoint": round(self.midpoint, 4),
            "width": round(self.width, 4),
            "band": self.band,
            "method": self.method,
            "rationale": list(self.rationale),
        }


@dataclass(frozen=True)
class HypothesisAssessment:
    hypothesis_id: str
    label: str
    probability: ProbabilityInterval
    severity_if_missed: str
    action_relevance: str
    evidence_used: tuple[str, ...] = ()
    residuals: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.hypothesis_id,
            "label": self.label,
            "probability": self.probability.to_dict(),
            "severity_if_missed": self.severity_if_missed,
            "action_relevance": self.action_relevance,
            "evidence_used": list(self.evidence_used),
            "residuals": list(self.residuals),
        }


@dataclass(frozen=True)
class OptionAssessment:
    option_id: str
    label: str
    kind: str
    feasible: bool
    gate_reasons: tuple[str, ...]
    vector: dict[str, float]
    score: float
    net_value_of_information: float | None
    robustness: float
    deadline_hours: float
    owner: str
    required_authorities: tuple[str, ...] = ()
    affected_parties: tuple[str, ...] = ()
    required_audiences: tuple[str, ...] = ()
    monitor: tuple[str, ...] = ()
    escalation_triggers: tuple[str, ...] = ()
    reasons: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.option_id,
            "label": self.label,
            "kind": self.kind,
            "feasible": self.feasible,
            "gate_reasons": list(self.gate_reasons),
            "vector": {k: round(v, 4) for k, v in self.vector.items()},
            "score": round(self.score, 4),
            "net_value_of_information": None if self.net_value_of_information is None else round(self.net_value_of_information, 4),
            "robustness": round(self.robustness, 4),
            "deadline_hours": self.deadline_hours,
            "owner": self.owner,
            "required_authorities": list(self.required_authorities),
            "affected_parties": list(self.affected_parties),
            "required_audiences": list(self.required_audiences),
            "monitor": list(self.monitor),
            "escalation_triggers": list(self.escalation_triggers),
            "reasons": list(self.reasons),
        }


@dataclass
class DecisionResult:
    state: str
    primary: OptionAssessment | None
    alternatives: list[OptionAssessment] = field(default_factory=list)
    not_recommended: list[dict[str, Any]] = field(default_factory=list)
    hypothesis_ranking: list[HypothesisAssessment] = field(default_factory=list)
    responsibility_checks: dict[str, bool] = field(default_factory=dict)
    responsibility_closure: str = "OPEN_ACTIVE_RESPONSIBILITY_CLOSURE"
    weights: dict[str, float] = field(default_factory=dict)
    weights_source: str = ""
    correction_contract: dict[str, Any] = field(default_factory=dict)
    explanation: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision_state": self.state,
            "primary_action": None if self.primary is None else self.primary.to_dict(),
            "alternatives": [item.to_dict() for item in self.alternatives],
            "not_recommended": self.not_recommended,
            "hypothesis_ranking": [item.to_dict() for item in self.hypothesis_ranking],
            "responsibility_checks": self.responsibility_checks,
            "responsibility_closure": self.responsibility_closure,
            "weights": {k: round(v, 4) for k, v in self.weights.items()},
            "weights_source": self.weights_source,
            "correction_contract": self.correction_contract,
            "explanation": self.explanation,
        }
