from __future__ import annotations

import re
from typing import Any

from .errors import SpecError
from .governance_model import (
    EVIDENCE_LEVELS, GOVERNANCE_PROFILES, HARM_SEVERITIES, HARM_STATES,
    INTENT_STATES, LINK_KINDS, MANDATORY_CONSTITUTION_KEYS, POWER_DIMENSIONS,
    GovernanceOverlay,
)
from .model import CoreArtifact

_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
_ALLOWED_TOP = {"mesh_version", "case_id", "profile", "actors", "case", "links", "constitution", "safeguards", "consequence_policy"}
_ALLOWED_ROLES = {"affected", "originator", "alleged_actor", "decision_controller", "evidence_controller", "reviewer", "executor", "appeal_reviewer", "beneficiary", "observer"}


def _id(value: Any, path: str) -> str:
    if not isinstance(value, str) or not _ID_RE.fullmatch(value):
        raise SpecError(f"{path} must be a stable id")
    return value


def normalize_governance(raw: Any, artifact: CoreArtifact, *, source_name: str = "") -> GovernanceOverlay:
    if raw is None:
        return GovernanceOverlay(version="8.5", profile="semantic_only", source_name=source_name)
    if not isinstance(raw, dict):
        raise SpecError("governance overlay must be an object")
    extra = set(raw) - _ALLOWED_TOP
    if extra:
        raise SpecError(f"governance overlay contains unsupported fields: {sorted(extra)}")
    version = str(raw.get("mesh_version", "8.5"))
    if version not in {"8.5", "8.5.0", "8.25", "8.25.0"}:
        raise SpecError("governance mesh_version must be 8.5 or migratable 8.25")
    profile = raw.get("profile", "protected")
    if profile not in GOVERNANCE_PROFILES:
        raise SpecError(f"profile must be one of {GOVERNANCE_PROFILES}")
    case_id = _id(raw.get("case_id", "case"), "case_id")

    actors_raw = raw.get("actors", [])
    if not isinstance(actors_raw, list):
        raise SpecError("actors must be a list")
    actors: list[dict[str, Any]] = []
    seen: set[str] = set()
    for i, actor in enumerate(actors_raw):
        if not isinstance(actor, dict):
            raise SpecError(f"actors[{i}] must be an object")
        actor_id = _id(actor.get("id"), f"actors[{i}].id")
        if actor_id in seen:
            raise SpecError(f"duplicate actor id {actor_id}")
        seen.add(actor_id)
        roles = actor.get("roles", [])
        if not isinstance(roles, list) or any(role not in _ALLOWED_ROLES for role in roles):
            raise SpecError(f"actors[{i}].roles contains unsupported role")
        power_raw = actor.get("power", {})
        if not isinstance(power_raw, dict):
            raise SpecError(f"actors[{i}].power must be an object")
        power: dict[str, int] = {}
        for dim in POWER_DIMENSIONS:
            value = power_raw.get(dim, 0)
            if not isinstance(value, int) or not 0 <= value <= 4:
                raise SpecError(f"actors[{i}].power.{dim} must be integer 0..4")
            power[dim] = value
        linked = actor.get("linked_records", [])
        if not isinstance(linked, list):
            raise SpecError(f"actors[{i}].linked_records must be a list")
        for ref in linked:
            if ref not in artifact.records:
                raise SpecError(f"actor {actor_id} references absent record {ref}")
        actors.append({"id": actor_id, "roles": sorted(set(roles)), "power": power, "linked_records": tuple(linked)})

    case = raw.get("case", {})
    if not isinstance(case, dict):
        raise SpecError("case must be an object")
    evidence = case.get("evidence_level", "S0")
    harm_state = case.get("harm_state", "none")
    intent = case.get("intent_state", "unknown")
    severity = case.get("harm_severity", "low")
    if evidence not in EVIDENCE_LEVELS: raise SpecError("invalid evidence_level")
    if harm_state not in HARM_STATES: raise SpecError("invalid harm_state")
    if intent not in INTENT_STATES: raise SpecError("invalid intent_state")
    if severity not in HARM_SEVERITIES: raise SpecError("invalid harm_severity")
    recurrence = case.get("recurrence", 0)
    if not isinstance(recurrence, int) or recurrence < 0: raise SpecError("recurrence must be nonnegative integer")
    case_norm = {
        "evidence_level": evidence,
        "harm_state": harm_state,
        "harm_severity": severity,
        "intent_state": intent,
        "recurrence": recurrence,
        "benefit_flow": bool(case.get("benefit_flow", False)),
        "retaliation_risk": bool(case.get("retaliation_risk", False)),
        "concealment_signal": bool(case.get("concealment_signal", False)),
        "spoliation_signal": bool(case.get("spoliation_signal", False)),
        "promise_breach": bool(case.get("promise_breach", False)),
        "source_erasure": bool(case.get("source_erasure", False)),
        "nonpayment": bool(case.get("nonpayment", False)),
        "ongoing_access": bool(case.get("ongoing_access", False)),
        "evidence_controller": str(case.get("evidence_controller", "")),
        "affected_actor": str(case.get("affected_actor", "")),
        "alleged_actor": str(case.get("alleged_actor", "")),
    }
    for k in ("evidence_controller", "affected_actor", "alleged_actor"):
        if case_norm[k] and case_norm[k] not in seen:
            raise SpecError(f"case.{k} references absent actor {case_norm[k]}")

    links_raw = raw.get("links", {})
    if not isinstance(links_raw, dict):
        raise SpecError("links must be an object")
    extra_links = set(links_raw) - set(LINK_KINDS)
    if extra_links: raise SpecError(f"unsupported link groups: {sorted(extra_links)}")
    links: dict[str, tuple[str, ...]] = {}
    for key, kind in LINK_KINDS.items():
        values = links_raw.get(key, [])
        if not isinstance(values, list): raise SpecError(f"links.{key} must be a list")
        refs = tuple(values)
        for ref in refs:
            if ref not in artifact.records: raise SpecError(f"links.{key} references absent record {ref}")
            if artifact.records[ref].kind != kind: raise SpecError(f"links.{key} record {ref} must be kind {kind}")
        links[key] = refs

    constitution = raw.get("constitution", {})
    if not isinstance(constitution, dict): raise SpecError("constitution must be an object")
    for key, ref in constitution.items():
        if key not in MANDATORY_CONSTITUTION_KEYS: raise SpecError(f"unsupported constitution key {key}")
        if ref not in artifact.records or artifact.records[ref].kind != "W": raise SpecError(f"constitution {key} must reference W record")

    safeguards_raw = raw.get("safeguards", {})
    if not isinstance(safeguards_raw, dict): raise SpecError("safeguards must be an object")
    safeguards = {k: bool(v) for k, v in safeguards_raw.items()}
    policy = raw.get("consequence_policy", {})
    if not isinstance(policy, dict): raise SpecError("consequence_policy must be an object")
    return GovernanceOverlay(version="8.5", case_id=case_id, profile=profile, actors=actors, case=case_norm, links=links, constitution={str(k):str(v) for k,v in constitution.items()}, safeguards=safeguards, consequence_policy=policy, source_name=source_name)
