from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

GOVERNANCE_PROFILES = ("semantic_only", "protected", "adversarial")
EVIDENCE_LEVELS = ("S0", "S1", "S2", "S3", "S4")
HARM_STATES = ("none", "historical", "ongoing", "imminent")
INTENT_STATES = ("unknown", "mistake", "negligent", "reckless", "deliberate")
HARM_SEVERITIES = ("low", "moderate", "high", "critical")
POWER_DIMENSIONS = ("resource", "information", "decision", "narrative", "timing", "exit", "legal", "technical")
LINK_KINDS = {
    "harm_D": "D",
    "benefit_D": "D",
    "source_D": "D",
    "power_I": "I",
    "uncertainty_I": "I",
    "retaliation_I": "I",
    "state_K": "K",
    "constitution_W": "W",
    "containment_P": "P",
    "investigation_P": "P",
    "restitution_P": "P",
    "consequence_P": "P",
    "appeal_P": "P",
    "recovery_P": "P",
}
MANDATORY_CONSTITUTION_KEYS = (
    "non_instrumentalization",
    "substantive_reciprocity",
    "anti_retaliation",
    "value_return",
    "proportional_consequence",
    "anti_impunity",
    "correction_and_appeal",
)

@dataclass(frozen=True)
class GovernanceFinding:
    code: str
    message: str
    level: str = "open"
    linked_records: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        value: dict[str, Any] = {"code": self.code, "message": self.message, "level": self.level}
        if self.linked_records:
            value["linked_records"] = list(self.linked_records)
        return value

@dataclass
class GovernanceOverlay:
    version: str = "8.5"
    case_id: str = "UNSPECIFIED"
    profile: str = "protected"
    actors: list[dict[str, Any]] = field(default_factory=list)
    case: dict[str, Any] = field(default_factory=dict)
    links: dict[str, tuple[str, ...]] = field(default_factory=dict)
    constitution: dict[str, str] = field(default_factory=dict)
    safeguards: dict[str, bool] = field(default_factory=dict)
    consequence_policy: dict[str, Any] = field(default_factory=dict)
    source_name: str = ""
